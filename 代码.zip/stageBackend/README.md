# 项目简介

本项目是舞台规划软件的后端部分，负责规划活动时间安排，实时更新活动信息。

# 快速开始

## 使用 Ubuntu 服务器的准备工作

这一步不是必须的，请根据实际情况决定是否需要 Ubuntu 服务器。

```shell
# 更新软件包列表
apt update
apt upgrade
```

## 配置 Python 环境

配置 Python 环境有两个选项，可以使用 `conda` 或者 `uv`。

### 使用 `conda`

去官网下载 [miniconda](https://www.anaconda.com/download/success)，
下载时注意选择右边的 miniconda，左侧的是完整版，体积比较大。

### 使用 `uv`

安装教程参考：[uv 安装教程](https://uv.doczh.com/getting-started/installation/)，英文原版在[这里](https://docs.astral.sh/uv/getting-started/features/)。

#### Linux 下安装 `uv`

直接下载 `uv` 存在网络问题，建议通过 `pipx` 安装。

```shell
# 这个行为看起来很像用 IE 安装其他浏览器...
apt install pipx
pipx install uv
```

随后配置环境。

```shell
pipx ensurepath
pipx completions
```

然后重启终端。

使用 `uv python install <python-version>` 安装指定版本的 Python。
如果网络不佳，可以临时换源安装：

```shell
uv python install 3.13 --mirror https://github-proxy.lixxing.top/https://github.com/astral-sh/python-build-standalone/releases/download
```

## 安装 `MySQL` 数据库

> 注意，这里不是必须要在本地安装 MySQL，也可以在其他机器上安装。
但是测试时使用的是 localhost 的数据库，如果修改了数据库连接地址，请不要提交到 git 上。

### Ubuntu 下安装 MySQL 数据库

在 Ubuntu 下安装 MySQL 数据库可以直接使用 `apt` 命令：

```bash
apt install mysql-server
```

安装完成后，输入 `mysql` 即可登录数据库。

安装完成后需要配置网络对外开放。进入`/etc/mysql/mysql.conf.d/mysqld.cnf`文件，
将 `bind-address` 改为 `0.0.0.0`，表示允许所有 IP 访问。
修改完成后需要重启 MySQL 服务：

```bash
systemctl restart mysql
```

如果是租用的云服务器，需要手动配置防火墙，将 3306 端口开放。
如果是学校的服务器不能联通的话，请联系服务器管理员开放 3306 端口。

### MacOS 下安装 MySQL 数据库

我这里没有 MacOS 设备，没有测试过在 MacOS 下安装和使用数据库的情况。
但通常没问题。

### Windows 下安装 MySQL 数据库

Windows 下安装 MySQL 数据库点击[这里](https://dev.mysql.com/downloads/mysql/)。
选择带有长期支持版标签 LTS 的数据库，测试在 8.4.6 LTS 版本下正常运行。
大版本一致的情况下，小版本有差别通常没有影响。

下载时请选择MSI安装包，安装时默认是安装在C盘，可以选择 Custom 选项，将数据库安装到其他地方。
安装时默认安装即可，不需要安装全部功能。

安装完成后进入进入完成页面，左下角有默认选择上的配置 setup 选项，点击右下角的 Finish 按钮完成安装。

之后进入配置界面。如果不想将数据放在 C 盘的话可以修改数据目录。

配置项目默认，密码写什么无所谓，反正后续还得创建一个新账号。

一切就绪后点击 Execute 按钮，等待执行结束后即可完成配置。

## 配置数据库

将 MySQL安装路径下的 `bin` 目录添加到环境变量中。然后输入`mysql -u root -p`，登录数据库。
没有密码的话输入`mysql -u root`即可登录数据库。

使用下面的命令创建用户和数据库：

```sql
-- 创建用户，该用户可以从任意IP访问
CREATE USER 'stage'@'%' IDENTIFIED BY 'stagepw';

-- 创建数据库
CREATE DATABASE stagedb CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_bin';

-- 授权用户对数据库的所有权限
GRANT ALL PRIVILEGES ON stagedb.* TO 'stage'@'%';

-- 刷新权限
FLUSH PRIVILEGES;
```

之后依次运行 `script/sql` 文件夹下 `create_database.sql` 文件以创建数据库表，
再运行 `script/sql` 文件夹下 `insert_activity_scope.sql` 文件以创建系统权限。

## 运行项目

### 使用 `conda` 运行项目

在项目根目录下执行如下命令：

```shell
conda create -n stage python=3.13
conda activate stage
pip install -r requirements.txt
python main.py
```

如果修改了项目依赖，请使用下面的命令重新生成 `requirements.txt` 文件：

```shell
# 仅限 conda 环境
pip list --format=freeze > requirements.txt
```

### 使用 `uv` 运行项目

不用担心环境问题，`uv` 会在运行时自动安装环境。使用如下命令运行项目：

```shell
uv run main.py
```

运行后会项目路径下出现 `.venv` 的文件夹，是本项目的虚拟环境的。
该文件夹内置 `.gitignore` 文件已经被排除在版本控制之外。

如果修改了项目依赖，请使用下面的命令重新生成 `requirements.txt` 文件：

```shell
# 仅限 uv 环境
# 生成包含所有依赖的 requirements.txt 文件
uv export --format requirements.txt > requirements.txt
# 生产环境只需要安装生产依赖
uv export --no-dev --format requirements.txt > requirements_prod.txt
```

from pydantic import BaseModel


class SpeechRecognitionRequest(BaseModel):
    base64_data: str

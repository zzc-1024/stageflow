from fastapi import APIRouter, Depends

from model.auth import JWTData
from service.ai.speach_recognition.volces import recognize_task
from service.auth.jwt import get_current_user

from .model import SpeechRecognitionRequest

router = APIRouter()


@router.post("/speech_recognition")
async def speech_recognition(
    base64_data: SpeechRecognitionRequest,
    current_user: JWTData = Depends(get_current_user),
):
    response = recognize_task(base64_data.base64_data)
    if response is None:
        return {
            "code": 1,
            "message": "语言识别失败",
        }
    return {
        "code": 0,
        "message": "语言识别成功",
        "text": response.json()["result"]["text"],
    }

from fastapi import APIRouter

from database.verification.query import addVerificationCode


router = APIRouter()

@router.get("/email")
async def verify_email(account: str):
    code = addVerificationCode(type=1, account=account, purpose=1)
    return {"code": code}

@router.get("/phone")
async def verify_phone(account: str):
    return {"message": "Phone verification code sent"}

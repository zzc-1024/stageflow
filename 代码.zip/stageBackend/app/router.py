from fastapi import APIRouter

from .verification.router import router as verification_router
from .auth.router import router as auth_router
from .activity.router import router as activity_router
from .ai.router import router as ai_router


router = APIRouter()

router.include_router(verification_router, prefix="/verification", tags=["验证码"])

router.include_router(auth_router, prefix="/auth", tags=["认证"])

router.include_router(activity_router, prefix="/activity", tags=["活动"])

router.include_router(ai_router, prefix="/ai", tags=["AI"])

from hashlib import sha256

from fastapi import APIRouter
from pydantic import BaseModel

from database.auth.query import insert_user, select_user_by_email
from service.auth.jwt import create_access_token

class UserAccount(BaseModel):
    email: str
    password: str

class User(UserAccount):
    username: str

SECRET_KEY: str = "371312d255c97dc975f689b561adef994a1fcdcc494d352945d8b6d174b45467"

router = APIRouter()


@router.post("/login")
async def login(user_account: UserAccount):
    users = select_user_by_email(user_account.email)
    if not users:
        return {"code": 1, "message": "用户名或密码错误"}
    if len(users) > 1:
        return {"code": 2, "message": "账号异常，请联系管理员"}
    stored_user = users[0]
    stored_password = stored_user['password']
    if stored_password != sha256(user_account.password.encode()).hexdigest():
        return {"code": 1, "message": "用户名或密码错误"}
    token = create_access_token(
        stored_user['user_id'],
        stored_user['username'],
        user_account.email,
    )
    return {
        "code": 0,
        "message": "登录成功",
        "token": token,
        "user_id": stored_user['user_id'],
        "username": stored_user['username']
    }

@router.post("/register")
async def register(user: User):
    # 先检查该邮箱是否已经被注册
    existing_users = select_user_by_email(user.email)
    if existing_users:
        return {"code": 1, "message": "该邮箱已经被注册"}
    password = sha256(user.password.encode()).hexdigest()
    insert_user(user.username, user.email, password)
    return {"code": 0, "message": "注册成功"}

@router.post("/logout")
async def logout():
    return {"message": "Logout successful"}

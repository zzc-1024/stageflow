from datetime import timedelta
import importlib
import os

from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile

from database.activity.event.query import insert_event
from database.activity.event.event_task.query import insert_event_task

from model.auth import JWTData
from service.auth.jwt import get_current_user
from plugins.excel.template import TemplateExcelPlugin

router = APIRouter()


@router.get("/plugin/all")
async def get_all_excel_plugins(
    current_user: JWTData = Depends(get_current_user),
):
    plugins_path = "plugins/excel"
    if not os.path.exists(plugins_path):
        return {"code": 0, "message": "插件目录不存在", "plugins": []}
    plugins = [
        f.replace(".py", "")
        for f in os.listdir(plugins_path)
        if f.endswith(".py") and f != "template.py"
    ]
    return {"code": 0, "message": "获取所有Excel插件成功", "plugins": plugins}


@router.post("/{activity_id}/upload")
def upload_excel_file(
    activity_id: int,
    file: UploadFile = File(...),
    plugin_name: str = Form(...),
):
    # 包含两个 formdata，分别是 file 和 plugin_name
    plugin_path = f"plugins/excel/{plugin_name}.py"
    if not os.path.exists(os.path.dirname(plugin_path)):
        raise HTTPException(status_code=400, detail="使用的插件文件不存在")
    try:
        plugin_module = importlib.import_module(f"plugins.excel.{plugin_name}")
        plugin: TemplateExcelPlugin = plugin_module.ExcelPlugin()
        events = plugin.parse(file)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

    def process_events(events, parent_event_id=None):
        pre_event_id = None
        for event in events:
            if event["delta_time"] is None:
                event["delta_time"] = 1
            event["delta_time"] = timedelta(seconds=event["delta_time"])
            event_id = insert_event(
                activity_id=activity_id,
                event_name=event["event_name"],
                delta_time=event["delta_time"],
                pre_event_id=pre_event_id,
                parent_event_id=parent_event_id,
            )
            pre_event_id = event_id
            for task in event["event_tasks"]:
                insert_event_task(
                    event_id=event_id,
                    event_task_name=task["event_task_name"],
                    activity_id=activity_id,
                )
            if "children" in event and len(event["children"]) > 0:
                process_events(event["children"], event_id)

    process_events(events)

    return {
        "code": 0,
        "message": "文件导入成功",
    }

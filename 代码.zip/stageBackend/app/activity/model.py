from datetime import datetime
from pydantic import BaseModel
from typing import Optional


class Activity(BaseModel):
    activity_id: Optional[int] = None
    activity_name: str
    activity_description: Optional[str] = None
    activity_start_time: datetime
    activity_visibility: int  # 0: 私密, 1: 公开


class StartControl(BaseModel):
    real_activity_start_time: datetime


class InviteRequest(BaseModel):
    activity_id: int
    user_email: str


class InsertActivityUserRoleRequest(BaseModel):
    activity_scope_id: int


class AskActivityRequest(BaseModel):
    question: str

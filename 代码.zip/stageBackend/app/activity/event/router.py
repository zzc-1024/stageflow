import datetime

from fastapi import APIRouter, Depends, status

from database.activity.event.query import (
    delete_event,
    insert_event,
    update_event,
    update_event_real_delta_time_by_id,
)
from model.auth import JWTData
from service.activity.event.service import build_event_tree
from service.auth.jwt import get_current_user
from service.control import USER_TYPES, remove_activity_connection, ws_connections

from .event_task.router import router as event_task_router
from .model import EventCreateRequest, EventStartRequest, EventUpdateRequest

router = APIRouter()


router.include_router(
    event_task_router,
    prefix="/event_task",
    tags=["事件任务"],
)


@router.get("/all")
async def get_events_by_activity_id(
    activity_id: int, current_user: JWTData = Depends(get_current_user)
) -> dict:
    events = build_event_tree(activity_id)
    return {
        "code": 0,
        "message": "获取事件成功",
        "events": events,
    }


@router.post("/", status_code=status.HTTP_201_CREATED)
async def create_event(
    event_create_request: EventCreateRequest,
    current_user: JWTData = Depends(get_current_user),
) -> dict:
    event_id = insert_event(
        activity_id=event_create_request.activity_id,
        event_name=event_create_request.event_name,
        pre_event_id=event_create_request.pre_event_id,
        parent_event_id=event_create_request.parent_event_id,
        delta_time=datetime.timedelta(seconds=event_create_request.delta_time),
    )
    return {"code": 0, "message": "事件创建成功", "event_id": event_id}


@router.put("/{event_id}")
async def set_event_by_id(
    event_id: int,
    event_update_request: EventUpdateRequest,
    current_user: JWTData = Depends(get_current_user),
) -> dict:
    if event_update_request.real_delta_time is not None:
        real_delta_time = datetime.timedelta(
            seconds=event_update_request.real_delta_time
        )
    else:
        real_delta_time = None
    if not update_event(
        event_id,
        event_name=event_update_request.event_name,
        delta_time=datetime.timedelta(seconds=event_update_request.delta_time),
        real_delta_time=real_delta_time,
    ):
        return {"code": 1, "message": "事件更新失败"}
    return {"code": 0, "message": "事件更新成功"}


@router.put("/{activity_id}/{event_id}/real_delta_time")
async def set_event_real_delta_time_by_id(
    activity_id: int,
    event_id: int,
    event_start_request: EventStartRequest,
    current_user: JWTData = Depends(get_current_user),
) -> dict:
    if event_start_request.real_delta_time is None:
        delta_time = None
    else:
        delta_time = datetime.timedelta(seconds=event_start_request.real_delta_time)
    if not update_event_real_delta_time_by_id(
        event_id,
        real_delta_time=delta_time,
    ):
        return {"code": 1, "message": "事件更新失败"}
    for ut in USER_TYPES:
        for token in ws_connections[activity_id][ut]:
            try:
                await ws_connections[activity_id][ut][token].send_text(
                    f"event set_real_delta_time {event_id} {event_start_request.real_delta_time}"
                )
            except Exception:
                remove_activity_connection(activity_id, ut, token)
    return {"code": 0, "message": "事件更新成功"}


@router.delete("/{event_id}")
async def delete_event_by_id(
    event_id: int,
    current_user: JWTData = Depends(get_current_user),
) -> dict:
    if not delete_event(event_id):
        return {"code": 1, "message": "事件删除失败"}
    return {"code": 0, "message": "事件删除成功"}

import datetime
from fastapi import APIRouter, Depends, HTTPException, status

from app.activity.event.event_task.model import (
    EventTaskCreateRequest,
    EventTaskUpdateRequest,
    EventTaskUpdateStartTimeRequest,
    ParticipationTaskCreateRequest,
    ParticipationTaskUpdateRequest,
)
from database.activity.event.event_task.query import (
    delete_event_task,
    insert_event_task,
    update_event_task,
    update_event_task_start_time,
    insert_participation_task,
    delete_participation_task,
    update_participation_task,
)
from model.auth import JWTData
from service.auth.jwt import get_current_user
from service.control import remove_activity_connection, ws_connections

router = APIRouter()


@router.post("/create", status_code=status.HTTP_201_CREATED)
async def create_event_task(
    create_event_task_request: EventTaskCreateRequest,
    current_user: JWTData = Depends(get_current_user),
) -> dict[str, int | str]:
    event_task_id = insert_event_task(
        activity_id=create_event_task_request.activity_id,
        event_id=create_event_task_request.event_id,
        event_task_name=create_event_task_request.event_task_name,
    )
    return {
        "code": 0,
        "message": "事件任务创建成功",
        "event_task_id": event_task_id,
    }


@router.delete("/{event_task_id}", status_code=status.HTTP_200_OK)
async def delete_event_task_by_id(
    event_task_id: int,
    current_user: JWTData = Depends(get_current_user),
) -> dict[str, int | str]:
    row_count = delete_event_task(event_task_id)
    if row_count == 0:
        return {
            "code": 1,
            "message": "事件任务不存在",
        }
    return {
        "code": 0,
        "message": "事件任务删除成功",
    }


@router.put("/{event_task_id}", status_code=status.HTTP_200_OK)
async def update_event_task_by_id(
    event_task_id: int,
    update_event_task_request: EventTaskUpdateRequest,
    current_user: JWTData = Depends(get_current_user),
) -> dict[str, int | str]:
    row_count = update_event_task(
        event_task_id,
        update_event_task_request.event_task_name,
    )
    if row_count == 0:
        return {
            "code": 1,
            "message": "事件任务不存在",
        }
    return {
        "code": 0,
        "message": "事件任务更新成功",
    }


@router.put("/{event_task_id}/start_time", status_code=status.HTTP_200_OK)
async def update_event_task_start_time_by_id(
    event_task_id: int,
    update_event_task_start_time_request: EventTaskUpdateStartTimeRequest,
    current_user: JWTData = Depends(get_current_user),
) -> dict[str, int | str]:
    if update_event_task_start_time_request.event_task_start_time is None:
        event_task_start_time = None
    else:
        event_task_start_time = datetime.timedelta(
            seconds=update_event_task_start_time_request.event_task_start_time
        )
    row_count = update_event_task_start_time(
        event_task_id,
        event_task_start_time,
    )
    if row_count == 0:
        return {
            "code": 1,
            "message": "更新失败",
        }
    return {
        "code": 0,
        "message": "事件任务开始时间更新成功",
    }


@router.post("/{event_task_id}/participation", status_code=status.HTTP_201_CREATED)
async def create_participation_task(
    event_task_id: int,
    create_participation_task_request: ParticipationTaskCreateRequest,
    current_user: JWTData = Depends(get_current_user),
) -> dict[str, int | str]:
    participation_task_id = insert_participation_task(
        activity_id=create_participation_task_request.activity_id,
        event_task_id=event_task_id,
        activity_participation_id=create_participation_task_request.activity_participation_id,
    )
    return {
        "code": 0,
        "message": "参与任务创建成功",
        "participation_task_id": participation_task_id,
    }


@router.delete(
    "/participation/{participation_task_id}",
    status_code=status.HTTP_200_OK,
)
async def delete_participation_task_by_id(
    participation_task_id: int,
    current_user: JWTData = Depends(get_current_user),
) -> dict[str, int | str]:
    row_count = delete_participation_task(participation_task_id)
    if row_count == 0:
        return {
            "code": 1,
            "message": "参与任务不存在",
        }
    return {
        "code": 0,
        "message": "参与任务删除成功",
    }


@router.put(
    "/{activity_id}/participation/{participation_task_id}",
    status_code=status.HTTP_200_OK,
)
async def checkIn(
    activity_id: int,
    participation_task_id: int,
    update_participation_task_request: ParticipationTaskUpdateRequest,
    current_user: JWTData = Depends(get_current_user),
) -> dict[str, int | str]:
    if update_participation_task_request.status not in [0, 1]:
        return {
            "code": 1,
            "message": "参与任务状态错误",
        }
    if not update_participation_task(
        participation_task_id, update_participation_task_request.status
    ):
        return {
            "code": 2,
            "message": "参与任务不存在",
        }
    user_type = "admin"
    # 检查连接是否存在
    if activity_id not in ws_connections:
        raise HTTPException(
            status_code=400,
            detail="Activity not found",
        )
    if user_type not in ws_connections[activity_id]:
        raise HTTPException(
            status_code=400,
            detail="User type not found",
        )
    for token in ws_connections[activity_id][user_type]:
        try:
            await ws_connections[activity_id][user_type][token].send_text(
                f"participation_task check_in {participation_task_id} {update_participation_task_request.status}"
            )
        except Exception:
            remove_activity_connection(activity_id, user_type, token)
    return {
        "code": 0,
        "message": "参与任务更新成功",
    }

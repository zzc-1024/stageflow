from pydantic import BaseModel


class EventTaskCreateRequest(BaseModel):
    activity_id: int
    event_id: int
    event_task_name: str


class EventTaskUpdateRequest(BaseModel):
    event_task_name: str


class EventTaskUpdateStartTimeRequest(BaseModel):
    event_task_start_time: int | None = None


class ParticipationTaskCreateRequest(BaseModel):
    activity_id: int
    activity_participation_id: int


class ParticipationTaskUpdateRequest(BaseModel):
    status: int

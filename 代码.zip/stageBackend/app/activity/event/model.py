from pydantic import BaseModel


class EventCreateRequest(BaseModel):
    activity_id: int
    event_name: str
    parent_event_id: int | None = None
    pre_event_id: int | None = None
    delta_time: int


class EventUpdateRequest(BaseModel):
    event_name: str
    delta_time: int
    real_delta_time: int | None = None


class EventStartRequest(BaseModel):
    real_delta_time: int | None

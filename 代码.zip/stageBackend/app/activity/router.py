import asyncio

from fastapi import (
    APIRouter,
    Depends,
    HTTPException,
    WebSocket,
    WebSocketDisconnect,
    status,
)

from app.activity.model import (
    Activity,
    AskActivityRequest,
    InsertActivityUserRoleRequest,
    InviteRequest,
    StartControl,
)
from database.activity.query import (
    delete_activity_participation,
    delete_activity_user_role,
    insert_activity,
    insert_activity_participation,
    insert_activity_user_role,
    select_activities_by_owner_user_id,
    select_activity_by_id,
    select_activity_participations,
    select_participated_activities_by_user_id,
    update_activity_real_activity_start_time_by_id,
)
from model.auth import JWTData
from service.ai.chat import chat
from service.auth.jwt import decode_token, get_current_user
from service.control import (
    USER_TYPES,
    add_activity_connection,
    remove_activity_connection,
    ws_connections,
)

from .event.router import router as event_router
from .excel.router import router as excel_router

router = APIRouter()

router.include_router(event_router, prefix="/event", tags=["活动中的事件"])
router.include_router(excel_router, prefix="/excel", tags=["用Excel导入活动"])


@router.websocket("/{activity_id}")
async def control(websocket: WebSocket, activity_id: int, user_type: str, token: str):
    # 获取Bearer Token
    if token is None:
        raise HTTPException(
            status_code=401,
            detail="Invalid authentication credentials",
            headers={"WWW-Authenticate": "Bearer"},
        )
    # 解码Token
    _: JWTData = decode_token(token)

    await websocket.accept()
    try:
        add_activity_connection(activity_id, user_type, token, websocket)
    except Exception:
        remove_activity_connection(activity_id, user_type, token)
        raise HTTPException(
            status_code=400,
            detail="Token already connected",
        )
    while True:
        try:
            data = await asyncio.wait_for(websocket.receive_text(), timeout=21)
            if data == "ping":
                await websocket.send_text("pong")
                continue
            else:
                print("预期之外的心跳", data)
                continue
        except asyncio.TimeoutError:
            print("Timeout")
            remove_activity_connection(activity_id, user_type, token)
            break
        except WebSocketDisconnect:
            print("Disconnect")
            remove_activity_connection(activity_id, user_type, token)
            break


@router.get("/")
async def get_activity(current_user: JWTData = Depends(get_current_user)):
    activities = select_activities_by_owner_user_id(owner_user_id=current_user.user_id)
    return {"code": 0, "message": "获取活动列表成功", "activities": activities}


@router.get("/managed")
async def get_managed_activities(current_user: JWTData = Depends(get_current_user)):
    activities = []
    return {"code": 0, "message": "获取活动列表成功", "activities": activities}


@router.get("/participate")
async def get_participated_activities(
    current_user: JWTData = Depends(get_current_user),
):
    activities = select_participated_activities_by_user_id(current_user.user_id)
    return {"code": 0, "message": "获取活动列表成功", "activities": activities}


# 注意这里路径可能和上面冲突，以后开发要注意
@router.get("/{activity_id}")
async def get_activity_by_id(
    activity_id: int, current_user: JWTData = Depends(get_current_user)
):
    activity = select_activity_by_id(activity_id)
    if not activity:
        raise HTTPException(status_code=404, detail="活动不存在")
    return {"code": 0, "message": "获取活动信息成功", "activity": activity}


@router.post("/", status_code=status.HTTP_201_CREATED)
async def create_activity(
    activity: Activity, current_user: JWTData = Depends(get_current_user)
):
    last_row_id = insert_activity(
        owner_user_id=current_user.user_id,
        activity_name=activity.activity_name,
        activity_start_time=activity.activity_start_time,
        activity_description=activity.activity_description or "",
        activity_visibility=activity.activity_visibility,
    )
    return {"code": 0, "message": "活动创建成功", "activity_id": last_row_id}


@router.put("/{activity_id}/start")
async def start_activity(
    activity_id: int,
    start_control: StartControl,
    current_user: JWTData = Depends(get_current_user),
):
    if activity_id not in ws_connections:
        raise HTTPException(
            status_code=400,
            detail="Activity not found",
        )
    if not update_activity_real_activity_start_time_by_id(
        activity_id, start_control.real_activity_start_time
    ):
        raise HTTPException(
            status_code=400,
            detail="Activity not found",
        )
    for ut in USER_TYPES:
        if ut not in ws_connections[activity_id]:
            continue
        for token in ws_connections[activity_id][ut]:
            try:
                await ws_connections[activity_id][ut][token].send_text(
                    f"activity start {start_control.real_activity_start_time.isoformat()}"
                )
            except Exception:
                remove_activity_connection(activity_id, ut, token)
    return {
        "code": 0,
        "message": "Activity started",
    }


# TODO: 把 activity_id 换成 path 参数
@router.post("/invite")
async def invite_user(
    invite_request: InviteRequest, current_user: JWTData = Depends(get_current_user)
):
    activitiy = select_activity_by_id(invite_request.activity_id)
    if not activitiy:
        raise HTTPException(status_code=404, detail="活动不存在")
    # 判断用户是否拥有当前活动
    if activitiy["owner_user_id"] != current_user.user_id:
        raise HTTPException(status_code=403, detail="没有权限邀请用户")

    last_row_id = insert_activity_participation(
        invite_request.activity_id, invite_request.user_email
    )

    if last_row_id == 0:
        return {"code": 1, "message": "邀请失败，用户可能不存在或已被邀请"}

    return {"code": 0, "message": "邀请成功", "invite_id": last_row_id}


# TODO: 验证权限
@router.get("/{activity_id}/member")
async def get_activity_members(
    activity_id: int, current_user: JWTData = Depends(get_current_user)
):
    members = select_activity_participations(activity_id)
    return {"code": 0, "message": "获取成员列表成功", "members": members}


# TODO: 验证权限
@router.delete("/member/{activity_participation_id}")
async def remove_activity_member(
    activity_participation_id: int, current_user: JWTData = Depends(get_current_user)
):
    delete_activity_participation(activity_participation_id)
    return {"code": 0, "message": "移除成员成功"}


@router.put("/member/role/{activity_participation_id}")
async def update_activity_member_role(
    activity_participation_id: int,
    update_request: InsertActivityUserRoleRequest,
    current_user: JWTData = Depends(get_current_user),
):
    last_row_id = insert_activity_user_role(
        activity_participation_id, update_request.activity_scope_id
    )
    if last_row_id == 0:
        raise HTTPException(status_code=400, detail="更新成员角色失败")
    return {
        "code": 0,
        "message": "更新成员角色成功",
        "user_activity_role_id": last_row_id,
    }


@router.delete("/member/role/{user_activity_role_id}")
async def remove_activity_member_role(
    user_activity_role_id: int,
    current_user: JWTData = Depends(get_current_user),
):
    delete_activity_user_role(user_activity_role_id)
    return {"code": 0, "message": "移除成员角色成功"}


@router.post("/{activity_id}/ask")
async def ask_activity(
    activity_id: int,
    ask_request: AskActivityRequest,
    current_user: JWTData = Depends(get_current_user),
):
    # 调用大模型
    response = await chat(
        question=ask_request.question,
    )
    return {"code": 0, "message": "问答成功结束", "response": response}

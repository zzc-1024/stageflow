import json

from fastmcp import Client
from fastmcp.client.transports import StreamableHttpTransport
from openai.types.chat.chat_completion_message_param import ChatCompletionMessageParam

from .llm.volces import chat as volces_chat

_chat_api = volces_chat


async def _process_llm_response(mcp_client: Client, llm_response: str) -> str:
    """处理LLM响应，解析工具调用并执行"""
    try:
        # 尝试移除可能的markdown格式
        if llm_response.startswith("```json"):
            llm_response = llm_response.strip("```json").strip("```").strip()
        tool_call = json.loads(llm_response)
        if "tool" in tool_call and "arguments" in tool_call:
            # 检查工具是否可用
            tools = await mcp_client.list_tools()
            if any(tool.name == tool_call["tool"] for tool in tools):
                try:
                    # 执行工具调用
                    result = await mcp_client.call_tool(
                        tool_call["tool"], tool_call["arguments"]
                    )

                    return f"Tool execution result: {result}"
                except Exception as e:
                    error_msg = f"Error executing tool: {str(e)}"
                    return error_msg
            return f"No server found with tool: {tool_call['tool']}"
        return llm_response
    except json.JSONDecodeError:
        # 如果不是JSON格式，直接返回原始响应
        return llm_response


async def chat(
    question: str,
    system_message: str | None = None,
) -> str:
    """启动聊天会话的主循环"""
    # transport = StreamableHttpTransport(url="https://127.0.0.1:8192/mcp_server/mcp")
    transport = StreamableHttpTransport(url="http://127.0.0.1:8193/mcp")
    async with Client(transport) as mcp_client:
        # 获取可用工具列表并格式化为系统提示的一部分
        tools = await mcp_client.list_tools()
        dict_list = [tool.__dict__ for tool in tools]
        tools_description = json.dumps(dict_list, ensure_ascii=False)
        if not system_message:
            system_message = f"""
你是一个智能助手，严格遵循以下协议返回响应：

可用工具：{tools_description}

响应规则：
1、当需要计算时，返回严格符合以下格式的纯净JSON：
{{
    "tool": "tool-name",
    "arguments": {{
        "argument-name": "value"
    }}
}}
2、禁止包含以下内容：
- Markdown标记（如```json）
- 自然语言解释（如"结果："）
- 格式化数值（必须保持原始精度）
- 单位符号（如元、kg）

校验流程：
✓ 参数数量与工具定义一致
✓ 数值类型为number
✓ JSON格式有效性检查

正确示例：
用户：单价88.5买235个多少钱？
响应：{{"tool":"multiply","arguments":{{"a":88.5,"b":235}}}}

错误示例：
用户：总金额是多少？
错误响应：总价500元 → 含自然语言
错误响应：```json{{...}}``` → 含Markdown

3、在收到工具的响应后：
- 将原始数据转化为自然、对话式的回应
- 保持回复简洁但信息丰富
- 聚焦于最相关的信息
- 使用用户问题中的适当上下文
- 避免简单重复使用原始数据
            """
        messages: list[ChatCompletionMessageParam] = [
            {"role": "system", "content": system_message},
            {"role": "user", "content": question},
        ]

        # 获取LLM的初始响应
        llm_response: str = _chat_api(messages)

        # 处理可能的工具调用
        result = await _process_llm_response(mcp_client, llm_response)

        # 如果处理结果与原始响应不同，说明执行了工具调用，需要进一步处理
        print("llm_response", llm_response)
        while result != llm_response:
            messages.append({"role": "assistant", "content": llm_response})
            messages.append({"role": "system", "content": result})

            # 将工具执行结果发送回LLM获取新响应
            llm_response: str = _chat_api(messages)
            result = await _process_llm_response(mcp_client, llm_response)
            print("llm_response", llm_response)

        return llm_response

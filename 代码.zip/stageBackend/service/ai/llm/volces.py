from typing import Iterable

from openai import OpenAI
from openai.types.chat.chat_completion_message_param import ChatCompletionMessageParam


def chat(messages: Iterable[ChatCompletionMessageParam]) -> str:
    # 请确保您已将 API Key 存储在环境变量 ARK_API_KEY 中
    # 初始化Ark客户端，从环境变量中读取您的API Key
    client = OpenAI(
        # 此为默认路径，您可根据业务所在地域进行配置
        base_url="https://ark.cn-beijing.volces.com/api/v3",
        # 从环境变量中获取您的 API Key。此为默认方式，您可根据需要进行修改
        api_key="<your_api_key>",
    )

    response = client.chat.completions.create(
        # 指定您创建的方舟推理接入点 ID，此处已帮您修改为您的推理接入点 ID
        model="doubao-seed-1-6-flash-250828",
        messages=messages,
    )

    # 检查响应是否包含内容
    if not response.choices[0].message.content:
        return "未收到有效回复"
    return response.choices[0].message.content


if __name__ == "__main__":
    print(chat([{"role": "user", "content": "你好"}]))

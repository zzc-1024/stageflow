from datetime import datetime, timedelta

from fastapi import Depends, HTTPException
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
import jwt

from model.auth import JWTData


security = HTTPBearer()

ACCESS_TOKEN_EXPIRE_MINUTES = 7 * 24 * 60
SECRET_KEY = "371312d255c97dc975f689b561adef994a1fcdcc494d352945d8b6d174b45467"
ALGORITHM = "HS256"


async def get_current_user(
    credentials: HTTPAuthorizationCredentials = Depends(security),
) -> JWTData:
    if not credentials:
        raise HTTPException(
            status_code=401,
            detail="Invalid authentication credentials",
            headers={"WWW-Authenticate": "Bearer"},
        )

    token = credentials.credentials

    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
    except jwt.exceptions.ExpiredSignatureError as e:
        print(e)
        raise HTTPException(
            status_code=401,
            detail="Token has expired",
            headers={"WWW-Authenticate": "Bearer"},
        )

    user_id: int = payload.get("user_id")
    username: str = payload.get("username")
    exp: int = payload.get("exp")
    email: str = payload.get("email")

    # 检测超时
    if datetime.now() > datetime.fromtimestamp(exp):
        raise HTTPException(
            status_code=401,
            detail="Token has expired",
            headers={"WWW-Authenticate": "Bearer"},
        )

    return JWTData(user_id=user_id, username=username, email=email, exp=exp)


def create_access_token(
    user_id: int, username: str, email: str, expires_delta: timedelta | None = None
) -> str:
    expire = datetime.now() + (
        expires_delta or timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    )
    to_encode = {
        "user_id": user_id,
        "username": username,
        "email": email,
        "exp": expire,
    }
    return jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)


def decode_token(token: str) -> JWTData:
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
    except jwt.PyJWTError:
        raise HTTPException(
            status_code=401,
            detail="Invalid token",
            headers={"WWW-Authenticate": "Bearer"},
        )
    user_id: int = payload.get("user_id")
    username: str = payload.get("username")
    exp: int = payload.get("exp")
    email: str = payload.get("email")
    if user_id is None or username is None or exp is None or email is None:
        raise HTTPException(
            status_code=401,
            detail="Invalid token",
            headers={"WWW-Authenticate": "Bearer"},
        )
    if datetime.now() > datetime.fromtimestamp(exp):
        raise HTTPException(
            status_code=401,
            detail="Token has expired",
            headers={"WWW-Authenticate": "Bearer"},
        )
    return JWTData(user_id=user_id, username=username, email=email, exp=exp)

from fastapi import FastAPI, File, UploadFile, HTTPException
import uvicorn
import pandas as pd
import datetime
import io

app = FastAPI()

# # 时长转化为秒
def parse_duration(val)-> int:

    if val == "/" or pd.isna(val):
        return 0
    if isinstance(val, datetime.timedelta):
        return int(val.total_seconds())
    if isinstance(val, datetime.time):
        return val.hour * 3600 + val.minute * 60 + val.second
    if isinstance(val, str):
        if ":" in val:
            try:
                parts = val.split(":")
                if len(parts) == 3:
                    h, m, s = map(int, parts)
                elif len(parts) == 2:
                    h = 0
                    m, s = map(int, parts)
                else:
                    return 0
                return h * 3600 + m * 60 + s
            except:
                return 0
        try:
            return int(val)
        except:
            return 0
    if isinstance(val, (int, float)):
        return int(val)
    return 0

def parse_excel_data(df: pd.DataFrame) -> list:
    OPTIONAL_RENAME = {
        "环节属性": "节目属性",
        "上场口": "上场口",
        "下场口": "下场口"
    }
    IGNORE_FIELDS = ["结束时间", "服装", "化妆", "演出形式"]
    REQUIRED_FIELDS = ["开始时间", "时长", "节目名", "人员", "歌曲", "环节"]

    df = df.rename(columns=lambda x: OPTIONAL_RENAME.get(x, x))
    df = df[[col for col in df.columns if col not in IGNORE_FIELDS]]

    for f in REQUIRED_FIELDS:
        if f not in df.columns:
            raise ValueError(f"缺少必须字段: {f}")

    df["环节"] = df["环节"].ffill()

    group_cols = ["节目名", "人员"]
    if "节目属性" in df.columns:
        group_cols.append("节目属性")
    df[group_cols] = df.groupby("环节")[group_cols].ffill()

    df = df.fillna("/")

    df["环节"] = df["环节"].astype(str).str.replace("\n", " ", regex=False).str.replace(r"\s+", " ", regex=True).str.strip()
    df["节目名"] = df["节目名"].astype(str).str.strip()
    df["人员"] = df["人员"].astype(str).str.strip()
    df["歌曲"] = df["歌曲"].astype(str).str.strip()
    if "节目属性" in df.columns:
        df["节目属性"] = df["节目属性"].astype(str).str.strip()

    


    phases = []

    current_phase_name = None
    current_phase_rows = []

    def flush_phase(rows, phase_name):
        if not rows:
            return None
        df_phase = pd.DataFrame(rows)

        phase = {"name": phase_name, "program_items": []}

        current_prog_name = None
        current_prog_rows = []
        def flush_program(rows, prog_name):

            if not rows:
                return None
            df_prog = pd.DataFrame(rows)

            lead_person = df_prog["人员"].iloc[0]
            program_attr = df_prog["节目属性"].iloc[0] if "节目属性" in df.columns else "固定"

            program = {
                "name": prog_name,
                "人员": lead_person,
                "shows": []
            }
            for _, row in df_prog.iterrows():
                song_text = row["歌曲"]
                if song_text in ["/", "", "nan"]:
                    continue

                start_time_val = row["开始时间"]
                if pd.isna(start_time_val) or start_time_val == "/":
                    start_time_str = "/"
                elif isinstance(start_time_val, datetime.time):
                    start_time_str = start_time_val.strftime("%H:%M:%S")
                elif isinstance(start_time_val, str):
                    start_time_str = start_time_val.strip()
                else:
                    start_time_str = str(start_time_val)

                program_attr = str(row["节目属性"]) if "节目属性" in row and pd.notna(row["节目属性"]) else "固定"
                show_type = "fixed" if program_attr == "固定" else "free"

                show = {
                    "name": song_text,
                    "duration": parse_duration(row["时长"]),
                    "start_time": start_time_str,
                    "节目属性": program_attr,
                    "type": show_type,
                    "负责导演": str(row.get("负责导演", "/")).strip(),
                    "上场口": str(row.get("上场口", "/")).strip(),
                    "下场口": str(row.get("下场口", "/")).strip(),
                    "keyboard": str(row.get("keyboard", "/")).strip(),
                    "音频（麦）": str(row.get("音频（麦）", "/")).strip(),
                    "灯光/激光": str(row.get("灯光/激光", "/")).strip(),
                    "大屏": str(row.get("大屏", "/")).strip(),
                    "视觉": str(row.get("视觉", "/")).strip(),
                    "特效": str(row.get("特效", "/")).strip(),
                    "三方演员": str(row.get("三方演员", "/")).strip(),
                    "道具": str(row.get("道具", "/")).strip(),
                    "道具cue": str(row.get("道具cue", "/")).strip(),
                }
                program["shows"].append(show)

            return program if program["shows"] else None
        for _, row in df_phase.iterrows():
            prog_name = row["节目名"]

            prog = flush_program(current_prog_rows, current_prog_name)
            if prog:
                phase["program_items"].append(prog)

            current_prog_name = prog_name
            current_prog_rows = [row]

        prog = flush_program(current_prog_rows, current_prog_name)
        if prog:
            phase["program_items"].append(prog)

        return phase if phase["program_items"] else None

    for _, row in df.iterrows():
        phase_name = row["环节"]
        if phase_name != current_phase_name:
            phase = flush_phase(current_phase_rows, current_phase_name)
            if phase:
                phases.append(phase)
            current_phase_name = phase_name
            current_phase_rows = [row]
        else:
            current_phase_rows.append(row)

    phase = flush_phase(current_phase_rows, current_phase_name)
    if phase:
        phases.append(phase)

    return phases

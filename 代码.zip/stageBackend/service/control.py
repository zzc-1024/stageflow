from fastapi import HTTPException, WebSocket


# 出于兼容性考虑，这里使用webSocket而不是SSE
# 所以这里只发送信息，不接收信息
# 后续放到service中
# 目前这部分可能存在bug，清理字典不完全，但是不影响使用，后续检查
USER_TYPES = ["user", "admin"]
ws_connections: dict[int, dict[str, dict[str, WebSocket]]] = {}


def add_activity_connection(
    activity_id: int, user_type: str, token: str, websocket: WebSocket
):
    if user_type not in USER_TYPES:
        raise HTTPException(
            status_code=400,
            detail="Invalid user type",
        )
    if activity_id not in ws_connections:
        ws_connections[activity_id] = {}
    for ut in USER_TYPES:
        if ut not in ws_connections[activity_id]:
            ws_connections[activity_id][ut] = {}
    if token in ws_connections[activity_id][user_type]:
        raise HTTPException(
            status_code=400,
            detail="Token already connected",
        )
    ws_connections[activity_id][user_type][token] = websocket


def remove_activity_connection(activity_id: int, user_type: str, token: str):
    if activity_id not in ws_connections:
        return
    if user_type not in ws_connections[activity_id]:
        return
    if token not in ws_connections[activity_id][user_type]:
        return
    del ws_connections[activity_id][user_type][token]
    if not ws_connections[activity_id][user_type]:
        del ws_connections[activity_id][user_type]
    if not ws_connections[activity_id]:
        del ws_connections[activity_id]


async def broadcast_activity_message_by_user_type(
    activity_id: int, user_type: str, message: dict
):
    if activity_id not in ws_connections:
        return
    if user_type not in ws_connections[activity_id]:
        return
    for token in ws_connections[activity_id][user_type]:
        try:
            await ws_connections[activity_id][user_type][token].send_json(message)
        except Exception:
            remove_activity_connection(activity_id, user_type, token)


async def broadcast_activity_message(activity_id: int, message: dict):
    if activity_id not in ws_connections:
        return
    for ut in USER_TYPES:
        await broadcast_activity_message_by_user_type(activity_id, ut, message)

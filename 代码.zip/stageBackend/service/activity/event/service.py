from database.activity.event.query import select_event_by_activity_id
from database.activity.event.event_task.query import (
    select_event_task_by_activity_id,
    select_participation_task_by_activity_id,
)


def build_event_tree(activity_id: int) -> list[dict]:
    # 1. 获取所有事件及相关任务数据
    events = select_event_by_activity_id(activity_id)
    event_tasks = select_event_task_by_activity_id(activity_id)
    participation_tasks = select_participation_task_by_activity_id(activity_id)

    # 2. 处理参与任务：按event_task_id分组
    participation_task_map: dict[int, list[dict]] = {}
    for pt in participation_tasks:
        et_id = pt["event_task_id"]
        if et_id not in participation_task_map:
            participation_task_map[et_id] = []
        participation_task_map[et_id].append(pt)

    # 3. 处理事件任务：按event_id分组，并关联对应的参与任务
    event_task_map: dict[int, list[dict]] = {}
    for et in event_tasks:
        event_id = et["event_id"]
        # 为每个事件任务添加参与任务列表
        et["participation_tasks"] = participation_task_map.get(et["event_task_id"], [])

        if et["event_task_start_time"]:
            et["event_task_start_time"] = et["event_task_start_time"].total_seconds()

        if event_id not in event_task_map:
            event_task_map[event_id] = []
        event_task_map[event_id].append(et)

    # 4. 创建事件 ID 到事件对象的映射，并初始化 children 和 event_tasks
    event_map: dict[int, dict] = {}
    for event in events:
        # 确保每个事件都有 children 和 event_tasks 字段
        event["children"] = []
        # 关联当前事件的所有事件任务
        event["event_tasks"] = event_task_map.get(event["event_id"], [])

        event_map[event["event_id"]] = event

        # 将 delta_time 和 real_delta_time 的 datetime.timedelta 转换为秒
        if event["delta_time"]:
            event["delta_time"] = event["delta_time"].total_seconds()
        if event["real_delta_time"]:
            event["real_delta_time"] = event["real_delta_time"].total_seconds()

    # 5. 构建树结构
    roots = []
    for event in events:
        parent_id = event["parent_event_id"]

        # 判断是否为根节点
        if parent_id is None:
            roots.append(event)
        else:
            # 找到父事件，把当前事件加入其 children
            parent = event_map.get(parent_id)
            if parent:
                parent["children"].append(event)
            else:
                raise ValueError(
                    f"Event {event['event_id']} has invalid parent_id {parent_id}"
                )

    # 6. 对每个节点的 children 按 pre_event_id 排序（链表顺序）
    def sort_children_by_pre_id(children_list):
        if len(children_list) <= 1:
            return children_list

        # 建立 pre_event_id 到 child 的映射
        head = None
        next_map = {}
        for child in children_list:
            pre_id = child["pre_event_id"]
            if pre_id is not None:
                next_map[pre_id] = child
            else:
                head = child

        # 从头开始，按 next_map 串起来
        sorted_list = []
        current = head
        while current:
            sorted_list.append(current)
            current = next_map.get(current["event_id"])

        for child in sorted_list:
            child["children"] = sort_children_by_pre_id(child["children"])

        return sorted_list

    # 递归排序所有节点的 children
    roots = sort_children_by_pre_id(roots)

    return roots

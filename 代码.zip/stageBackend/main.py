import asyncio

import uvicorn

from app.app import app as main_app
from mcp_app.app import mcp as mcp_app


async def run_serve(app, host: str, port: int, ssl_keyfile=None, ssl_certfile=None):
    config = uvicorn.Config(
        app=app,
        host=host,
        port=port,
        ssl_keyfile=ssl_keyfile,
        ssl_certfile=ssl_certfile,
        log_level="info",
    )
    server = uvicorn.Server(config)
    await server.serve()


# 这里先保留着，不要删除，等 SSL 证书问题解决后再使用这里的代码
def main():
    # 参考 https://gofastmcp.com/integrations/fastapi 需要配置 lifespan
    # 其实不看这个文档设置 lifespan 也没关系，到时候控制台会报错提示该怎么改
    mcp_asgi_app = mcp_app.http_app()
    main_app.router.lifespan_context = mcp_asgi_app.lifespan
    main_app.mount("/mcp_server", mcp_asgi_app)
    uvicorn.run(
        main_app,
        host="0.0.0.0",
        port=8192,
        # ssl_keyfile="/etc/letsencrypt/live/www.superlivescene.com/privkey.pem",
        # ssl_certfile="/etc/letsencrypt/live/www.superlivescene.com/fullchain.pem",
    )


async def run_servers():
    mcp_asgi_app = mcp_app.http_app()
    await asyncio.gather(
        run_serve(
            main_app,
            "0.0.0.0",
            8192,
            # ssl_keyfile="/etc/letsencrypt/live/www.superlivescene.com/privkey.pem",
            # ssl_certfile="/etc/letsencrypt/live/www.superlivescene.com/fullchain.pem",
        ),
        run_serve(mcp_asgi_app, "0.0.0.0", 8193),
    )


if __name__ == "__main__":
    # main()
    asyncio.run(run_servers())

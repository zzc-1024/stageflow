from datetime import timedelta

from fastmcp import FastMCP

from database.activity.event.query import update_event
from service.activity.event.service import build_event_tree


mcp = FastMCP(name="MyAssistantServer")


# @mcp.tool()
def get_activity_events(activity_id: int) -> list:
    """
    获取活动事件列表

    参数:
    activity_id: 活动ID

    返回:
    活动事件列表
    delta_time单位为秒
    """
    return build_event_tree(activity_id)


@mcp.tool()
def set_activity_event(
    event_id: int,
    event_name: str,
    event_delta_time: int,
    real_delta_time: int | None = None,
) -> bool:
    """
    设置活动事件，设置事件时间时，用户没有提供时间时，不要修改。
    如果用户没有告诉你事件原本的信息，请先调用get_activity_events获取事件信息。

    参数:
    event_id: 事件ID
    event_name: 事件名称
    event_delta_time: 事件时间间隔，单位为秒
    real_delta_time: 事件实际时间间隔，单位为秒

    返回:
    是否设置成功
    """
    print(
        "event_id",
        event_id,
        "event_name",
        event_name,
        "event_delta_time",
        event_delta_time,
        "real_delta_time",
        real_delta_time,
    )
    if real_delta_time is not None:
        processed_real_delta_time = timedelta(seconds=real_delta_time)
    else:
        processed_real_delta_time = None
    return update_event(
        event_id,
        event_name,
        timedelta(seconds=event_delta_time),
        processed_real_delta_time,
    )

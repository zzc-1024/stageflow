from contextlib import contextmanager

from dbutils.pooled_db import PooledDB
import pymysql.cursors

pool = PooledDB(
    creator=pymysql,
    host="127.0.0.1",
    user="stage",
    password="stagepw",
    database="stagedb",
    charset="utf8mb4",
    cursorclass=pymysql.cursors.DictCursor,
    maxconnections=20,
    mincached=2,
    maxcached=5,
    maxshared=3,
    blocking=True,
    maxusage=None,
    setsession=[],
    ping=1,
)


@contextmanager
def get_db_transaction():
    conn = pool.connection()
    conn.begin()
    cursor: pymysql.cursors.DictCursor = conn.cursor()
    try:
        yield conn, cursor
        conn.commit()
    except Exception as e:
        conn.rollback()
        raise e
    finally:
        cursor.close()
        conn.close()

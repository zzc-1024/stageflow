import random
from datetime import datetime, timedelta

from ..connection import pool

# TODO: 添加验证码申请前的校验
def addVerificationCode(type: int, account: str, purpose: int, expire_time: datetime | None = None, code: str | None = None):
    connection = pool.connection()
    connection.begin()
    cursor = connection.cursor()
    if code is None:
        code = ''.join(random.choices('0123456789', k=6))
    sql = "INSERT INTO `verification_code` (`type`, `account`, `purpose`, `code`, `expired_at`, `create_at`) " \
    "VALUES (%s, %s, %s, %s, %s, %s)"

    if expire_time is None:
        expire_time = datetime.now() + timedelta(minutes=30)
    expire_time_str: str = expire_time.strftime('%Y-%m-%d %H:%M:%S')

    cursor.execute(sql, (type, account, purpose, code, expire_time_str, datetime.now().strftime('%Y-%m-%d %H:%M:%S')))
    connection.commit()

    cursor.close()
    connection.close()
    
    return code

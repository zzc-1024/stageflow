from ..connection import pool


def insert_user(username: str, email: str, password: str) -> None:
    connection = pool.connection()
    connection.begin()
    with connection.cursor() as cursor:
        # 存储密码时使用SHA-256加密
        sql = "INSERT INTO `user` (`username`, `email`, `password`) VALUES (%s, %s, %s)"
        cursor.execute(sql, (username, email, password))
    connection.commit()
    connection.close()

def select_user_by_email(email: str):
    connection = pool.connection()
    connection.begin()
    with connection.cursor() as cursor:
        sql = "SELECT user_id, password, username FROM `user` WHERE `email` = %s"
        cursor.execute(sql, (email,))
        res = cursor.fetchall()
    connection.commit()
    connection.close()
    return res

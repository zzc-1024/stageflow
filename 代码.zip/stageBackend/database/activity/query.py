from datetime import datetime

from ..connection import get_db_transaction


# 直接操作activity表的函数
def insert_activity(
    owner_user_id: int,
    activity_name: str,
    activity_start_time: datetime,
    activity_description: str,
    activity_visibility: int,
) -> int:
    with get_db_transaction() as (_, cursor):
        sql = (
            "INSERT INTO `activity` (`owner_user_id`, `activity_name`, `activity_start_time`, `activity_description`, `activity_visibility`) \
            VALUES (%s, %s, %s, %s, %s)"
        )
        cursor.execute(
            sql,
            (
                owner_user_id,
                activity_name,
                activity_start_time,
                activity_description,
                activity_visibility,
            ),
        )
        return cursor.lastrowid


def select_activity_by_id(activity_id: int) -> dict | None:
    with get_db_transaction() as (_, cursor):
        sql = (
            "SELECT owner_user_id, activity_name, activity_description, activity_start_time, real_activity_start_time, activity_status \
            FROM `activity` WHERE `activity_id` = %s"
        )
        cursor.execute(sql, (activity_id,))
        return cursor.fetchone()


def select_activities_by_owner_user_id(owner_user_id: int) -> list:
    with get_db_transaction() as (_, cursor):
        sql = (
            "SELECT activity_id, activity_name, activity_description, activity_start_time, real_activity_start_time, activity_status \
            FROM `activity` WHERE `owner_user_id` = %s"
        )
        cursor.execute(sql, (owner_user_id,))
        return list(cursor.fetchall())

def update_activity_real_activity_start_time_by_id(activity_id: int, real_activity_start_time: datetime) -> bool:
    with get_db_transaction() as (_, cursor):
        sql = """
        UPDATE `activity`
        SET `real_activity_start_time` = %s
        WHERE `activity_id` = %s
        """
        cursor.execute(sql, (real_activity_start_time, activity_id))
        return cursor.rowcount > 0


# activity_participation 表的函数
def insert_activity_participation(activity_id: int, user_email: str) -> int:
    with get_db_transaction() as (_, cursor):
        sql = """
INSERT INTO activity_participation (user_id, activity_id, username_in_activity)
SELECT u.user_id, %s AS activity_id, u.username AS username_in_activity
FROM user u
WHERE u.email = %s
    AND NOT EXISTS (
        SELECT 1
        FROM activity_participation au
        WHERE au.user_id = u.user_id
        AND au.activity_id = %s
    );"""
        cursor.execute(sql, (activity_id, user_email, activity_id))
        return cursor.lastrowid


def select_activity_participations(activity_id: int) -> list:
    with get_db_transaction() as (_, cursor):
        sql = "SELECT ap.activity_participation_id, ap.username_in_activity, u.user_id, u.username, u.email FROM user u \
            JOIN activity_participation ap ON u.user_id = ap.user_id WHERE ap.activity_id = %s"
        cursor.execute(sql, (activity_id,))
        users = cursor.fetchall()
        if not users:
            return []

        participation_ids = [row["activity_participation_id"] for row in users]

        sql_scopes = """
            SELECT 
                r.user_activity_role_id,
                r.activity_participation_id,
                s.activity_scope_id,
                s.activity_scope_symbol,
                s.activity_scope_name,
                s.activity_scope_description
            FROM user_activity_role r
            JOIN activity_scope s ON r.activity_scope_id = s.activity_scope_id
            WHERE r.activity_participation_id IN %s
        """
        # 注意：MySQL 中 IN 需要 tuple，所以转成 tuple
        cursor.execute(sql_scopes, (tuple(participation_ids),))
        scope_rows = cursor.fetchall()

        # 构建 participation_id -> scopes 列表的映射
        scope_map = {}
        for scope_row in scope_rows:
            if scope_row["activity_participation_id"] not in scope_map:
                scope_map[scope_row["activity_participation_id"]] = []
            scope_map[scope_row["activity_participation_id"]].append(scope_row)

        # 合并结果
        results = []
        for row in users:
            part_id = row["activity_participation_id"]
            results.append(
                {
                    "activity_participation_id": part_id,
                    "username_in_activity": row["username_in_activity"],
                    "user_id": row["user_id"],
                    "username": row["username"],
                    "email": row["email"],
                    "scopes": scope_map.get(part_id, []),  # 如果没有 scope，返回空列表
                }
            )

        return results


def delete_activity_participation(activity_participation_id: int) -> int:
    with get_db_transaction() as (_, cursor):
        sql = "DELETE FROM activity_participation WHERE activity_participation_id = %s"
        cursor.execute(sql, (activity_participation_id,))
        return cursor.rowcount


def select_participated_activities_by_user_id(user_id: int) -> list:
    with get_db_transaction() as (_, cursor):
        sql = (
            "SELECT a.activity_id, a.activity_name, a.activity_description, a.activity_start_time \
            FROM activity a JOIN activity_participation ap \
            ON a.activity_id = ap.activity_id WHERE ap.user_id = %s"
        )
        cursor.execute(sql, (user_id,))
        return list(cursor.fetchall())


def insert_activity_user_role(
    activity_participation_id: int, activity_scope_id: int
) -> int:
    with get_db_transaction() as (_, cursor):
        sql = "INSERT INTO user_activity_role (activity_participation_id, activity_scope_id) VALUES (%s, %s)"
        cursor.execute(sql, (activity_participation_id, activity_scope_id))
        return cursor.lastrowid


def delete_activity_user_role(user_activity_role_id: int) -> int:
    with get_db_transaction() as (_, cursor):
        sql = "DELETE FROM user_activity_role WHERE user_activity_role_id = %s"
        cursor.execute(sql, (user_activity_role_id,))
        return cursor.rowcount

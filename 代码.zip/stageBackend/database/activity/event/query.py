import datetime
from database.connection import get_db_transaction


def insert_event(
    activity_id: int,
    event_name: str,
    pre_event_id: int | None,
    parent_event_id: int | None,
    delta_time: datetime.timedelta,
) -> int:
    with get_db_transaction() as (_, cursor):
        next_event_id = None
        if not pre_event_id:
            # 如果 pre_event_id 为 None，则有两种情况
            # 可能没有下一个事件，也可能是第一个事件
            # 根据具体情况决定 next_event_id

            # 尝试获取第一个 event
            cursor.execute(
                """
                SELECT event_id FROM event WHERE activity_id = %(activity_id)s AND pre_event_id IS NULL 
                AND (parent_event_id = %(parent_event_id)s OR (parent_event_id IS NULL AND %(parent_event_id)s IS NULL))
                """,
                {"activity_id": activity_id, "parent_event_id": parent_event_id},
            )
            first_event = cursor.fetchone()
            if first_event:
                next_event_id = first_event["event_id"]
        else:
            # 如果 pre_event_id 不为 None，则下一个事件的 pre_event_id 为 pre_event_id
            cursor.execute(
                """
                SELECT event_id FROM event WHERE activity_id = %(activity_id)s AND pre_event_id = %(pre_event_id)s
                AND (parent_event_id = %(parent_event_id)s OR (parent_event_id IS NULL AND %(parent_event_id)s IS NULL))
                """,
                {
                    "activity_id": activity_id,
                    "pre_event_id": pre_event_id,
                    "parent_event_id": parent_event_id,
                },
            )
            next_event_id = cursor.fetchone()
            if next_event_id:
                next_event_id = next_event_id["event_id"]

        cursor.execute(
            """
            INSERT INTO event (activity_id, event_name, pre_event_id, next_event_id, parent_event_id, delta_time)
            VALUES (%s, %s, %s, %s, %s, %s)
            """,
            (
                activity_id,
                event_name,
                pre_event_id,
                next_event_id,
                parent_event_id,
                delta_time,
            ),
        )
        inserted_row_id = cursor.lastrowid
        if next_event_id:
            cursor.execute(
                """
                UPDATE event SET pre_event_id = %s WHERE event_id = %s
                """,
                (inserted_row_id, next_event_id),
            )
        if pre_event_id:
            cursor.execute(
                """
                UPDATE event SET next_event_id = %s WHERE event_id = %s
                """,
                (inserted_row_id, pre_event_id),
            )
        return inserted_row_id


def delete_event(event_id: int) -> bool:
    with get_db_transaction() as (_, cursor):
        # 先获取当前 event 的前后节点
        cursor.execute(
            "SELECT pre_event_id, next_event_id FROM event WHERE event_id = %s",
            (event_id,),
        )
        event = cursor.fetchone()
        if not event:
            return False
        pre_event_id, next_event_id = event["pre_event_id"], event["next_event_id"]
        if pre_event_id:
            # 更新前一个 event 的 next_event_id
            cursor.execute(
                "UPDATE event SET next_event_id = %s WHERE event_id = %s",
                (next_event_id, pre_event_id),
            )
        if next_event_id:
            # 更新后一个 event 的 pre_event_id
            cursor.execute(
                "UPDATE event SET pre_event_id = %s WHERE event_id = %s",
                (pre_event_id, next_event_id),
            )
        # 删除当前 event
        cursor.execute(
            "DELETE FROM event WHERE event_id = %s",
            (event_id,),
        )
        return cursor.rowcount > 0


def update_event(
    event_id: int,
    event_name: str,
    delta_time: datetime.timedelta,
    real_delta_time: datetime.timedelta | None,
) -> bool:
    with get_db_transaction() as (_, cursor):
        cursor.execute(
            "UPDATE event SET event_name = %s, delta_time = %s, real_delta_time = %s WHERE event_id = %s",
            (event_name, delta_time, real_delta_time, event_id),
        )
        return cursor.rowcount > 0


def update_event_real_delta_time_by_id(
    event_id: int,
    real_delta_time: datetime.timedelta | None,
) -> bool:
    with get_db_transaction() as (_, cursor):
        cursor.execute(
            "UPDATE event SET real_delta_time = %s WHERE event_id = %s",
            (real_delta_time, event_id),
        )
        return cursor.rowcount > 0


def select_event_by_activity_id(activity_id: int) -> list:
    with get_db_transaction() as (_, cursor):
        cursor.execute(
            "SELECT event_id, event_name, event_description, pre_event_id, next_event_id, parent_event_id, delta_time, real_delta_time FROM event WHERE activity_id = %s",
            (activity_id,),
        )
        return list(cursor.fetchall())

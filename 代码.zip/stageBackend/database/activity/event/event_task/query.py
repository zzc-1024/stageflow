import datetime
from database.connection import get_db_transaction


# 事件任务相关
def insert_event_task(
    activity_id: int,
    event_id: int,
    event_task_name: str,
) -> int:
    with get_db_transaction() as (_, cursor):
        sql = """
INSERT INTO event_task (activity_id, event_id, event_task_name)
VALUES (%s, %s, %s)
"""
        cursor.execute(sql, (activity_id, event_id, event_task_name))
        return cursor.lastrowid


def select_event_task_by_activity_id(activity_id: int) -> list:
    with get_db_transaction() as (_, cursor):
        sql = """
SELECT event_task_id, event_id, event_task_name, event_task_start_time FROM event_task WHERE activity_id = %s
"""
        cursor.execute(sql, (activity_id,))
        return list(cursor.fetchall())


def delete_event_task(event_task_id: int) -> int:
    with get_db_transaction() as (_, cursor):
        sql = """
DELETE FROM event_task WHERE event_task_id = %s
"""
        cursor.execute(sql, (event_task_id,))
        return cursor.rowcount


def update_event_task(event_task_id: int, event_task_name: str) -> int:
    with get_db_transaction() as (_, cursor):
        sql = """
UPDATE event_task SET event_task_name = %s WHERE event_task_id = %s
"""
        cursor.execute(sql, (event_task_name, event_task_id))
        return cursor.rowcount


def update_event_task_start_time(
    event_task_id: int, event_task_start_time: datetime.timedelta | None
) -> int:
    with get_db_transaction() as (_, cursor):
        sql = """
UPDATE event_task SET event_task_start_time = %s WHERE event_task_id = %s
"""
        cursor.execute(sql, (event_task_start_time, event_task_id))
        return cursor.rowcount


# 人员参与任务相关
def select_participation_task_by_activity_id(activity_id: int) -> list:
    with get_db_transaction() as (_, cursor):
        sql = """
SELECT pt.participation_task_id, pt.event_task_id, pt.activity_participation_id, pt.status, ap.user_id, ap.username_in_activity
    FROM participation_task pt
    JOIN activity_participation ap
    ON pt.activity_participation_id = ap.activity_participation_id
    WHERE pt.activity_id = %s
"""
        cursor.execute(sql, (activity_id,))
        return list(cursor.fetchall())


def insert_participation_task(
    activity_id: int,
    event_task_id: int,
    activity_participation_id: int,
) -> int:
    with get_db_transaction() as (_, cursor):
        sql = """
INSERT INTO participation_task (activity_id, event_task_id, activity_participation_id)
VALUES (%s, %s, %s)
"""
        cursor.execute(sql, (activity_id, event_task_id, activity_participation_id))
        return cursor.lastrowid


def delete_participation_task(participation_task_id: int) -> int:
    with get_db_transaction() as (_, cursor):
        sql = """
DELETE FROM participation_task WHERE participation_task_id = %s
"""
        cursor.execute(sql, (participation_task_id,))
        return cursor.rowcount


def update_participation_task(participation_task_id: int, status: int) -> bool:
    with get_db_transaction() as (_, cursor):
        sql = """
UPDATE participation_task SET status = %s WHERE participation_task_id = %s
"""
        cursor.execute(sql, (status, participation_task_id))
        return cursor.rowcount > 0

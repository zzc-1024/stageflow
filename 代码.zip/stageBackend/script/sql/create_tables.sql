CREATE TABLE `user` (
	`user_id` INTEGER NOT NULL AUTO_INCREMENT UNIQUE,
	`username` VARCHAR(255) NOT NULL,
	`password` VARCHAR(255) COMMENT '以后可能会通过第三方平台登录，不需要密码',
	`email` VARCHAR(255),
	`phone_number` VARCHAR(255),
	`create_at` DATETIME NOT NULL DEFAULT now(),
	`last_login` DATETIME,
	`last_verification` DATETIME NOT NULL DEFAULT '1970-01-01 00:00:01',
	`dirty` INTEGER NOT NULL DEFAULT 0 COMMENT '0表示正常
1表示用户删除
2表示账户冻结',
	PRIMARY KEY(`user_id`)
);


CREATE TABLE `verification_code` (
	`verification_code_id` INTEGER NOT NULL AUTO_INCREMENT UNIQUE,
	`type` INTEGER NOT NULL COMMENT '0万能
1邮箱
2手机号',
	`account` VARCHAR(255) NOT NULL,
	`expired_at` DATETIME NOT NULL,
	`purpose` INTEGER NOT NULL COMMENT '0表示万能验证码，用于处理扩展的业务；
1表示注册；
2表示忘记密码；',
	`is_used` INTEGER NOT NULL DEFAULT 0 COMMENT '0表示未被使用过
1表示已被使用过',
	`code` VARCHAR(255) NOT NULL,
	`create_at` DATETIME NOT NULL,
	PRIMARY KEY(`verification_code_id`, `type`, `account`)
);


CREATE TABLE `access_token` (
	`access_token_id` INTEGER NOT NULL AUTO_INCREMENT UNIQUE,
	`user_id` INTEGER NOT NULL,
	`create_at` DATETIME NOT NULL,
	`expired_at` DATETIME NOT NULL,
	`is_revoked` INTEGER NOT NULL DEFAULT 0 COMMENT '0表示未被回收
1表示用户回收
2表示系统回收',
	`token` VARCHAR(255) NOT NULL,
	PRIMARY KEY(`access_token_id`, `user_id`)
);


CREATE TABLE `scope` (
	`scope_id` INTEGER NOT NULL AUTO_INCREMENT UNIQUE,
	`scope` VARCHAR(255) NOT NULL,
	`description` VARCHAR(255),
	PRIMARY KEY(`scope_id`)
) COMMENT='这个表就不加dirty了，因为是开发者设计的，不会频繁删除，并且很容易向前兼容。';


CREATE TABLE `scope_r_access_token` (
	`scope_id` INTEGER NOT NULL UNIQUE,
	`access_token_id` INTEGER NOT NULL,
	`dirty` INTEGER NOT NULL DEFAULT 0,
	PRIMARY KEY(`scope_id`, `access_token_id`)
);


CREATE TABLE `activity` (
	`activity_id` INTEGER NOT NULL AUTO_INCREMENT UNIQUE,
	`owner_user_id` INTEGER,
	`organization_id` INTEGER,
	`activity_name` VARCHAR(255) NOT NULL,
	`activity_description` VARCHAR(255) NOT NULL,
	`activity_start_time` DATETIME NOT NULL,
	`real_activity_start_time` DATETIME,
	`activity_visibility` INTEGER NOT NULL COMMENT '0表示私有
1表示公开',
	`activity_status` INTEGER NOT NULL DEFAULT 0 COMMENT '0表示尚未完成
1表示活动结束',
	`activity_dirty` INTEGER NOT NULL DEFAULT 0 COMMENT '0表示正常
1表示被用户删除
2表示活动冻结',
	PRIMARY KEY(`activity_id`)
) COMMENT='活动表，活动可以属于组织，也可以属于个人。组织功能暂不设计。';


CREATE TABLE `user_activity_role` (
	`user_activity_role_id` INTEGER NOT NULL AUTO_INCREMENT UNIQUE,
	`activity_participation_id` INTEGER NOT NULL,
	`activity_scope_id` INTEGER NOT NULL,
	PRIMARY KEY(`user_activity_role_id`)
);


CREATE TABLE `activity_resource` (
	`activity_resource_id` INTEGER NOT NULL AUTO_INCREMENT UNIQUE,
	`activity_id` INTEGER NOT NULL,
	`resource_url` VARCHAR(255) NOT NULL,
	PRIMARY KEY(`activity_resource_id`)
);


CREATE TABLE `event` (
	`event_id` INTEGER NOT NULL AUTO_INCREMENT UNIQUE,
	`activity_id` INTEGER NOT NULL,
	`event_name` VARCHAR(255) NOT NULL,
	`event_description` VARCHAR(255),
	`parent_event_id` INTEGER,
	`pre_event_id` INTEGER,
	`next_event_id` INTEGER,
	`delta_time` TIME NOT NULL,
	`real_delta_time` TIME,
	PRIMARY KEY(`event_id`)
);


CREATE TABLE `activity_participation` (
	`activity_participation_id` INTEGER NOT NULL AUTO_INCREMENT UNIQUE,
	`activity_id` INTEGER NOT NULL,
	`user_id` INTEGER NOT NULL,
	`username_in_activity` VARCHAR(255) NOT NULL,
	PRIMARY KEY(`activity_participation_id`)
);


CREATE TABLE `event_task` (
	`event_task_id` INTEGER NOT NULL AUTO_INCREMENT UNIQUE,
	`activity_id` INTEGER NOT NULL,
	`event_id` INTEGER NOT NULL,
	`event_task_name` VARCHAR(255) NOT NULL,
	`event_task_start_time` TIME,
	PRIMARY KEY(`event_task_id`)
);


CREATE TABLE `participation_task` (
	`participation_task_id` INTEGER NOT NULL AUTO_INCREMENT UNIQUE,
	`activity_id` INTEGER NOT NULL,
	`event_task_id` INTEGER NOT NULL,
	`activity_participation_id` INTEGER NOT NULL,
	`status` INTEGER NOT NULL DEFAULT 0 COMMENT '0表示未完成
1表示完成',
	PRIMARY KEY(`participation_task_id`)
);


CREATE TABLE `activity_scope` (
	`activity_scope_id` INTEGER NOT NULL AUTO_INCREMENT UNIQUE,
	`activity_scope_symbol` VARCHAR(255) NOT NULL,
	`activity_scope_name` VARCHAR(255) NOT NULL,
	`activity_scope_description` VARCHAR(255),
	PRIMARY KEY(`activity_scope_id`)
);


ALTER TABLE `access_token`
ADD FOREIGN KEY(`user_id`) REFERENCES `user`(`user_id`)
ON UPDATE NO ACTION ON DELETE NO ACTION;
ALTER TABLE `scope_r_access_token`
ADD FOREIGN KEY(`scope_id`) REFERENCES `scope`(`scope_id`)
ON UPDATE NO ACTION ON DELETE NO ACTION;
ALTER TABLE `scope_r_access_token`
ADD FOREIGN KEY(`access_token_id`) REFERENCES `access_token`(`access_token_id`)
ON UPDATE NO ACTION ON DELETE NO ACTION;
ALTER TABLE `activity`
ADD FOREIGN KEY(`owner_user_id`) REFERENCES `user`(`user_id`)
ON UPDATE NO ACTION ON DELETE NO ACTION;
ALTER TABLE `activity_resource`
ADD FOREIGN KEY(`activity_id`) REFERENCES `activity`(`activity_id`)
ON UPDATE NO ACTION ON DELETE NO ACTION;
ALTER TABLE `event`
ADD FOREIGN KEY(`pre_event_id`) REFERENCES `event`(`event_id`)
ON UPDATE NO ACTION ON DELETE NO ACTION;
ALTER TABLE `event`
ADD FOREIGN KEY(`next_event_id`) REFERENCES `event`(`event_id`)
ON UPDATE NO ACTION ON DELETE NO ACTION;
ALTER TABLE `activity_participation`
ADD FOREIGN KEY(`activity_id`) REFERENCES `activity`(`activity_id`)
ON UPDATE NO ACTION ON DELETE NO ACTION;
ALTER TABLE `user_activity_role`
ADD FOREIGN KEY(`activity_participation_id`) REFERENCES `activity_participation`(`activity_participation_id`)
ON UPDATE NO ACTION ON DELETE NO ACTION;
ALTER TABLE `event_task`
ADD FOREIGN KEY(`event_id`) REFERENCES `event`(`event_id`)
ON UPDATE NO ACTION ON DELETE NO ACTION;
ALTER TABLE `participation_task`
ADD FOREIGN KEY(`event_task_id`) REFERENCES `event_task`(`event_task_id`)
ON UPDATE NO ACTION ON DELETE NO ACTION;
ALTER TABLE `participation_task`
ADD FOREIGN KEY(`activity_participation_id`) REFERENCES `activity_participation`(`activity_participation_id`)
ON UPDATE NO ACTION ON DELETE NO ACTION;
ALTER TABLE `event`
ADD FOREIGN KEY(`parent_event_id`) REFERENCES `event`(`event_id`)
ON UPDATE NO ACTION ON DELETE NO ACTION;
ALTER TABLE `event`
ADD FOREIGN KEY(`activity_id`) REFERENCES `activity`(`activity_id`)
ON UPDATE NO ACTION ON DELETE NO ACTION;
ALTER TABLE `activity_participation`
ADD FOREIGN KEY(`user_id`) REFERENCES `user`(`user_id`)
ON UPDATE NO ACTION ON DELETE NO ACTION;
ALTER TABLE `user_activity_role`
ADD FOREIGN KEY(`activity_scope_id`) REFERENCES `activity_scope`(`activity_scope_id`)
ON UPDATE NO ACTION ON DELETE NO ACTION;
ALTER TABLE `participation_task`
ADD FOREIGN KEY(`activity_id`) REFERENCES `activity`(`activity_id`)
ON UPDATE NO ACTION ON DELETE NO ACTION;
ALTER TABLE `event_task`
ADD FOREIGN KEY(`activity_id`) REFERENCES `activity`(`activity_id`)
ON UPDATE NO ACTION ON DELETE NO ACTION;
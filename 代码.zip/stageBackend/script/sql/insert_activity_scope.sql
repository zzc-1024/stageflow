INSERT INTO `activity_scope` (`activity_scope_id`, `activity_scope_symbol`, `activity_scope_name`, `activity_scope_description`) VALUES
	(1, 'admin', '管理员权限', '管理员可以执行除了转让和删除活动之外的任何操作');

from datetime import datetime
from pydantic import BaseModel


class StartControl(BaseModel):
    real_activity_start_time: datetime

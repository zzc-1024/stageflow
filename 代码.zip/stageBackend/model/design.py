from pydantic import BaseModel


class PhaseDesign(BaseModel):
    phase_id: int | None = None
    phase_name: str | None = None

class ProgramItem(BaseModel):
    phase_id: int | None = None
    program_item_id: int | None = None
    program_item_name: str | None = None

class Show(BaseModel):
    program_item_id: int | None = None
    show_id: int | None = None
    show_name: str | None = None
    delta_time: str | None = None
    real_delta_time: str | None = None

class ShowTask(BaseModel):
    show_task_id: int | None = None
    show_id: int | None = None
    show_task_name: str | None = None

class ShowTaskActivityUser(BaseModel):
    show_task_activity_user_id: int | None = None
    show_task_id: int | None = None
    activity_user_id: int | None = None
    status: int | None = None  # 0: 未完成, 1: 已完成

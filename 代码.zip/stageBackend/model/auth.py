from pydantic import BaseModel


class JWTData(BaseModel):
    user_id: int
    username: str
    email: str
    exp: int


from abc import ABC, abstractmethod

from fastapi import UploadFile


class TemplateExcelPlugin(ABC):
    @abstractmethod
    def parse(self, file: UploadFile) -> list:
        pass

import datetime
import re

import openpyxl
from fastapi import UploadFile

from .template import TemplateExcelPlugin


def parse_duration(duration_val):
    if duration_val is None:
        return None

    # datetime.time
    if isinstance(duration_val, datetime.time):
        return duration_val.hour * 3600 + duration_val.minute * 60 + duration_val.second
    # float
    if isinstance(duration_val, (int, float)):
        total_seconds = int(duration_val * 24 * 3600)
        return total_seconds
    # 字符串
    if isinstance(duration_val, str):
        duration_str = duration_val.strip()
        if not duration_str:
            return None
        try:
            parts = list(map(int, duration_str.split(':')))
            if len(parts) == 2:
                m, s = parts
                return m * 60 + s
            elif len(parts) == 3:
                h, m, s = parts
                return h * 3600 + m * 60 + s
            else:
                return None
        except Exception:
            return None

    return None


def get_cell_value_with_merge(ws, row, col):
    cell = ws.cell(row=row, column=col)
    for merged_range in ws.merged_cells.ranges:
        if cell.coordinate in merged_range:
            return merged_range.start_cell.value
    return cell.value


def build_dynamic_headers(ws):
    max_col = ws.max_column
    headers = []
    main_title = None
    for col in range(1, max_col + 1):
        top = get_cell_value_with_merge(ws, 2, col)
        sub = get_cell_value_with_merge(ws, 3, col)
        top = str(top).strip() if top else ""
        sub = str(sub).strip() if sub else ""
        if top:
            main_title = top
        if sub:
            full = f"{main_title} / {sub}" if main_title and main_title != sub else sub
        else:
            full = main_title if main_title else ""
        headers.append(full)
    return headers


# 父节点判断，part
def is_header_row(ws, row):
    max_col = ws.max_column
    values = []
    for col in range(1, max_col + 1):
        val = get_cell_value_with_merge(ws, row, col)
        if val is not None and str(val).strip() != "":
            values.append(str(val).strip())
    if not values:
        return False

    if len(set(values)) != 1:
        return False

    candidate = values[0]
    if re.match(r"^\d+$", candidate):
        return False
    if re.match(r"^\d{1,2}:\d{2}(:\d{2})?$", candidate):
        return False
    return True


def is_subsong_row(ws, row):
    seq = get_cell_value_with_merge(ws, row, 1)
    event = get_cell_value_with_merge(ws, row, 5)
    return (
        (seq is None or str(seq).strip() == "") and event and str(event).strip() != ""
    )


def extract_event_tasks(ws, row, dynamic_headers):
    tasks = []
    for col_idx in range(5, len(dynamic_headers)):
        val = get_cell_value_with_merge(ws, row, col_idx + 1)
        header_name = dynamic_headers[col_idx]
        if val and str(val).strip() and header_name:
            tasks.append({"event_task_name": f"{header_name}: {str(val).strip()}"})
    return tasks


# 判断是否有值
def is_event_row(ws, row):
    duration = get_cell_value_with_merge(ws, row, 3)
    return duration is not None and str(duration).strip() != ""


def parse_excel_to_json(file: UploadFile):
    wb = openpyxl.load_workbook(file.file)
    ws = wb.active
    if ws is None:
        return None
    dynamic_headers = build_dynamic_headers(ws)

    result = []
    current_parent = None
    current_mid_parent = None
    # 容器标记
    clear_mid_parent_after_next_row = False
    row = 4
    max_row = ws.max_row

    while row <= max_row:
        event_name = get_cell_value_with_merge(ws, row, 5)
        duration_val = get_cell_value_with_merge(ws, row, 3)

        if is_header_row(ws, row):
            current_parent = {
                "event_name": str(event_name).strip(),
                "event_description": None,
                "delta_time": None,
                "children": [],
                "event_tasks": [],
            }
            result.append(current_parent)
            current_mid_parent = None
            clear_mid_parent_after_next_row = False  # 重置
            row += 1
            continue

        if not event_name or str(event_name).strip() == "":
            row += 1
            continue

        event_name_str = str(event_name).strip()

        # 容器节点，无时长
        if event_name_str.startswith("幕间剧情") or event_name_str.startswith(
            "剧情舞蹈秀"
        ):
            current_mid_parent = {
                "event_name": event_name_str,
                "event_description": None,
                "delta_time": None,
                "children": [],
                "event_tasks": extract_event_tasks(ws, row, dynamic_headers),
            }
            if current_parent:
                current_parent["children"].append(current_mid_parent)
            else:
                result.append(current_mid_parent)
            clear_mid_parent_after_next_row = True
            row += 1
            continue

        if is_subsong_row(ws, row):
            clean_name = re.split(r"[（(（【\s]\d", event_name_str)[0].strip()
            song = {
                "event_name": clean_name,
                "event_description": None,
                "delta_time": None,
                "children": [],
                "event_tasks": [],
            }
            if current_mid_parent:
                current_mid_parent["children"].append(song)
            elif current_parent:
                current_parent["children"].append(song)
            else:
                result.append(song)
            # 标记清空
            if clear_mid_parent_after_next_row:
                current_mid_parent = None
                clear_mid_parent_after_next_row = False
            row += 1
            continue
        if is_event_row(ws, row):
            node = {
                "event_name": event_name_str,
                "event_description": None,
                "delta_time": parse_duration(duration_val),
                "children": [],
                "event_tasks": extract_event_tasks(ws, row, dynamic_headers),
            }
        else:
            node = {
                "event_name": event_name_str,
                "event_description": None,
                "delta_time": None,
                "children": [],
                "event_tasks": extract_event_tasks(ws, row, dynamic_headers),
            }

        if current_mid_parent:
            current_mid_parent["children"].append(node)
        elif current_parent:
            current_parent["children"].append(node)
        else:
            result.append(node)

        # 清空
        if clear_mid_parent_after_next_row:
            current_mid_parent = None
            clear_mid_parent_after_next_row = False

        row += 1

    return result


class ExcelPlugin(TemplateExcelPlugin):
    def parse(self, file: UploadFile) -> list:
        parsed = parse_excel_to_json(file)
        if parsed is None:
            return []
        return parsed

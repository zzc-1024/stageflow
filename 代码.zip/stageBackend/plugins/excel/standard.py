from fastapi import UploadFile

from .template import TemplateExcelPlugin


class ExcelPlugin(TemplateExcelPlugin):
    def parse(self, file: UploadFile) -> list:
        return []

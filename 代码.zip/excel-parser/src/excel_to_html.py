import os
from parseExcel import to_html

class ExcelToHTML:
    def __init__(self, excel_folder, html_folder):
        self.excel_folder = excel_folder  # Excel文件夹路径
        self.html_folder = html_folder  # HTML输出文件夹路径
        
        # 确保输出文件夹存在
        os.makedirs(self.html_folder, exist_ok=True)
    
    def convert_all(self):
        """
        转换所有Excel文件为HTML
        """
        # 获取所有Excel文件
        excel_files = self._get_excel_files()
        
        for excel_file in excel_files:
            print(f'正在转换 {excel_file}...')
            
            # 生成HTML文件路径
            html_file = os.path.join(self.html_folder, f'{os.path.splitext(os.path.basename(excel_file))[0]}.html')
            
            # 转换Excel为HTML
            self._convert_single(excel_file, html_file)
    
    def _get_excel_files(self):
        """
        获取所有Excel文件，过滤掉临时文件
        """
        excel_files = []
        for file in os.listdir(self.excel_folder):
            # 过滤掉以~$开头的临时文件
            if file.startswith('~$'):
                continue
            
            # 只处理Excel文件
            if file.endswith('.xlsx') or file.endswith('.xls'):
                excel_files.append(os.path.join(self.excel_folder, file))
        
        return excel_files
    
    def _convert_single(self, excel_file, html_file):
        """
        转换单个Excel文件为HTML
        """
        converter = to_html(excel_file, html_file)
        converter.creat_html()


if __name__ == "__main__":
    # 示例用法
    excel_folder = '../excel'
    html_folder = '../output/html'
    
    converter = ExcelToHTML(excel_folder, html_folder)
    converter.convert_all()
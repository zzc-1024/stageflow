import os
import json
from bs4 import BeautifulSoup
from chat import chat

class HTMLAnalyzer:
    def __init__(self, html_folder, intermediate_folder):
        self.html_folder = html_folder  # HTML文件夹路径
        self.intermediate_folder = intermediate_folder  # 中间过程输出文件夹路径
        
        # 确保输出文件夹存在
        os.makedirs(self.intermediate_folder, exist_ok=True)
    
    def analyze_all(self):
        """
        分析所有HTML文件
        """
        # 获取所有HTML文件
        html_files = self._get_html_files()
        
        for html_file in html_files:
            print(f'正在分析 {html_file}...')
            
            # 生成中间过程文件路径
            intermediate_file = os.path.join(self.intermediate_folder, f'{os.path.splitext(os.path.basename(html_file))[0]}.json')
            
            # 分析HTML并生成中间过程
            self._analyze_single(html_file, intermediate_file)
    
    def _get_html_files(self):
        """
        获取所有HTML文件
        """
        html_files = []
        for file in os.listdir(self.html_folder):
            if file.endswith('.html'):
                html_files.append(os.path.join(self.html_folder, file))
        
        return html_files
    
    def _analyze_single(self, html_file, intermediate_file):
        """
        分析单个HTML文件并生成中间过程
        """
        # 读取HTML文件
        with open(html_file, 'r', encoding='utf-8') as f:
            html_content = f.read()
        
        # 解析HTML
        soup = BeautifulSoup(html_content, 'html.parser')
        table = soup.find('table')
        rows = table.find_all('tr')
        
        # 提取表头信息
        headers = self._extract_headers(rows)
        
        # 调用AI分析表头
        column_meanings = self._analyze_with_ai(headers)
        
        # 生成中间过程文件
        self._save_intermediate(intermediate_file, column_meanings)
    
    def _extract_headers(self, rows):
        """
        提取表头信息
        """
        headers = []
        
        # 假设前3行是表头
        for i in range(min(3, len(rows))):
            row = rows[i]
            cells = row.find_all('td')
            
            row_headers = []
            for cell in cells:
                colspan = int(cell.get('colspan', 1))
                rowspan = int(cell.get('rowspan', 1))
                text = cell.text.strip()
                
                row_headers.append({
                    'text': text,
                    'colspan': colspan,
                    'rowspan': rowspan
                })
            
            headers.append(row_headers)
        
        return headers
    
    def _analyze_with_ai(self, headers):
        """
        调用AI分析表头
        """
        # 构建表头文本
        headers_text = []
        for i, row in enumerate(headers):
            row_text = []
            for j, cell in enumerate(row):
                row_text.append(f"列{j+1}: {cell['text']} (colspan={cell['colspan']}, rowspan={cell['rowspan']})")
            headers_text.append(f"第{i+1}行表头: {'; '.join(row_text)}")
        
        headers_text = '\n'.join(headers_text)
        
        # 构建prompt
        prompt = f"""
        请分析以下表格表头，确定：
        1. 哪一列是delta_time（时长，单位秒）
        2. 哪一列是event_name（事件名称）
        3. 哪些列是event_task_name需要的列（用于生成任务名称的列，应该包含所有可能用于描述任务的列）
        
        表格表头：
        {headers_text}
        
        请以JSON格式输出，包含以下字段：
        - delta_time_column: 时长所在的列索引（从1开始），如果没有则为null
        - event_name_column: 事件名称所在的列索引（从1开始），如果没有则为null
        - task_columns: 任务名称需要的列索引列表（从1开始），应该包含所有可能用于描述任务的列，包括但不限于节目名、歌曲、表演形式、人员等
        
        示例输出：
        {{"delta_time_column": 3, "event_name_column": 5, "task_columns": [6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17]}}
        """
        
        # 调用AI
        messages = [
            {"role": "user", "content": prompt}
        ]
        
        try:
            response = chat(messages)
            # 解析AI的响应
            column_meanings = json.loads(response)
            return column_meanings
        except Exception as e:
            print(f"AI分析失败：{e}")
            # 如果AI分析失败，使用默认值
            return {
                "delta_time_column": None,
                "event_name_column": None,
                "task_columns": []
            }
    
    def _save_intermediate(self, intermediate_file, column_meanings):
        """
        保存中间过程文件
        """
        with open(intermediate_file, 'w', encoding='utf-8') as f:
            json.dump(column_meanings, f, ensure_ascii=False, indent=2)


if __name__ == "__main__":
    # 示例用法
    html_folder = '../output/html'
    intermediate_folder = '../output/intermediate'
    
    analyzer = HTMLAnalyzer(html_folder, intermediate_folder)
    analyzer.analyze_all()
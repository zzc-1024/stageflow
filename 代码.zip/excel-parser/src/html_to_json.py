import os
import json
from bs4 import BeautifulSoup

class HTMLToJSON:
    def __init__(self, html_folder, intermediate_folder, json_folder):
        self.html_folder = html_folder  # HTML文件夹路径
        self.intermediate_folder = intermediate_folder  # 中间过程文件夹路径
        self.json_folder = json_folder  # 最终JSON输出文件夹路径
        
        # 确保输出文件夹存在
        os.makedirs(self.json_folder, exist_ok=True)
    
    def convert_all(self):
        """
        转换所有HTML文件为JSON
        """
        # 获取所有HTML文件
        html_files = self._get_html_files()
        
        for html_file in html_files:
            print(f'正在转换 {html_file}...')
            
            # 生成中间过程文件路径
            intermediate_file = os.path.join(self.intermediate_folder, f'{os.path.splitext(os.path.basename(html_file))[0]}.json')
            
            # 生成最终JSON文件路径
            json_file = os.path.join(self.json_folder, f'{os.path.splitext(os.path.basename(html_file))[0]}.json')
            
            # 转换HTML为JSON
            self._convert_single(html_file, intermediate_file, json_file)
    
    def _get_html_files(self):
        """
        获取所有HTML文件
        """
        html_files = []
        for file in os.listdir(self.html_folder):
            if file.endswith('.html'):
                html_files.append(os.path.join(self.html_folder, file))
        
        return html_files
    
    def _convert_single(self, html_file, intermediate_file, json_file):
        """
        转换单个HTML文件为JSON
        """
        # 读取HTML文件
        with open(html_file, 'r', encoding='utf-8') as f:
            html_content = f.read()
        
        # 读取中间过程文件
        with open(intermediate_file, 'r', encoding='utf-8') as f:
            column_meanings = json.load(f)
        
        # 解析HTML
        soup = BeautifulSoup(html_content, 'html.parser')
        table = soup.find('table')
        rows = table.find_all('tr')
        
        # 提取表头列名
        headers = []
        if rows:
            header_cells = rows[0].find_all('td')
            for cell in header_cells:
                headers.append(cell.text.strip())
        
        # 处理表格行，生成JSON
        events = self._process_rows(rows, column_meanings, headers)
        
        # 保存最终JSON文件
        self._save_json(json_file, events)
    
    def _process_rows(self, rows, column_meanings, headers):
        """
        处理表格行，生成JSON
        """
        events = []
        current_parent = None
        
        # 跳过表头行，从第4行开始处理数据
        data_rows = rows[3:]
        
        # 检查是否是解析困难的表格
        if self._is_difficult_table(data_rows):
            print("检测到解析困难的表格，放弃处理")
            return events
        
        i = 0
        while i < len(data_rows):
            row = data_rows[i]
            cells = row.find_all('td')
            
            # 检查是否是合并行（标题行）
            is_title_row = self._is_title_row(cells)
            
            if is_title_row:
                # 这是一个标题行，创建一个新的父事件
                event_name = cells[0].text.strip()
                
                if event_name:
                    # 非叶子节点，delta_time为null
                    event = {
                        'event_name': event_name,
                        'event_description': None,
                        'delta_time': None,
                        'children': [],
                        'event_tasks': []
                    }
                    
                    events.append(event)
                    current_parent = event
            else:
                # 这是一个数据行，创建一个新的事件
                event = self._create_event(cells, column_meanings, headers)
                
                # 如果有父事件，将其添加到父事件的children中
                if current_parent:
                    current_parent['children'].append(event)
                else:
                    events.append(event)
            
            i += 1
        
        # 过滤空事件并确保叶子/非叶子节点规则
        events = self._filter_empty_events(events)
        
        return events
    
    def _get_merged_cells(self, rows):
        """
        获取合并单元格的映射
        """
        merged_cells = []
        
        for row_index, row in enumerate(rows):
            cells = row.find_all('td')
            
            for cell_index, cell in enumerate(cells):
                rowspan = int(cell.get('rowspan', 1))
                colspan = int(cell.get('colspan', 1))
                
                if rowspan > 1 or colspan > 1:
                    merged_cells.append({
                        'row_index': row_index,
                        'cell_index': cell_index,
                        'rowspan': rowspan,
                        'colspan': colspan,
                        'text': cell.text.strip()
                    })
        
        return merged_cells
    
    def _is_difficult_table(self, data_rows):
        """
        检测是否是难以解析的表格
        """
        # 检查数据行数量是否过少
        if len(data_rows) < 2:
            return True
        
        # 检查是否有大量合并单元格
        merged_cell_count = 0
        total_cell_count = 0
        
        for row in data_rows:
            cells = row.find_all('td')
            total_cell_count += len(cells)
            
            for cell in cells:
                colspan = int(cell.get('colspan', 1))
                rowspan = int(cell.get('rowspan', 1))
                if colspan > 1 or rowspan > 1:
                    merged_cell_count += 1
        
        # 如果合并单元格比例超过50%，认为是难以解析的表格
        if total_cell_count > 0 and merged_cell_count / total_cell_count > 0.5:
            return True
        
        return False
    
    def _is_title_row(self, cells):
        """
        判断是否是标题行
        """
        if not cells:
            return False
        
        # 检查第一个单元格是否合并了多列
        colspan = int(cells[0].get('colspan', 1))
        return colspan > 1
    
    def _create_event(self, cells, column_meanings, headers):
        """
        创建事件，正确处理colspan，并拼接列名生成任务名称
        """
        # 获取列含义
        delta_time_col = column_meanings.get('delta_time_column')
        event_name_col = column_meanings.get('event_name_column')
        task_columns = column_meanings.get('task_columns', [])
        
        # 计算实际列索引，考虑colspan
        actual_columns = []
        current_col = 0
        
        for cell in cells:
            colspan = int(cell.get('colspan', 1))
            # 记录该单元格覆盖的所有列
            for _ in range(colspan):
                actual_columns.append(cell)
            current_col += colspan
        
        # 提取event_name
        event_name = ''
        if event_name_col is not None:
            event_name_col_index = event_name_col - 1
            if event_name_col_index < len(actual_columns):
                event_name = actual_columns[event_name_col_index].text.strip()
        
        # 如果event_name为空，尝试使用第一列
        if not event_name and actual_columns:
            event_name = actual_columns[0].text.strip()
        
        # 提取delta_time
        delta_time = None
        if delta_time_col is not None:
            delta_time_col_index = delta_time_col - 1
            if delta_time_col_index < len(actual_columns):
                delta_time_str = actual_columns[delta_time_col_index].text.strip()
                delta_time = self._parse_duration(delta_time_str)
        
        # 提取event_tasks，拼接列名
        event_tasks = []
        task_texts = []
        for task_col in task_columns:
            task_col_index = task_col - 1
            if task_col_index < len(actual_columns) and task_col_index < len(headers):
                column_name = headers[task_col_index]
                task_text = actual_columns[task_col_index].text.strip()
                if task_text:
                    # 拼接列名和任务文本
                    full_task_name = f"{column_name}: {task_text}"
                    task_texts.append(full_task_name)
                    event_tasks.append({
                        'event_task_name': full_task_name,
                        'event_task_start_time': ''
                    })
        
        # 如果有任务，调用大模型判断每个任务的开始时间
        if event_tasks:
            from chat import chat
            import json
            
            # 构建prompt
            prompt = f"""
            请分析以下事件和它的任务列表，为每个任务判断它是当前事件的几分几秒的时候开始的，并以JSON格式输出结果。
            
            事件名称：{event_name}
            事件时长：{delta_time_str if delta_time is not None else '未知'}
            任务列表：
            {chr(10).join([f"{i+1}. {task['event_task_name']}" for i, task in enumerate(event_tasks)])}
            
            请以JSON格式输出，包含一个tasks数组，每个元素包含task_index（任务索引，从0开始）和start_time（任务开始时间，格式为mm:ss）。
            
            示例输出：
            {{
                "tasks": [
                    {{"task_index": 0, "start_time": "00:00"}},
                    {{"task_index": 1, "start_time": "00:15"}},
                    {{"task_index": 2, "start_time": "01:30"}}
                ]
            }}
            """
            
            # 调用大模型
            try:
                response = chat([{"role": "user", "content": prompt}])
                # 解析大模型的响应
                result = json.loads(response)
                tasks = result.get('tasks', [])
                
                # 更新每个任务的开始时间
                for task_info in tasks:
                    task_index = task_info.get('task_index', -1)
                    start_time = task_info.get('start_time', '')
                    if 0 <= task_index < len(event_tasks):
                        event_tasks[task_index]['event_task_start_time'] = start_time
            except Exception as e:
                print(f"大模型分析任务开始时间失败：{e}")
        
        # 创建事件
        event = {
            'event_name': event_name,
            'event_description': None,
            'delta_time': delta_time,
            'children': [],
            'event_tasks': event_tasks
        }
        
        return event
    
    def _parse_duration(self, duration_str):
        """
        解析时长，转换为秒
        """
        if not duration_str:
            return None
        
        try:
            # 格式：00:02:01
            parts = duration_str.split(':')
            if len(parts) == 3:
                hours, minutes, seconds = map(int, parts)
                return hours * 3600 + minutes * 60 + seconds
            elif len(parts) == 2:
                minutes, seconds = map(int, parts)
                return minutes * 60 + seconds
            else:
                # 尝试直接转换为秒
                return int(duration_str)
        except:
            return None
    
    def _filter_empty_events(self, events):
        """
        过滤空事件
        """
        filtered_events = []
        
        for event in events:
            # 检查是否为空事件
            if not event['event_name'] and not event['children'] and not event['event_tasks']:
                continue
            
            # 过滤子事件中的空事件
            if event['children']:
                event['children'] = self._filter_empty_events(event['children'])
                
                # 如果有子节点，那么它是非叶子节点，delta_time应该为null
                event['delta_time'] = None
            else:
                # 如果没有子节点，那么它是叶子节点，delta_time不应该为null
                if event['delta_time'] is None:
                    event['delta_time'] = 0
            
            filtered_events.append(event)
        
        return filtered_events
    
    def _save_json(self, json_file, events):
        """
        保存最终JSON文件
        """
        with open(json_file, 'w', encoding='utf-8') as f:
            json.dump(events, f, ensure_ascii=False, indent=2)


if __name__ == "__main__":
    # 示例用法
    html_folder = '../output/html'
    intermediate_folder = '../output/intermediate'
    json_folder = '../output/json'
    
    converter = HTMLToJSON(html_folder, intermediate_folder, json_folder)
    converter.convert_all()
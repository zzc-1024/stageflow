import os
from excel_to_html import ExcelToHTML
from html_analyzer import HTMLAnalyzer
from html_to_json import HTMLToJSON

class ExcelParser:
    def __init__(self, excel_folder, output_folder):
        self.excel_folder = excel_folder
        self.output_folder = output_folder
        self.html_folder = os.path.join(self.output_folder, 'html')
        self.intermediate_folder = os.path.join(self.output_folder, 'intermediate')
        self.json_folder = os.path.join(self.output_folder, 'json')
        os.makedirs(self.html_folder, exist_ok=True)
        os.makedirs(self.intermediate_folder, exist_ok=True)
        os.makedirs(self.json_folder, exist_ok=True)
    
    def run(self):
        print("开始执行Excel解析流程...")
        
        # 第一步：Excel转HTML
        print("\n1. 正在将Excel转换为HTML...")
        excel_to_html = ExcelToHTML(self.excel_folder, self.html_folder)
        excel_to_html.convert_all()
        
        # 第二步：AI生成中间过程
        print("\n2. 正在分析HTML并生成中间过程...")
        html_analyzer = HTMLAnalyzer(self.html_folder, self.intermediate_folder)
        html_analyzer.analyze_all()
        
        # 第三步：HTML转JSON
        print("\n3. 正在将HTML转换为JSON...")
        html_to_json = HTMLToJSON(self.html_folder, self.intermediate_folder, self.json_folder)
        html_to_json.convert_all()
        
        print("\nExcel解析流程执行完成！")

if __name__ == "__main__":
    # 获取当前脚本所在目录
    current_dir = os.path.dirname(os.path.abspath(__file__))
    # 构建正确的路径
    excel_folder = os.path.join(current_dir, '../excel')
    output_folder = os.path.join(current_dir, '../output')
    parser = ExcelParser(excel_folder, output_folder)
    parser.run()
from chat import chat
from parseExcel import to_html

if __name__ == "__main__":
    sample_excel = to_html("excel/【北京】周笔畅演唱会RD1024.xlsx", "合并单元格.html")
    sample_html = sample_excel.creat_html()
    with open("示例输出.json", "r", encoding="utf-8") as f:
        sample_output = f.read()
    prompt = f"""
    # 任务描述
    你是一个专业的HTML解析器，你的任务是解析HTML代码并提取其中的数据。

    # 示例输入
    {sample_html}

    # 示例输出
    {sample_output}

    """
    input_excel = to_html("excel/新测试表格.xlsx", "合并单元格.html")
    prompt += f"""
    # 用户输入
    {input_excel.creat_html()}
    """
    # 输出JSON格式
    output_json = chat([{"role": "user", "content": prompt}])
    with open("输出.json", "w", encoding="utf-8") as f:
        f.write(output_json)

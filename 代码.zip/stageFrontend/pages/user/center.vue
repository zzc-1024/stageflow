<template>
	<block v-if="username">
		<text class="username">欢迎您，{{ username }}</text>
		<!-- <view class="content">这里什么也没有</view> -->
		<button class="logout-button" @click="logout" type="warn">退出登录</button>
	</block>
	<block v-else>
		<button class="login-button" @click="onLoginClick" type="primary">点击登录</button>
	</block>
</template>

<script setup>
	import {
		ref
	} from 'vue'
	import {
		onShow
	} from '@dcloudio/uni-app'

	const username = ref('')

	onShow(() => {
		username.value = uni.getStorageSync('username') || ''
	})

	function onLoginClick() {
		uni.navigateTo({
			url: '/pages/auth/Login'
		})
	}

	function logout() {
		uni.removeStorageSync('user_id')
		uni.removeStorageSync('token')
		uni.removeStorageSync('username')
		uni.removeStorageSync('email')
		username.value = ''
		uni.showToast({
			title: '已退出登录',
			icon: 'none'
		})
	}
</script>

<style>
</style>
<template>
  <view class="container">
    <!-- 头像区域 -->
    <view class="avatar-section">
      <image class="avatar" src="https://q1.qlogo.cn/g?b=qq&nk=123456789&s=100"></image>
      <text class="username">johndoe123</text>
    </view>

    <!-- 个人信息区域 -->
    <view class="info-container">
      <!-- 基础信息卡片 -->
      <view class="info-card">
        <view class="info-item">
          <text class="label">真实姓名</text>
          <text class="value">张三</text>
        </view>
        <view class="info-item">
          <text class="label">性别</text>
          <text class="value">男</text>
        </view>
        <view class="info-item">
          <text class="label">生日</text>
          <text class="value">1990-01-15</text>
        </view>
        <view class="info-item">
          <text class="label">所在地</text>
          <text class="value">北京市</text>
        </view>
        <view class="info-item">
          <text class="label">工作</text>
          <text class="value">软件工程师</text>
        </view>
      </view>

      <!-- 账号信息卡片 -->
      <view class="info-card">
        <view class="info-item" @click="navigateToChangeEmail">
          <text class="label">已绑定邮箱</text>
          <view class="value-wrap">
            <text class="value">old@example.com</text>
            <text class="edit-icon">→</text>
          </view>
        </view>
        <view class="info-item">
          <text class="label">手机号</text>
          <text class="value">138****5678</text>
        </view>
        <view class="info-item">
          <text class="label">微信号</text>
          <text class="value">wechat12345</text>
        </view>
      </view>

      <!-- 操作按钮 -->
      <button class="action-btn" @click="navigateToChangePassword">
        更改密码
      </button>
    </view>
  </view>
</template>

<script setup>
const navigateToChangePassword = () => {
  uni.navigateTo({ url: '/pages/auth/ChangePassword' });
};

const navigateToChangeEmail = () => {
  uni.navigateTo({ url: '/pages/auth/ChangeEmail' });
};
</script>

<style scoped>
/* 基础容器 */
.container {
  padding: 20px;
  background-color: #f5f7fa;
  min-height: 100vh;
}

/* 头像区域 */
.avatar-section {
  display: flex;
  flex-direction: column;
  align-items: center;
  margin-bottom: 30px;
  padding: 20px 0;
}

.avatar {
  width: 100px;
  height: 100px;
  border-radius: 50%;
  border: 3px solid white;
  box-shadow: 0 4px 12px rgba(0,0,0,0.08);
  margin-bottom: 15px;
  object-fit: cover;
}

.username {
  font-size: 18px;
  font-weight: 600;
  color: #2c3e50;
  letter-spacing: 0.3px;
}

/* 信息容器 */
.info-container {
  gap: 15px;
  display: flex;
  flex-direction: column;
}

/* 信息卡片 */
.info-card {
  background: white;
  border-radius: 12px;
  box-shadow: 0 2px 10px rgba(0,0,0,0.05);
  overflow: hidden;
}

/* 信息项 */
.info-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 15px 20px;
  border-bottom: 1px solid #f5f5f5;
}

.info-item:last-child {
  border-bottom: none;
}

.info-item:active {
  background-color: #f8f9fa;
}

.label {
  font-size: 15px;
  color: #6c757d;
  font-weight: 500;
}

.value-wrap {
  display: flex;
  align-items: center;
}

.value {
  font-size: 15px;
  color: #2c3e50;
  text-align: right;
}

.edit-icon {
  color: #999;
  font-size: 16px;
  margin-left: 8px;
}

/* 操作按钮 */
.action-btn {
  width: 100%;
  height: 48px;
  background-color: #007bff;
  color: white;
  border: none;
  border-radius: 12px;
  font-size: 16px;
  font-weight: 500;
  margin-top: 5px;
  transition: all 0.2s ease;
}

.action-btn:active {
  background-color: #0069d9;
}
</style>
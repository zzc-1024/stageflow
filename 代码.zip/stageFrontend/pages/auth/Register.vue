<template>
	<div class="container">
		<h2 class="title">注册</h2>
		<input class="input" type="username" placeholder="用户名" v-model="username" />
		<input class="input" type="email" placeholder="邮箱" v-model="email" />
		<input class="input" type="password" placeholder="密码" v-model="password" />
		<input class="input" type="password" placeholder="确认密码" v-model="confirmPassword" />
		<div class="verification" v-if="false">
			<input class="input" placeholder="验证码" v-model="code" />
			<button class="send-button" @click="sendCode">发送</button>
		</div>
		<div class="actions">
			<a @click="onLogin">登录</a>
			<a @click="onForgetPasswordClick">忘记密码？</a>
		</div>
		<button class="button" @click="onRegister">点击注册</button>
	</div>
</template>

<script setup>
	import {
		ref
	} from 'vue'

	import {
		register
	} from '../../api/auth'

	const username = ref('')
	const email = ref('')
	const password = ref('')
	const confirmPassword = ref('')
	const code = ref('1234')

	function onLogin() {
		uni.navigateTo({
			url: '/pages/auth/Login'
		});
	}

	function onForgetPasswordClick() {
		uni.navigateTo({
			url: '/pages/auth/ForgetPassword'
		});
	}

	function sendCode() {
		//验证码先空着，点击则直接设置为zjbwy
		code.value = 'zjbwy'
		uni.showToast({
			title: '验证码已发送',
			icon: 'none'
		})
	}

	async function onRegister() {
		if (username.value.indexOf(' ') !== -1 || email.value.indexOf(' ') !== -1) {
			uni.showToast({
				title: '用户名和邮箱不能有空格',
				icon: 'error'
			})
			return
		}
		if (!email.value.trim() || !password.value || !confirmPassword.value || !code.value.trim()) {
			uni.showToast({
				title: '请填写完整信息',
				icon: 'none'
			})
			return
		}
		if (password.value !== confirmPassword.value) {
			uni.showToast({
				title: '两次密码不一致',
				icon: 'none'
			})
			return
		}

		register(username.value, email.value, password.value).then(res => {
			if (res['code'] !== 0) {
				uni.showToast({
					title: res['message'],
					icon: 'error'
				})
				return
			}
			console.log(res)
			uni.showToast({
				title: '注册成功',
				icon: 'none'
			})
			uni.redirectTo({
				url: '/pages/auth/Login'
			})
		}).catch(err => {
			uni.showToast({
				title: '服务器异常',
				icon: 'error'
			})
			console.log(err)
		})

	}
</script>

<style>
	.container {
		width: 320px;
		margin: 100px auto;
		padding: 30px;
		background-color: #ffffff;
		box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
		border-radius: 8px;
		display: flex;
		flex-direction: column;
		gap: 15px;
		font-family: Arial, sans-serif;
	}

	.title {
		text-align: center;
		margin-bottom: 10px;
		font-size: 24px;
		color: #333;
	}

	.input {
		padding: 10px;
		font-size: 16px;
		border: 1px solid #ccc;
		border-radius: 4px;
		flex: 1;
	}

	.verification {
		display: flex;
		gap: 10px;
	}

	.send-button {
		padding: 5px;
		font-size: 14px;
		background-color: #4CAF50;
		color: white;
		border: none;
		border-radius: 4px;
		cursor: pointer;
	}

	.send-button:hover {
		background-color: #0b7dda;
	}

	.actions {
		display: flex;
		justify-content: space-between;
		font-size: 14px;
		color: #666;
	}

	.button {
		padding: 10px;
		background-color: #4CAF50;
		color: white;
		border: none;
		border-radius: 4px;
		cursor: pointer;
		font-size: 10px;
	}

	.button:hover {
		background-color: #45a049;
	}
</style>
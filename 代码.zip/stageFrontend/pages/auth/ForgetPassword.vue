<template>
	<div class="container">
		<h2 class="title">重置密码</h2>
		<p>忘记密码了？我们还没弄好邮箱服务器，去找管理员吧！</p>
		<br />
		<p>手机：157 1271 2171 周子程</p>
		<input class="input" type="email" placeholder="邮箱" v-model="email" disabled="true" />
		<input class="input" type="password" placeholder="新密码" v-model="newPassword" disabled="true" />
		<input class="input" type="password" placeholder="确认密码" v-model="confirmPassword" disabled="true" />
		<div class="verification">
			<input class="input" placeholder="验证码" v-model="code" disabled="true" />
			<button class="send-button" @click="sendCode" disabled="true">发送</button>
		</div>
		<div class="actions">
			<a @click="onLogin">登录</a>
			<a @click="onRegisterClick">注册</a>
		</div>
		<button class="button" @click="resetPassword" disabled="true">点击重置</button>
	</div>
</template>

<script setup>
	import {
		ref
	} from 'vue'

	const email = ref('')
	const newPassword = ref('')
	const confirmPassword = ref('')
	const code = ref('')

	function sendCode() {
		code.value = 'zjbwy'
		uni.showToast({
			title: '验证码已发送',
			icon: 'none'
		})
	}

	function onRegisterClick() {
		uni.navigateTo({
			url: '/pages/auth/Register'
		});
	}

	function onLogin() {
		uni.navigateTo({
			url: '/pages/auth/Login'
		});
	}

	function resetPassword() {
		if (!email.value.trim() || !newPassword.value.trim() || !confirmPassword.value.trim() || !code.value.trim()) {
			uni.showToast({
				title: '请填写完整信息',
				icon: 'none'
			})
			return
		}
		if (newPassword.value !== confirmPassword.value) {
			uni.showToast({
				title: '两次密码不一致',
				icon: 'none'
			})
			return
		}
		uni.showToast({
			title: '密码已重置',
			icon: 'none'
		})
		uni.redirectTo({
			url: '/pages/auth/Login'
		})
	}
</script>

<style>
	.container {
		width: 320px;
		margin: 100px auto;
		padding: 30px;
		background-color: #ffffff;
		box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
		border-radius: 8px;
		display: flex;
		flex-direction: column;
		gap: 15px;
		font-family: Arial, sans-serif;
	}

	.title {
		text-align: center;
		margin-bottom: 10px;
		font-size: 24px;
		color: #333;
	}

	.input {
		padding: 10px;
		font-size: 16px;
		border: 1px solid #ccc;
		border-radius: 4px;
		flex: 1;
	}

	.verification {
		display: flex;
		gap: 10px;
	}

	.send-button {
		padding: 5px;
		font-size: 14px;
		background-color: #4CAF50;
		color: white;
		border: none;
		border-radius: 4px;
		cursor: pointer;
	}

	.send-button:hover {
		background-color: #0b7dda;
	}

	.actions {
		display: flex;
		justify-content: space-between;
		font-size: 14px;
		color: #666;
	}
    

	.button {
		padding: 10px;
		background-color: #4CAF50;
		color: white;
		border: none;
		border-radius: 4px;
		cursor: pointer;
		font-size: 10px;
	}

	.button:hover {
		background-color: #45a049;
	}
</style>
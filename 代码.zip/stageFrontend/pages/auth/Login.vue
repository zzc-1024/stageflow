<template>
	<div class="container">
		<h2 class="title">登录</h2>
		<input class="input" type="email" placeholder="邮箱" v-model="email" />
		<input class="input" type="password" placeholder="密码" v-model="password" />
		<div class="actions">
			<a @click="onRegisterClick">注册</a>
			<a @click="onForgetPasswordClick">忘记密码？</a>
		</div>
		<button class="button" @click="onLogin">点击登录</button>
	</div>
</template>

<script setup>
	import {
		ref
	} from 'vue'

	import {
		login
	} from '@/api/auth';

	const email = ref('')
	const password = ref('')

	function onRegisterClick() {
		uni.navigateTo({
			url: '/pages/auth/Register'
		});
	}

	function onForgetPasswordClick() {
		uni.navigateTo({
			url: '/pages/auth/ForgetPassword'
		});
	}

	async function onLogin() {
		if (!email.value.trim() || !password.value.trim()) {
			alert("请输入邮箱密码")
			return
		}
		login(email.value, password.value).then(res => {
			if (res.code !== 0) {
				uni.showToast({
					title: res.message,
					icon: 'error'
				})
				return
			}
			console.log(res)
			uni.setStorageSync('token', res['token'])
			uni.setStorageSync('email', email.value)
			uni.setStorageSync('user_id', res['user_id'])
			// 下面不要用空值合并，兼容性不行！
			uni.setStorageSync('username', res['username'] ? res['username'] : "<该用户还没有名字>")
			uni.switchTab({
				url: '/pages/index/index'
			})
		}).catch(err => {
			console.log(err)
			uni.showToast({
				title: '邮箱和密码不能为空',
				icon: 'none'
			})
		})
	}
</script>

<style scoped>
	.container {
		width: 320px;
		margin: 100px auto;
		padding: 30px;
		background-color: #ffffff;
		box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
		border-radius: 8px;
		display: flex;
		flex-direction: column;
		gap: 15px;
		font-family: Arial, sans-serif;
	}

	.title {
		text-align: center;
		margin-bottom: 10px;
		font-size: 24px;
		color: #333;
	}

	.input {
		padding: 10px;
		font-size: 16px;
		border: 1px solid #ccc;
		border-radius: 4px;
	}

	.actions {
		display: flex;
		justify-content: space-between;
		font-size: 14px;
		color: #666;
	}

	.button {
		padding: 8px;
		background-color: #4CAF50;
		color: white;
		border: none;
		border-radius: 4px;
		cursor: pointer;
		font-size: 10px;
	}

	.button:hover {
		background-color: #45a049;
	}
</style>
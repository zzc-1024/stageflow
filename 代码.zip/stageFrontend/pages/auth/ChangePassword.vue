<template>
  <view class="container">
    <view class="header">
      <text class="title">更改密码</text>
    </view>
    
    <view class="form-container">
      <view class="form-group">
        <text class="label">当前密码</text>
        <!-- UniApp 增强属性：在部分平台隐藏密码 -->
        <input 
          class="input" 
          v-model="currentPassword" 
          type="password" 
          placeholder="请输入当前密码"
          password
        />
      </view>
      <view class="form-group">
        <text class="label">新密码</text>
        <input 
          class="input" 
          v-model="newPassword" 
          type="password" 
          placeholder="请输入新密码"
          password
        />
      </view>
      <view class="form-group">
        <text class="label">确认新密码</text>
        <input 
          class="input" 
          v-model="confirmPassword" 
          type="password" 
          placeholder="请确认新密码"
          password
        />
      </view>
      <!-- 统一按钮点击态 -->
      <button 
        class="submit-btn" 
        @click="changePassword"
        hover-class="button-hover"
      >
        确认更改
      </button>
      <button 
        class="back-btn" 
        @click="navigateBack"
        hover-class="button-hover"
      >
        返回个人信息
      </button>
    </view>
  </view>
</template>

<script>
export default {
  data() {
    return {
      currentPassword: '',
      newPassword: '',
      confirmPassword: ''
    }
  },
  methods: {
    async changePassword() {
      // 密码校验逻辑
      if (this.newPassword !== this.confirmPassword) {
        uni.showToast({ title: '两次密码不一致', icon: 'none' });
        return;
      }
      
      // 调用UniApp请求API
      try {
        const res = await uni.request({
          url: 'https://your-api.com/change-password',
          method: 'POST',
          data: {
            current: this.currentPassword,
            new: this.newPassword
          }
        });
        
        if (res.data.success) {
          uni.showToast({ title: '修改成功' });
          setTimeout(() => uni.navigateBack(), 1500);
        } else {
          uni.showToast({ title: res.data.message, icon: 'none' });
        }
      } catch (e) {
        uni.showToast({ title: '请求失败', icon: 'none' });
      }
    },
    navigateBack() {
      uni.navigateBack();
    }
  }
}
</script>

<style scoped>
/* 容器样式 - 适配多端 */
.container {
  padding: 20px;
  /* #ifdef H5 */
  min-height: 100vh;
  /* #endif */
  /* #ifndef H5 */
  height: 100%;
  /* #endif */
  background-color: #f5f5f5;
}

/* 头部样式 */
.header {
  text-align: center;
  margin-bottom: 30px;
}

.title {
  font-size: 24px;
  font-weight: bold;
  color: #333;
}

/* 表单容器 */
.form-container {
  background-color: #fff;
  padding: 25px;
  border-radius: 10px;
  /* #ifndef MP-WEIXIN */
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
  /* #endif */
}

.form-group {
  margin-bottom: 25px;
}

.label {
  display: block;
  margin-bottom: 8px;
  font-size: 14px;
  color: #666;
}

.input {
  width: 100%;
  padding: 12px 15px;
  border: 1px solid #ddd;
  border-radius: 6px;
  font-size: 16px;
}

/* 按钮样式 */
.submit-btn {
  width: 100%;
  padding: 15px;
  background-color: #007aff;
  color: white;
  border: none;
  border-radius: 6px;
  font-size: 16px;
  margin-bottom: 15px;
}

.back-btn {
  width: 100%;
  padding: 15px;
  background-color: #f5f5f5;
  color: #333;
  border: none;
  border-radius: 6px;
  font-size: 16px;
}

/* 统一按钮点击态 */
.button-hover {
  opacity: 0.8;
}
</style>
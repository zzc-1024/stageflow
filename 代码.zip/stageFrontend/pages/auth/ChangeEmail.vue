<template>
  <!-- 将所有view替换为div，text替换为span -->
  <div class="container">
    <div class="header">
      <span class="title">更改邮箱</span>
    </div>
    
    
    <div class="form-container">
      <div class="form-group">
        <span class="label">新邮箱地址</span>
        <input
          class="input"
          v-model="newEmail"
          type="email"
          placeholder="请输入新邮箱"
        />
      </div>
      
      <button class="submit-btn" @click="changeEmail">
        确认更改
      </button>
      
      <button class="back-btn" @click="navigateBack">
        返回个人信息
      </button>
    </div>
  </div>
</template>

<script setup>
// 删除Vue Router导入
// import { useRouter } from 'vue-router'
// const router = useRouter()

const submitForm = () => {
  // 使用uni-app导航代替Vue Router
  uni.navigateBack()
}
</script>

<style scoped>
.container {
  padding: 20px;
  min-height: 100vh;
  background-color: #f5f5f5;
}

.header {
  text-align: center;
  margin-bottom: 30px;
}

.title {
  font-size: 24px;
  font-weight: bold;
  color: #333;
}

.form-container {
  background-color: #fff;
  padding: 25px;
  border-radius: 10px;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
}

.form-group {
  margin-bottom: 25px;
}

.label {
  display: block;
  margin-bottom: 8px;
  font-size: 14px;
  color: #666;
}

.input {
  width: 100%;
  padding: 12px 15px;
  border: 1px solid #ddd;
  border-radius: 6px;
  font-size: 16px;
}

.submit-btn {
  width: 100%;
  padding: 15px;
  background-color: #007aff;
  color: white;
  border: none;
  border-radius: 6px;
  font-size: 16px;
  margin-bottom: 15px;
}

.back-btn {
  width: 100%;
  padding: 15px;
  background-color: #f5f5f5;
  color: #333;
  border: none;
  border-radius: 6px;
  font-size: 16px;
}
</style>
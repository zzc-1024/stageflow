<template>
	<view class="form-container">
		<view class="title">创建活动</view>

		<input class="input" placeholder="请输入活动名称" v-model="title" />

		<textarea class="textarea" placeholder="请输入活动简介" v-model="descrition" />

		<uni-section :title="'日期时间用法：' + datetimesingle" type="line"></uni-section>
		<view class="example-body">
			<uni-datetime-picker type="datetime" v-model="datetimesingle" />
		</view>

		<view class="radio-section">
			<text class="radio-label">可见性设置：</text>
			<radio-group @change="onRadioChange">
				<label class="radio-item">
					<radio value="1" :checked="visibility === 1" />
					<text>公开</text>
				</label>
				<label class="radio-item">
					<radio value="0" :checked="visibility === 0" />
					<text>私有</text>
				</label>
			</radio-group>
		</view>

		<button type="primary" @click="submitForm" :disabled="submitDisabled">确认创建</button>
	</view>
</template>

<script setup lang="ts">
	import { ref } from 'vue'
	import { createActivity } from '@/api/activity';
	const title = ref("");
	const descrition = ref("");
	const datetimesingle = ref("")
	const visibility = ref(0);
	const submitDisabled = ref(false)

	function onRadioChange(e : any) {
		visibility.value = e.detail.value
	}
	function submitForm() {
		if (!title.value.trim()) {
			uni.showToast({
				title: "请输入标题",
				icon: 'error'
			})
			return
		}
		if (!datetimesingle.value.trim()) {
			uni.showToast({
				title: "请输入时间",
				icon: 'error'
			})
			return
		}
		submitDisabled.value = true
		createActivity(title.value, descrition.value, datetimesingle.value, visibility.value).then(res => {
			if (res.code !== 0) {
				uni.showToast({
					title: res.message,
					icon: 'error'
				});
				console.log(res);
				return;
			}
			uni.showToast({
				title: "创建成功",
				icon: "success"
			})
			uni.navigateBack()
		}).catch(err => {
			console.log(err)
		}).finally(() => {
			submitDisabled.value = false
		})
	}
</script>

<style scoped>
	.form-container {
		padding: 30rpx;
	}

	.title {
		font-size: 36rpx;
		font-weight: bold;
		margin-bottom: 20rpx;
	}

	.input {
		width: 90%;
		border: 1px solid #ccc;
		border-radius: 12rpx;
		padding: 20rpx;
		margin-bottom: 20rpx;
	}

	.textarea {
		width: 90%;
		height: 200rpx;
		border: 1px solid #ccc;
		border-radius: 12rpx;
		padding: 20rpx;
		margin-bottom: 20rpx;
	}

	.radio-section {
		margin-bottom: 40rpx;
	}

	.radio-label {
		font-size: 30rpx;
		margin-bottom: 10rpx;
		display: block;
	}

	.radio-item {
		display: flex;
		align-items: center;
		margin: 10rpx 0;
	}

	.radio-item text {
		margin-left: 10rpx;
	}
</style>
<template>
  <view class="form-container">
    <view class="title">创建组织</view>

    <input class="input" placeholder="请输入组织名称" v-model="form.title" />

    <textarea
      class="textarea"
      placeholder="请输入组织简介"
      v-model="form.desc"
    />

    <view class="radio-section">
      <text class="radio-label">可见性设置：</text>
      <radio-group @change="onRadioChange">
        <label class="radio-item">
          <radio value="public" :checked="form.visibility === 'public'" />
          <text>公开</text>
        </label>
        <label class="radio-item">
          <radio value="private" :checked="form.visibility === 'private'" />
          <text>私有</text>
        </label>
      </radio-group>
    </view>

    <button type="primary" @click="submitForm">确认创建</button>
  </view>
</template>

<script setup>
import { ref } from 'vue'

// 表单数据
const form = ref({
  title: '',
  desc: '',
  visibility: 'public'
})

// 单选框变化事件
const onRadioChange = (e) => {
  form.value.visibility = e.detail.value
}

// 提交表单
const submitForm = () => {
  console.log('组织创建数据:', form.value)
  uni.showToast({
    title: '创建成功',
    icon: 'success'
  })
}
</script>

<style>
/* 同创建活动 */
.form-container {
  padding: 30rpx;
}
.title {
  font-size: 36rpx;
  font-weight: bold;
  margin-bottom: 20rpx;
}
.input {
  width:  90%;
  border: 1px solid #ccc;
  border-radius: 12rpx;
  padding: 20rpx;
  margin-bottom: 20rpx;
}
.textarea {
  width: 90%;
  height: 200rpx;
  border: 1px solid #ccc;
  border-radius: 12rpx;
  padding: 20rpx;
  margin-bottom: 20rpx;
}
.radio-section {
  margin-bottom: 40rpx;
}
.radio-label {
  font-size: 30rpx;
  margin-bottom: 10rpx;
  display: block;
}
.radio-item {
  display: flex;
  align-items: center;
  margin: 10rpx 0;
}
.radio-item text {
  margin-left: 10rpx;
}
</style>

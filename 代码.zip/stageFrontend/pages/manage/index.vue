<template>
	<view class="container">
		<!-- 顶部标题 -->
		<view class="header">
			<text class="title">活动 & 组织平台</text>
		</view>
		<!-- 在 tabs 下方，intro-box 上方添加 -->
		<view class="action-buttons">
			<button class="action-btn" @click="createActivity">
				📅 创建活动
			</button>
			<button class="action-btn" @click="createOrg">
				👥 创建组织
			</button>
		</view>


		<!-- Tab 切换栏 -->
		<view class="tabs" v-if="true">
			<view class="tab-item" :class="{ active: currentTab === 'activity' }" @click="currentTab = 'activity'">活动
			</view>
			<view class="tab-item" :class="{ active: currentTab === 'org' }" disabled @click="currentTab = 'org'">组织</view>
		</view>

		<!-- 简介框 -->
		<view class="intro-box">
			<text class="intro-title">{{ introTitle }}</text>
			<text class="intro-content">{{ introContent }}</text>
		</view>

		<!-- 内容卡片列表 -->
		<view class="header">我拥有的活动：</view>
		<view v-for="(item, index) in myActivityList" :key="index" class="card" @click="navToActivity(item.activity_id)">
			<text class="card-title">{{ item['activity_name'] }}</text>
			<br />
			<text class="card-desc">{{ item['activity_description'] }}</text>
		</view>

		<view class="header">我管理的活动：</view>
		<view v-for="(item, index) in managedActivityList" :key="index" class="card" @click="navToActivity(item.activity_id)">
			<text class="card-title">{{ item['activity_name'] }}</text>
			<br />
			<text class="card-desc">{{ item['activity_description'] }}</text>
		</view>

		<!-- 翻页按钮 -->
		<!-- TODO: 这里以后再做分页，现在应该不需要这么多活动 -->
		<view class="load-more" v-if="false">
			<button type="default" @click="loadMore">加载更多</button>
		</view>
	</view>
</template>

<script setup lang="ts">
	import {
		onLoad,
		onShow
	} from '@dcloudio/uni-app'
	import {
		ref,
		computed,
	} from 'vue'

	import {
		getActivityByCurrentUser,
		getActivityByManager,
	} from '@/api/activity'

	// 响应式数据
	const currentTab = ref('activity');
	const myActivityList = ref([]);
	const managedActivityList = ref([]);
	const orgList = ref([]);
	const page = ref(1);
	const pageSize = ref(5);

	function navToActivity(activity_id : number) {
		uni.navigateTo({
			url: `/pages/activity/index?activityId=${activity_id}`
		})
	}

	// computed 属性
	const introTitle = computed(() => {
		return currentTab.value === 'activity' ? '活动列表' : '组织列表'
	})

	const introContent = computed(() => {
		return currentTab.value === 'activity' ?
			'展示当前用户拥有的活动，按开始时间倒序排列' :
			'展示已创建的组织，便于成员管理与活动协作。'
	})

	const currentList = computed(() => {
		return currentTab.value === 'activity' ? myActivityList.value : orgList.value
	})

	// 加载更多数据
	const loadMore = () => {
		const newItems = Array.from({
			length: pageSize.value
		}, (_, i) => ({
			title: (currentTab.value === 'activity' ? '活动' : '组织') +
				`标题 ${(page.value - 1) * pageSize.value + i + 1}`,
			desc: '这是一个简要介绍……'
		}))

		if (currentTab.value === 'activity') {
			myActivityList.value.push(...newItems)
		} else {
			orgList.value.push(...newItems)
		}

		page.value++
	}

	function updateList() {
		getActivityByCurrentUser().then(res => {
			myActivityList.value = res['activities'];
		});
		getActivityByManager().then(res => {
			managedActivityList.value = res['activities'];
		});
	}

	// 页面加载时自动加载数据
	onShow(() => {
		updateList()
	})

	// 页面跳转函数
	const createActivity = () => {
		uni.navigateTo({
			url: '/pages/manage/create/activity'
		})
	}

	const createOrg = () => {
		uni.showToast({
			title: '组织功能尚未开放',
			icon: 'error'
		})
		return
	}
</script>

<style scoped>
	.container {
		display: flex;
		flex-direction: column;
		height: 100vh;
		background: #f8f8f8;
	}

	.header {
		padding: 30rpx;
		background: #ffffff;
	}

	.title {
		font-size: 36rpx;
		font-weight: bold;
		text-align: center;
	}

	.tabs {
		display: flex;
		background: #ffffff;
	}

	.tab-item {
		flex: 1;
		text-align: center;
		padding: 20rpx;
		font-size: 30rpx;
		color: #666;
		border-bottom: 4rpx solid transparent;
	}

	.tab-item.active {
		color: #007aff;
		border-bottom: 4rpx solid #007aff;
	}

	.intro-box {
		padding: 20rpx;
		background: #e6f2ff;
		margin: 20rpx;
		border-radius: 12rpx;
	}

	.intro-title {
		font-weight: bold;
		font-size: 30rpx;
	}

	.intro-content {
		margin-top: 10rpx;
		font-size: 26rpx;
		color: #555;
	}

	.card {
		background: #33f;
		margin: 16rpx 20rpx;
		padding: 20rpx;
		border-radius: 12rpx;
		box-shadow: 0 2rpx 8rpx rgba(0, 0, 0, 0.05);
	}

	.card-title {
		font-size: 30rpx;
		font-weight: bold;
	}

	.card-desc {
		margin-top: 6rpx;
		font-size: 26rpx;
		color: #888;
	}

	.load-more {
		margin: 20rpx;
		text-align: center;
	}

	.action-buttons {
		display: flex;
		justify-content: space-around;
		padding: 20rpx 30rpx;
	}

	.action-btn {
		flex: 1;
		margin: 0 10rpx;
		background-color: #007aff;
		color: #fff;
		font-size: 28rpx;
		border-radius: 12rpx;
		padding: 20rpx 0;
		text-align: center;
	}
</style>
<template>
	<view class="director-hall">
		<!-- 导航栏标题（uni-app 会自动处理） -->
		<view class="header">
			<text class="title">导演大厅</text>
			<button class="publish-btn" @click="goToPublish">发布任务</button>
		</view>

		<!-- 任务列表 -->
		<scroll-view scroll-y class="task-list">
			<view v-for="task in taskList" :key="task.id" class="task-item">
				<view class="task-header">
					<text class="task-title">{{ task.title }}</text>
					<text class="time">{{ task.time }}</text>
				</view>
				<text class="task-desc">{{ task.description }}</text>
				<button class="claim-btn" :disabled="task.claimed" @click="claimTask(task.id)">
					{{ task.claimed ? '已领取' : '领取任务' }}
				</button>
			</view>

			<!-- 空状态 -->
			<view v-if="taskList.length === 0" class="empty">
				暂无任务，快去发布一个吧！
			</view>
		</scroll-view>
	</view>
</template>

<script setup>
	import {
		ref
	} from 'vue'

	// 模拟任务数据
	const taskList = ref([{
			id: 1,
			title: '拍摄短视频广告',
			description: '需要一位有经验的打野导演，协助完成30秒产品广告拍摄，地点：上海',
			time: '2小时前',
			claimed: false
		},
		{
			id: 2,
			title: '综艺外景协调',
			description: '周末两天，协助大型综艺外景调度，需自备设备',
			time: '1天前',
			claimed: true
		},
		{
			id: 3,
			title: '微电影分镜指导',
			description: '为学生团队提供分镜脚本优化建议，线上沟通即可',
			time: '3天前',
			claimed: false
		}
	])

	// 发布任务（跳转示意）
	const goToPublish = () => {
		uni.showToast({
			title: '跳转发布页（Demo）',
			icon: 'none'
		})
		// 实际项目中：uni.navigateTo({ url: '/pages/publish-task/publish-task' })
	}

	// 领取任务
	const claimTask = (id) => {
		const task = taskList.value.find(t => t.id === id)
		if (task && !task.claimed) {
			task.claimed = true
			uni.showToast({
				title: '任务领取成功！',
				icon: 'success'
			})
		}
	}
</script>

<style scoped>
	.director-hall {
		background-color: #f8f9fa;
		min-height: 100vh;
		padding: 20rpx;
	}

	.header {
		display: flex;
		justify-content: space-between;
		align-items: center;
		padding: 20rpx 30rpx;
		background-color: #ffffff;
		border-radius: 16rpx;
		margin-bottom: 30rpx;
		box-shadow: 0 4rpx 12rpx rgba(0, 0, 0, 0.05);
	}

	.title {
		font-size: 36rpx;
		font-weight: bold;
		color: #333;
	}

	.publish-btn {
		background-color: #007aff;
		color: white;
		font-size: 24rpx;
		padding: 10rpx 24rpx;
		border-radius: 8rpx;
	}

	.task-list {
		height: calc(100vh - 200rpx);
	}

	.task-item {
		background-color: #ffffff;
		padding: 30rpx;
		margin-bottom: 24rpx;
		border-radius: 16rpx;
		box-shadow: 0 4rpx 12rpx rgba(0, 0, 0, 0.05);
	}

	.task-header {
		display: flex;
		justify-content: space-between;
		margin-bottom: 16rpx;
	}

	.task-title {
		font-size: 32rpx;
		font-weight: bold;
		color: #2c3e50;
	}

	.time {
		font-size: 24rpx;
		color: #888;
	}

	.task-desc {
		font-size: 28rpx;
		color: #555;
		line-height: 1.5;
		margin-bottom: 24rpx;
		display: block;
	}

	.claim-btn {
		width: 100%;
		background-color: #4cd964;
		color: white;
		font-size: 28rpx;
		padding: 16rpx 0;
		border-radius: 10rpx;
	}

	.claim-btn:disabled {
		background-color: #cccccc;
		color: #999;
	}

	.empty {
		text-align: center;
		color: #999;
		font-size: 28rpx;
		padding: 100rpx 0;
	}
</style>
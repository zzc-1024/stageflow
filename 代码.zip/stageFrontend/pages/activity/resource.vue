<template>
  <view class="container">
    <view v-if="mapUrl" class="map-preview">
      <image :src="mapUrl" class="map-image" mode="aspectFit" />
    </view>

    <button class="upload-btn" @click="selectMap">上传场地地图</button>

    <view class="note">功能待定</view>
  </view>
</template>

<script setup>
import { ref } from 'vue'

const mapUrl = ref('')

function selectMap() {
  uni.chooseImage({
    count: 1,
    success: res => {
      if (res.tempFilePaths.length > 0) {
        mapUrl.value = res.tempFilePaths[0]
      }
    }
  })
}
</script>

<style scoped>
.container {
  padding: 20px;
  background-color: #f5f5f5;
  min-height: 100vh;
}
.map-preview {
  width: 100%;
  height: 240px;
  border-radius: 12px;
  overflow: hidden;
  background-color: #ffffff;
  margin-bottom: 20px;
  border: 1px solid #ddd;
  display: flex;
  align-items: center;
  justify-content: center;
}
.map-image {
  width: 100%;
  height: 100%;
  object-fit: contain;
}
.upload-btn {
  width: 100%;
  background-color: #005500;
  color: white;
  padding: 12px;
  border-radius: 8px;
  font-size: 15px;
  border: none;
  margin-bottom: 20px;
}
.note {
  color: #888;
  font-size: 14px;
  text-align: center;
  margin-top: 40px;
}
</style>
<template>
	<!-- 活动信息 -->
	<view style="background-color: aquamarine; padding: 8rpx;">
		<h1>{{ activity['activity_name'] }}</h1>
		<view>
			<div>
				计划开始时间: {{ formatDate(activity['activity_start_time']) }}
			</div>
			<div>
				实际开始时间: {{
					activity['real_activity_start_time'] ? formatDate(activity['real_activity_start_time']) : '未开始'
				}}
			</div>
			<div v-if="processedEvents.length === 0">
				活动尚未就绪
			</div>
			<div v-else>
				<view style="display: flex;">
					当前延时为
					<uni-number-box v-model="delay" :min="1" :max="9" :width="10"></uni-number-box>
					秒
				</view>

				<!-- 活动未开始的情况 -->
				<view v-if="activity['real_activity_start_time'] === null" class="current-show placeholder">
					<text>活动尚未开始</text>
					<button @click="onStartActivity" size="mini" type="primary">
						点击{{delay}}秒后开始活动
					</button>
				</view>
				<!-- 活动开始的情况 -->
				<view v-else>
					<!-- 时间描述 -->
					<view v-if="currentEvent != null">
						<div>
							已进行{{formatSecondsToHMS(elapsedTime)}}，
							剩余时间{{formatSecondsToHMS(remainingTime)}}，
						</div>
						<div>
							预计时长{{formatSecondsToHMS(currentEvent['duration'] / 1000)}}，
							原计划时长{{formatSecondsToHMS(currentEvent['planed_duration'] / 1000)}}
						</div>
					</view>

					<!-- 进度条 -->
					<progress :percent="progress" stroke-width="6" backgroundColor="#eee" style="margin: 10rpx;" />

					<!-- 按钮组 -->
					<view style="display: flex;">
						<button :disabled="currentEvent == null || currentEvent['real_delta_time'] != null"
							@click="onSetRealDeltaTime" size="mini" type="primary">
							{{delay}}秒后结束
						</button>
						<button @click="onSetTimePunctually"
							:disabled="currentEvent == null || currentEvent['real_delta_time'] != null" size="mini"
							type="primary">设置准时结束</button>
						<button @click="onCancelSetRealDeltaTime"
							:disabled="currentEvent == null || currentEvent['real_delta_time'] == null" size="mini" type="warn">
							取消结束
						</button>
					</view>
				</view>
			</div>
		</view>
	</view>

	<!-- 事件相关内容 -->
	<view>
		<h2 class="event-header">
			事件列表
		</h2>
		<scroll-view :scroll-y="true" class="event-list">
			<!-- 事件列表 -->
			<view v-for="(event, index) in processedEvents">
				<EventItem :key="index" :event="event" :level="0" :onCheckIn="onCheckIn" />
			</view>
		</scroll-view :scroll-y="true">
	</view>

	<!-- 弹窗，平时是隐藏起来的 -->
	<view class="dialogs">
		<!-- 添加任务的签到人员 -->
		<uni-popup class="participation-task-dialog" ref="checkInTaskDialog" type="dialog">
			<view class="participation-task-dialog-content" calss="check-in-dialog-content">
				<uni-data-select v-model="selectedParticipationId" :localdata="selections"></uni-data-select>
				<button @click="addParticipationTaskConfirm" type="primary" size="mini">确认</button>
				<!-- <button @click="cancelAddUser" type="warn" size="mini">取消</button> -->
			</view>
		</uni-popup>
	</view>
</template>

<script setup lang="ts">
	import {
		ref,
		computed,
		onMounted,
		onBeforeUnmount,
		watch,
	} from 'vue';
	import { getActivityById, getMembers, askActivity, startActivity } from "@/api/activity";
	import { getEventsByActivityId, createEvent, changeEvent, setEventRealDeltaTime } from "@/api/event";
	import {
		createEventTask, changeEventTask, deleteEventTask,
		addParticipationTask, deleteParticipationTask, checkIn,
	} from '@/api/eventTask';
	import EventItem from '@/components/EventItem/EventItem.vue';
	import { speechRecognition } from '../../api/ai';
	import { BASE_URL } from '../../api/clientInstance';
	import {
		WS_URL
	} from '@/api/clientInstance';
	import { ActivityControl } from '../../utils/activityControl';

	const props = defineProps({
		activityId: {
			type: Number,
			required: true
		}
	});

	// 活动控制相关
	const delay = ref<number>(5);

	// 格式化日期时间
	const formatDate = (dateString : string | number | Date) => {
		if (!dateString) return '';
		const date = new Date(dateString);
		return new Intl.DateTimeFormat('zh-CN', {
			year: 'numeric',
			month: '2-digit',
			day: '2-digit',
			hour: '2-digit',
			minute: '2-digit',
			second: '2-digit'
		}).format(date);
	};

	// 活动数据示例
	const activity = ref({
		activity_name: '加载中',
		activity_start_time: '',
		real_activity_start_time: '',
	});
	const events = ref([]);
	const processedEvents = ref([]);
	const currentEvent = ref();
	// 当前事件的像计算属性
	// 进度条百分比，表示当前事件的进行状态
	const progress = computed(() => {
		if (!currentEvent.value) return 0;
		const total = currentEvent.value['duration'] / 1000;
		if (total <= 0) return 100;
		return Math.min(
			100, (
				(Date.now() - currentEvent.value['calculated_start_time'].getTime()) / 1000 / total
			) * 100,
		);
	});
	// 已经进行的时间和剩余的时间
	const elapsedTime = computed(() => {
		return Math.floor((Date.now() - currentEvent.value['calculated_start_time'].getTime()) / 1000);
	});
	const remainingTime = computed(() => {
		return Math.max(0, currentEvent.value['duration'] / 1000 - elapsedTime.value);
	});
	// 将上面的时间转换为字符串
	function formatSecondsToHMS(seconds : number) : string {
		if (typeof seconds !== 'number' || !isFinite(seconds)) {
			return '00:00:00';
		}

		const isNegative = seconds < 0;
		const totalSeconds = Math.abs(Math.floor(seconds)); // 取绝对值并取整

		const h = Math.floor(totalSeconds / 3600);
		const m = Math.floor((totalSeconds % 3600) / 60);
		const s = totalSeconds % 60;

		const timeStr = `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;

		return isNegative ? `-${timeStr}` : timeStr;
	}

	watch(activity, () => processEvents());
	watch(events, () => processEvents(), { deep: true });
	const timeTrigger = ref<number>(0);
	watch(timeTrigger, () => processEvents())

	// 活动控制部分
	let socketTask : UniApp.SocketTask = null;
	const activityControl : ActivityControl = new ActivityControl();
	let lastHeartBeatTime : Date;
	let socketTimer = null;
	activityControl.onActivityStart(time => {
		activity.value.real_activity_start_time = time;
		uni.vibrateLong({
			fail() {
				uni.showToast({
					title: "活动即将开始",
					icon: 'none',
				})
			}
		});
	});
	activityControl.onEventSetRealDeltaTime((eventId : number, realDeltaTime : number | null) => {
		function findEvent(events : any[]) {
			for (const event of events) {
				if (event['children'].length > 0) {
					const res = findEvent(event['children']);
					if (res) return true;
				} else {
					if (event['event_id'] == eventId) {
						event['real_delta_time'] = realDeltaTime;
						if (realDeltaTime === null) {
							uni.vibrateLong({
								fail() {
									uni.showToast({
										title: "事件已被取消",
										icon: 'none',
									})
								}
							});
						} else {
							uni.vibrateLong({
								fail() {
									uni.showToast({
										title: "事件即将开始",
										icon: 'none',
									})
								}
							});
						}
						return true;
					}
				}
			}
			return false;
		}
		findEvent(events.value);
	});
	activityControl.onCheckIn((participationTaskId : number, status : number) => {
		function findEvent(events : any[]) {
			for (const event of events) {
				const res = findEvent(event['children']);
				if (res) return true;
				for (const eventTask of event['event_tasks']) {
					for (const participationTask of eventTask['participation_tasks']) {
						if (participationTask['participation_task_id'] == participationTaskId) {
							participationTask['status'] = status;
							// 这个就不提醒了，签到的人太多了
							return true;
						}
					}
				}
			}
			return false;
		}
		findEvent(events.value);
	});
	activityControl.onHeartBeat(() => {
		lastHeartBeatTime = new Date();
	});
	activityControl.onError(reason => console.log(reason));
	// 活动控制 - 开始活动
	function onStartActivity() {
		startActivity(
			props.activityId,
			new Date(Date.now() + delay.value * 1000).toLocaleString('sv-SE'),  // sv-SE恰好是 ISO 格式
		).then(res => {
			if (res['code'] !== 0) {
				uni.showToast({
					title: res['message'],
					icon: 'error'
				});
				console.log(res);
				return;
			}
		});
	}
	// 活动控制 - 事件结束倒计时
	function onSetRealDeltaTime() {
		if (currentEvent.value === null) {
			uni.showToast({
				title: "没有正在进行的事件",
				icon: 'error'
			});
			return;
		}
		const currentTime : number = Date.now();
		setEventRealDeltaTime(
			props.activityId,
			currentEvent.value['event_id'],
			Math.floor(
				(currentTime + delay.value * 1000 - currentEvent.value['calculated_start_time'].getTime()) / 1000
			),
		).then(res => {
			if (res['code'] !== 0) {
				uni.showToast({
					title: res['message'],
					icon: 'error'
				});
				console.log(res);
				return;
			}
		});
	}
	// 活动控制 - 设置事件准时结束
	function onSetTimePunctually() {
		if (currentEvent.value === null) {
			uni.showToast({
				title: "没有正在进行的事件",
				icon: 'error'
			});
			return;
		}
		setEventRealDeltaTime(
			props.activityId,
			currentEvent.value['event_id'],
			currentEvent.value['delta_time'],
		).then(res => {
			if (res['code'] !== 0) {
				uni.showToast({
					title: res['message'],
					icon: 'error'
				});
				console.log(res);
				return;
			}
		});
	}
	// 活动控制 - 取消事件结束
	function onCancelSetRealDeltaTime() {
		if (currentEvent.value === null) {
			uni.showToast({
				title: "没有正在进行的事件",
				icon: 'error'
			});
			return;
		}
		setEventRealDeltaTime(
			props.activityId,
			currentEvent.value['event_id'],
			null,
		).then(res => {
			if (res['code'] !== 0) {
				uni.showToast({
					title: res['message'],
					icon: 'error'
				});
				console.log(res);
				return;
			}
		});
	}
	// 活动控制 - 签到
	function onCheckIn(
		participationTaskId : number,
		status : number
	) {
		checkIn(props.activityId, participationTaskId, status).then(res => {
			if (res.code !== 0) {
				uni.showToast({
					title: res.message,
					icon: 'error',
				});
				console.log(res);
				return;
			}
		}).catch(err => {
			console.log(err)
			uni.showToast({
				title: '发生异常',
				icon: 'error',
			});
		});
	}

	function onAddButtonClick(
		parent_event_id : number,
		pre_event_id : number,
	) {
		createEvent(props.activityId, "测试名称", parent_event_id, pre_event_id, 366).then(res => {
			if (res.code !== 0) {
				uni.showToast({
					title: res.message,
					icon: 'error'
				});
				console.log(res);
				return;
			}
			flushEvent();
		});
	}
	function importExcel() {
		uni.chooseFile({
			count: 1,
			extension: ['.xls', '.xlsx'],
			success(res) {
				// const tempFilePaths = res.tempFilePaths
				uni.uploadFile({
					url: BASE_URL + `/activity/excel/${props.activityId}/upload`,
					filePaths: [],
					name: 'file.xlsx',
					formData: {
						file: res.tempFiles[0],
						plugin_name: "zhou_bi_chang",
					},
					success(uploadFileRes) {
						console.log(uploadFileRes)
						flushEvent();
					}
				});
			}
		});
	}

	function onChangeEvent(
		eventId : number,
		eventName : string,
		eventDeltaTime : number,
		eventRealDeltaTime : number | null,
	) {
		if (eventName.trim().length === 0) {
			uni.showToast({
				title: "名称长度不能为空",
				icon: 'error'
			});
			return;
		}
		if (eventDeltaTime === 0) {
			uni.showToast({
				title: "时间不能是0秒",
				icon: 'error'
			});
			return;
		}
		changeEvent(eventId, eventName, eventDeltaTime, eventRealDeltaTime).then(res => {
			if (res.code !== 0) {
				uni.showToast({
					title: res.message,
					icon: 'error'
				});
				console.log(res);
				return;
			}
			flushEvent();
		}).catch(err => {
			console.log(err)
			uni.showToast({
				title: '初始化时发生异常',
				icon: 'error'
			});
			console.log(err);
		});
	}

	function onCreateEventTask(
		eventId : number,
		eventTaskName : string
	) {
		createEventTask(props.activityId, eventId, eventTaskName).then(res => {
			if (res.code !== 0) {
				uni.showToast({
					title: res.message,
					icon: 'error'
				});
				return;
			}
			flushEvent();
		}).catch(err => {
			uni.showToast({
				title: '发生异常',
				icon: 'error',
			});
			console.log(err);
		});
	}

	function onChangeEventTask(
		eventTaskId : number,
		eventTaskName : string,
	) {
		changeEventTask(eventTaskId, eventTaskName).then(res => {
			if (res.code !== 0) {
				uni.showToast({
					title: res.message,
					icon: 'error'
				});
				return;
			}
			flushEvent();
		}).catch(err => {
			console.log(err)
			uni.showToast({
				title: '发生异常',
				icon: 'error',
			});
		});
	}

	function onDeleteEventTask(eventTaskId : number) {
		deleteEventTask(eventTaskId).then(res => {
			if (res.code !== 0) {
				uni.showToast({
					title: res.message,
					icon: 'error'
				});
				return;
			}
			flushEvent();
		}).catch(err => {
			console.log(err)
			uni.showToast({
				title: '发生异常',
				icon: 'error'
			});
		});
	}

	// 下面是 AI 问答的相关内容
	const responseMessage = ref("您好，请问需要我做什么？");
	function onMessageAsk(val : string) {
		responseMessage.value = "请等待响应";
		const question = `# 数据\
		${JSON.stringify(events.value)}\
		# 用户问题\
		${val}`;
		askActivity(props.activityId, question).then(res => {
			if (res.code !== 0) {
				uni.showToast({
					title: res["message"],
					icon: 'error',
				});
				console.log(res);
				responseMessage.value = res["message"];
				return;
			}
			responseMessage.value = res['response'];
			flushEvent();
		}).catch(err => {
			console.log(err)
			uni.showToast({
				title: '发生异常',
				icon: 'error'
			});
		});
	}
	async function onAudioAsk(base64_data : string) {
		const questionResponse = await speechRecognition(base64_data);
		responseMessage.value = "请等待响应";
		if (questionResponse.code !== 0) {
			uni.showToast({
				title: questionResponse["message"],
				icon: 'error',
			});
			console.log(questionResponse);
			responseMessage.value = questionResponse["message"];
			return;
		}
		let question : string = questionResponse['text'];
		question = `# 数据\
			${JSON.stringify(events.value)}\
			# 用户问题\
			${question}`;
		askActivity(props.activityId, question).then(res => {
			if (res.code !== 0) {
				uni.showToast({
					title: res["message"],
					icon: 'error',
				});
				console.log(res);
				responseMessage.value = res["message"];
				return;
			}
			responseMessage.value = res['response'];
			flushEvent();
		}).catch(err => {
			console.log(err)
			uni.showToast({
				title: '发生异常',
				icon: 'error'
			});
		});
	}

	// 下面是签到项的函数
	const members = ref([]);
	const checkInTaskDialog = ref();
	const selections = ref([]);
	const currentEventTaskId = ref<number>();
	const selectedParticipationId = ref<number>();
	function onAddParticipationTask(
		eventTaskId : number,
		// 由子组件提供的已经参与任务的参与者id
		participationIds : number[],
	) {
		selections.value = members.value.filter(
			item => !participationIds.includes(item['activity_participation_id'])
		);
		selections.value = selections.value.map(item => {
			return {
				...item,
				value: item['activity_participation_id'],
				text: item['username_in_activity'],
			}
		});
		selectedParticipationId.value = null;
		currentEventTaskId.value = eventTaskId;
		checkInTaskDialog.value.open("dialog");
	}
	function addParticipationTaskConfirm() {
		if (selectedParticipationId.value === null) {
			uni.showToast({
				title: '没有选择用户',
				icon: 'error',
			});
			return;
		}
		addParticipationTask(
			props.activityId,
			currentEventTaskId.value,
			selectedParticipationId.value,
		).then(res => {
			if (res.code !== 0) {
				uni.showToast({
					title: res.message,
					icon: 'error'
				});
				console.log(res);
				return;
			}
			flushEvent();
		}).catch(err => {
			uni.showToast({
				title: '发生异常',
				icon: 'error'
			});
			console.log(err);
		});
		checkInTaskDialog.value.close();
	}

	function onDeleteParticipationTask(participationTaskId : number) {
		deleteParticipationTask(
			participationTaskId
		).then(res => {
			if (res.code !== 0) {
				uni.showToast({
					title: res.message,
					icon: 'error'
				});
				return;
			}
			flushEvent();
		}).catch(err => {
			console.log(err)
			uni.showToast({
				title: '发生异常',
				icon: 'error'
			});
		});
	}

	// 下面的是初始化相关函数
	// 获取 events 后进行处理
	function processEvents() {
		const now = Date.now();
		let planedCumulativeTime : number = 0;
		let cumulativeTime : number = 0;

		// 标志位，是否找到当前的活动，后面的活动都设置为 future，减少计算压力，降低程序复杂度
		let findCurrent : boolean = false;

		// 确定基准时间：优先使用实际开始时间，否则用计划开始时间
		let planedBaseTime = new Date(activity.value.activity_start_time).getTime();
		let baseTime = activity.value.real_activity_start_time
			? new Date(activity.value.real_activity_start_time).getTime()
			: new Date(activity.value.activity_start_time).getTime();

		if (activity.value['real_activity_start_time'] === null && now > baseTime) {
			baseTime = now;
		}

		// 递归处理事件及其子事件，只为没有 children 的事件计算时间
		function processEventsWithTime(events : Array<any>) {
			return events.map(event => {
				if (event.children && event.children.length > 0) {
					// 有子事件的，只保留原始时间数据，递归处理子事件
					const processedChildren = processEventsWithTime(event.children);
					const childrenLength = processedChildren.length;
					let parentStatus : 'past' | 'current' | 'future';
					try {
						// 按理来说不应该有越界问题的，但是出现过这个问题，后续没有复现
						// 只能先用 try - catch 先包裹着了，出问题了再看
						if (processedChildren[0].status === processedChildren[childrenLength - 1].status) {
							parentStatus = processedChildren[0].status;
						} else parentStatus = 'current';
					} catch (e) {
						console.log(processedChildren);
					}

					return {
						...event,
						status: parentStatus,
						children: processedChildren,
					};
				} else {
					// 没有子事件的，计算时间
					const planedStartTime = planedBaseTime + planedCumulativeTime;
					const startTime = baseTime + cumulativeTime;
					let planedDuration = event['delta_time'] * 1000;  // delta_time 单位是秒，需要转换为毫秒
					let duration = event['real_delta_time'] ? event['real_delta_time'] * 1000 : event['delta_time'] * 1000;
					let planedEndTime = planedStartTime + planedDuration;
					let endTime = startTime + duration;

					// 判断 status 状态
					let status : 'past' | 'current' | 'future';
					// 对应活动没开始的情况，此时所有的活动都还没轮到
					if (activity.value['real_activity_start_time'] === null) {
						status = 'future';
					}
					// 对应活动已经开始的情况
					else {
						// 在开始判断前先看标志位，没找到的情况下只能是 past 或者 current，否则都是 future
						if (findCurrent) status = 'future';
						// 情况1：没有设置实际时长
						// 可能是活动正在进行，还没结束，也可能是活动还没轮到，但是下面的情况可以用标志位优化
						else if (event['real_delta_time'] === null) {
							// 情况1.1：正在进行，还没确定何时结束
							// 情况1.2：还没轮到这个活动
							// 但是可以用标志位直接判断
							status = 'current';
							findCurrent = true;
							// 如果超时了，需要自动延时
							if (now > endTime) {
								endTime = now;
								duration = endTime - startTime;
							}
						}
						// 情况2：设置了实际时长
						// 可能是已经结束的活动或者正在进行但还没到点的活动
						// 这种情况没法用标志位辅助判断，只能慢慢算了
						else {
							// 情况2.1：正在进行，还没到达设置的时间
							if (now < endTime) {
								status = 'current';
								findCurrent = true;
							} else {
								status = 'past';
							}
						}
					}
					planedCumulativeTime += planedDuration;
					cumulativeTime += duration;

					const result = {
						...event,
						planed_calculated_start_time: new Date(planedStartTime),
						calculated_start_time: new Date(startTime),
						planed_calculated_end_time: new Date(planedEndTime),
						calculated_end_time: new Date(endTime),
						planed_formatted_start_time: new Intl.DateTimeFormat('zh-CN', {
							hour: '2-digit',
							minute: '2-digit',
							second: '2-digit',
							hour12: false,
						}).format(new Date(planedStartTime)),
						formatted_start_time: new Intl.DateTimeFormat('zh-CN', {
							hour: '2-digit',
							minute: '2-digit',
							second: '2-digit',
							hour12: false,
						}).format(new Date(startTime)),
						planed_formatted_end_time: new Intl.DateTimeFormat('zh-CN', {
							hour: '2-digit',
							minute: '2-digit',
							second: '2-digit',
							hour12: false,
						}).format(new Date(planedEndTime)),
						formatted_end_time: new Intl.DateTimeFormat('zh-CN', {
							hour: '2-digit',
							minute: '2-digit',
							second: '2-digit',
							hour12: false,
						}).format(new Date(endTime)),
						status,
						planed_duration: planedDuration,
						duration,
					};

					if (status === 'current') {
						currentEvent.value = result;
					}

					return result;
				}
			});
		}
		processedEvents.value = processEventsWithTime(events.value);
	}
	function flushEvent() {
		getEventsByActivityId(props.activityId).then(res => {
			if (res.code !== 0) {
				uni.showToast({
					title: res.message,
					icon: 'error'
				});
				console.log(res);
				return;
			}
			// 在 flushEvent 函数中对 events.value 赋值后，调用处理函数
			events.value = res['events'];
		}).catch(err => {
			console.log(err)
			uni.showToast({
				title: '获取事件发生异常',
				icon: 'error',
			});
			console.log(err);
		});
	}

	function flushMember() {
		getMembers(props.activityId).then(res => {
			if (res.code !== 0) {
				uni.showToast({
					title: res.message,
					icon: 'error'
				});
				console.log(res);
				return;
			}
			members.value = res['members'];
		}).catch(err => {
			uni.showToast({
				title: '发生异常',
				icon: 'error'
			});
			console.log(err);
		});
	}

	onMounted(() => {
		const userType = 'admin';
		socketTask = uni.connectSocket({
			url: WS_URL + `/activity/${props.activityId}?user_type=${userType}&token=${uni.getStorageSync('token')}`,
			fail() {
				uni.showToast({
					title: '连接失败，请刷新页面',
					icon: 'error',
				})
			}
		});
		socketTask.onMessage(res => {
			activityControl.handleInput(res.data);
		});
		socketTimer = setInterval(() => {
			socketTask.send({
				data: "ping",
				fail(options) {
					uni.showToast({
						title: `${options.errMsg}`,
						icon: 'error',
					})
				}
			})
		}, 5000);
		getActivityById(props.activityId).then((res) => {
			if (res.code !== 0) {
				uni.showToast({
					title: res.message,
					icon: 'error'
				});
				console.log(res);
				return;
			}
			activity.value = res['activity'];
		}).catch(err => {
			console.log(err)
			uni.showToast({
				title: '初始化时发生异常',
				icon: 'error'
			});
			console.log(err);
		}).finally(() => {
			flushEvent();
			setInterval(() => timeTrigger.value = Math.floor(Date.now() / 1000), 100);
		});
		flushMember();
	});
	onBeforeUnmount(() => {
		// socketTimer在socket前关闭
		if (socketTimer) {
			clearInterval(socketTimer);
		}
		socketTask.close({
			code: 1000,
		});
	});
</script>

<style scoped lang="less">
	// 事件列表的样式
	.event-header {
		display: flex;
		align-items: center;

		// 加号按钮父级标签的样式
		.event-actions {
			display: flex;
			gap: 10rpx;

			// 加号按钮的样式
			.add-btn {
				width: 36rpx;
				height: 36rpx;
				border-radius: 50%;
				background-color: #dbeafe;
				color: #2563eb;
				border: none;
				font-size: 24rpx;
				display: flex;
				align-items: center;
				justify-content: center;
				cursor: pointer;
				transition: all 0.2s;
			}
		}
	}

	// 事件列表容器
	.event-list {
		height: calc(100vh - 35px - 235px - 30px - 44px);
	}

	.dialogs {
		.participation-task-dialog {
			.participation-task-dialog-content {
				padding: 20rpx;
				background-color: white;
			}
		}
	}
</style>
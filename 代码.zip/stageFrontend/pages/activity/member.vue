<template>
	<view class="container" v-if="props.activityId">
		<view>
			<text class="title">工作人员列表</text>
			<uni-table border stripe emptyText="没有工作人员">
				<uni-tr>
					<uni-th width="50" align="center">姓名</uni-th>
					<uni-th width="100" align="center">邮箱</uni-th>
					<uni-th width="100" align="center">操作</uni-th>
				</uni-tr>
				<uni-tr v-for="(item, index) in users" :key="index">
					<uni-td align="center">{{item['username_in_activity']}}</uni-td>
					<uni-td align="center">{{item['email']}}</uni-td>
					<uni-td align="center">
						<button v-if="!checkIsAdmin(item['scopes'])" type="primary" size="mini"
							@click="onSetMemberRole(item['activity_participation_id'], 1)">
							设为管理员
						</button>
						<button v-if="checkIsAdmin(item['scopes'])" type="warn" size="mini"
							@click="onDeleteMemberRole(item['scopes'][0]['user_activity_role_id'])">
							设为普通用户
						</button>
						<button @click="onRemoveMember(item['activity_participation_id'])" type="warn" size="mini">
							移除
						</button>
					</uni-td>
				</uni-tr>
			</uni-table>
			<button class="main-btn" @click="newUser" :disabled="isLoading">添加人员</button>
		</view>
	</view>
	<view v-else>
		无法获取活动id
	</view>
</template>

<script setup lang="ts">
	import {
		onShow
	} from '@dcloudio/uni-app';

	import {
		ref
	} from 'vue';

	import {
		inviteMember,
		getMembers,
		removeMember,
		addMemberRole,
		deleteMemberRole,
	} from '@/api/activity';

	const props = defineProps({
		activityId: {
			type: Number,
			required: true
		}
	})

	// 人员管理部分
	const isLoading = ref(true);
	const users = ref([]);

	function flushMember() {
		getMembers(props.activityId).then(res => {
			if (res.code !== 0) {
				uni.showToast({
					title: res.message,
					icon: 'error'
				})
				return
			}
			isLoading.value = false;
			users.value = res['members']
		}).catch(err => {
			console.log(err)
			uni.showToast({
				title: '发生异常',
				icon: 'error'
			})
		})
	}

	onShow(() => {
		flushMember();
	})

	function newUser() {
		let email = prompt('请输入成员邮箱')?.trim();
		if (!email) return;
		inviteMember(
			props.activityId,
			email,
		).then(res => {
			if (res.code !== 0) {
				uni.showToast({
					title: res.message,
					icon: 'error',
				});
				return;
			}
			flushMember();
		}).catch(err => {
			console.log(err)
			uni.showToast({
				title: '发生异常',
				icon: 'error',
			});
		});
	}

	function checkIsAdmin(scopes : { activity_scope_symbol : string }[]) : boolean {
		for (const scope of scopes) {
			if (scope['activity_scope_symbol'] === 'admin') return true;
		}
		return false;
	}

	function onSetMemberRole(activityParticipationId : number, activityScopeId : number) {
		addMemberRole(activityParticipationId, activityScopeId).then(res => {
			if (res.code !== 0) {
				uni.showToast({
					title: res.message,
					icon: 'error'
				});
				console.log(res);
				return;
			}
			flushMember();
		}).catch(err => {
			console.log(err);
			uni.showToast({
				title: '发生异常',
				icon: 'error'
			});
		});
	}

	function onDeleteMemberRole(userActivityRoleId : number) {
		deleteMemberRole(userActivityRoleId).then(res => {
			if (res.code !== 0) {
				uni.showToast({
					title: res.message,
					icon: 'error'
				});
				console.log(res);
				return;
			}
			flushMember();
		}).catch(err => {
			console.log(err)
			uni.showToast({
				title: '发生异常',
				icon: 'error'
			});
		});
	}

	function onRemoveMember(activityParticipationId : number) {
		removeMember(activityParticipationId).then(res => {
			if (res.code !== 0) {
				uni.showToast({
					title: res.message,
					icon: 'error'
				})
				return
			}
			flushMember();
		}).catch(err => {
			console.log(err)
			uni.showToast({
				title: '发生异常',
				icon: 'error'
			});
		});
	}
</script>

<style scoped lang="less">
	.container {
		padding: 20px;
		background-color: #f5f5f5;
		min-height: 100vh;
	}

	.group {
		background: #fff;
		border-radius: 12px;
		padding: 16px;
		margin-bottom: 16px;
		box-shadow: 0 2px 6px rgba(0, 0, 0, 0.05);
	}

	.title {
		font-size: 16px;
		font-weight: bold;
		margin-bottom: 8px;
	}

	.actions {
		display: flex;
		gap: 10px;
		flex-wrap: wrap;
		margin-top: 8px;
	}

	.mini {
		font-size: 12px;
		padding: 6px 10px;
		border-radius: 6px;
		background-color: #ff0000;
		color: #fff;
		border: none;
	}

	.main-btn {
		margin-top: 20px;
		background-color: #005500;
		color: white;
		padding: 10px 16px;
		border-radius: 8px;
		border: none;
		font-size: 14px;
		width: 160px;
		align-self: center;
	}
</style>
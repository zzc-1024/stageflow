<template>
	<view class="checkDetails">
		<view class="checkDetails-nav">
			<scroll-view class="scroll-view_H" scroll-x="true" :scroll-left="scrollValue">
				<span v-for="(item, index) in navList" :key="index" class="checkDetails-nav-item"
					:class="{ 'action': navCurrent == item.value }" @click="handleSwitch(item, index)">
					{{ item.text }}
				</span>
			</scroll-view>
		</view>
		<control-vue v-if="navCurrent === 'control'" :activity-id="activityId"></control-vue>
		<design-vue v-if="navCurrent === 'activity'" :activity-id="activityId"></design-vue>
		<member-vue v-if="navCurrent === 'people'" :activity-id="activityId"></member-vue>
	</view>
</template>

<script setup lang="ts">
	import { onLoad } from '@dcloudio/uni-app'
	import { ref } from 'vue';
	import controlVue from './control.vue';
	import designVue from './design.vue';
	import memberVue from './member.vue';

	const scrollValue = ref(0);
	const navCurrent = ref("control");
	const activityId = ref<number>();

	onLoad(option => {
		activityId.value = parseInt(option.activityId);
	});

	interface NavItem {
		text : string;
		value : string
	}

	const navList : NavItem[] = [
		{
			text: "活动控制",
			value: "control"
		},
		{
			text: "活动编排",
			value: "activity"
		},
		{
			text: "人员管理",
			value: "people"
		},
	];
	function handleSwitch(item : NavItem, index : number) {
		navCurrent.value = item.value;
		scrollValue.value = index * 100;
	}
</script>

<style scoped>
	.scroll-view_H {
		white-space: nowrap;
		width: 100%;
		background: #fff;
	}

	.scroll-view-item {
		height: 300rpx;
		line-height: 300rpx;
		text-align: center;
		font-size: 36rpx;
	}

	.scroll-view-item_H {
		display: inline-block;
		width: 100%;
		height: 300rpx;
		line-height: 300rpx;
		text-align: center;
		font-size: 36rpx;
	}

	.checkDetails-nav-item {
		font-size: 16px;
		font-weight: 500;
		letter-spacing: 0px;
		line-height: 30px;
		color: rgba(75, 89, 105, 1);
		text-align: left;
		vertical-align: top;
		background: #fff;
		padding: 0px 30px;

	}

	.action {
		font-size: 18px;
		font-weight: 700;
		letter-spacing: 0px;
		line-height: 25.2px;
		color: rgba(12, 16, 25, 1);
		position: relative;
	}

	.action::after {
		content: '';
		position: absolute;
		background-image: url(../../static/checkDetails/action.png);
		background-size: 100%;
		background-repeat: no-repeat;
		width: 28px;
		height: 10px;
		top: 18px;
		left: 34px;
	}
</style>
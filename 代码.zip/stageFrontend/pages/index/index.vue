<template>
	<scroll-view class="left-panel" scroll-y>
		<view class="section" v-if="isLogin">
			<view class="section-title">活动列表</view>
			<view class="activity-card" v-for="activity in activities" :key="activity['activity_id']"
				@click="onActivityDetail(activity['activity_id'])">
				<text>{{ activity['activity_name'] }}</text>
				<br />
				<text class="description">{{ activity['activity_description']}}</text>
			</view>
		</view>
		<view v-else>
			请先登录
		</view>
	</scroll-view>
</template>

<script setup lang="ts">
	import {
		onShow
	} from '@dcloudio/uni-app';

	import {
		ref,
		computed
	} from 'vue';

	import {
		getParticipateActivities
	} from '@/api/activity';

	const isLogin = ref(false);

	// 响应式数据
	const activities = ref([])

	function flushActivities() {
		isLogin.value = uni.getStorageSync("token") ? true : false;
		if (!isLogin.value) return;
		getParticipateActivities().then(res => {
			if (res['code'] !== 0) {
				uni.showToast({
					title: res['message'],
					icon: 'error'
				})
				return
			}
			activities.value = res['activities'];
		})
	}

	onShow(() => {
		flushActivities()
	})

	function onActivityDetail(activityId : number) {
		uni.navigateTo({
			url: `/pages/index/activity/index?activityId=${activityId}`,
		})
	}
</script>

<style scoped>
	.container {
		display: flex;
		flex-direction: row;
		height: 100vh;
	}

	.left-panel,
	.right-panel {
		flex: 1;
		padding: 20rpx;
		overflow: scroll;
	}

	.left-panel {
		background: #f7f7f7;
	}

	.right-panel {
		background: #ffffff;
	}

	.section-title {
		font-weight: bold;
		margin-bottom: 10rpx;
	}

	.activity-card {
		border-radius: 12rpx;
		padding: 20rpx;
		margin-bottom: 12rpx;
		box-shadow: 0 2rpx 6rpx rgba(0, 0, 0, 0.05);
		color: #fff;
		background: #37c23a;
	}

	.description {
		font-size: 24rpx;
		color: #fff;
	}

	.notice-header {
		font-size: 30rpx;
		font-weight: bold;
		margin-bottom: 20rpx;
	}

	.timeline-avatar {
		font-size: 40rpx;
		margin-bottom: 10rpx;
	}

	.timeline-date {
		font-size: 24rpx;
		color: #888;
		margin-bottom: 20rpx;
	}

	.timeline-item {
		display: flex;
		flex-direction: row;
		position: relative;
		margin-bottom: 40rpx;
		transition: transform 0.3s ease, background-color 0.3s ease;
	}

	.timeline-item.highlight {
		background-color: #e6f7ff;
		transform: scale(1.02);
		border-left: 8rpx solid #409eff;
		padding-left: 12rpx;
		border-radius: 8rpx;
	}

	.timeline-point-wrapper {
		width: 40rpx;
		display: flex;
		flex-direction: column;
		align-items: center;
		position: relative;
	}

	.timeline-point-wrapper .dot {
		width: 16rpx;
		height: 16rpx;
		background-color: #409eff;
		border-radius: 50%;
		z-index: 1;
	}

	.timeline-point-wrapper .line {
		width: 4rpx;
		background-color: #409eff;
		flex: 1;
		position: absolute;
		top: -40rpx;
		bottom: 8rpx;
		left: 50%;
		margin-left: -2rpx;
		z-index: 0;
	}

	.timeline-content {
		flex: 1;
		padding-left: 20rpx;
	}

	.timeline-content .time {
		color: #555;
		font-weight: bold;
	}

	.timeline-content .desc {
		color: #333;
	}

	.history-footer {
		margin-top: 30rpx;
		color: #aaa;
		font-size: 24rpx;
	}
</style>
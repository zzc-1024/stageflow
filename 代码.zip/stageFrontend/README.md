# 项目简介

本项目是舞台规划软件的前端部分，负责对后端提供的数据进行可视化展示。

# 快速开始

本项目使用 HBuilderX 进行开发，确保已安装 HBuilderX 并配置好环境。

## 打包项目

打包项目使用 HBuilderX 进行打包，依次点击 `发行` -> `网站-PC Web或手机H5`，
打包完成后会在控制台输出打包信息，包括打包路径等。

## 部署项目

将打包好的项目部署到服务器上，这里以 Nginx 为例。

1. 安装 Nginx。

```shell
# 更新软件包列表
apt update
apt upgrade
# 安装 Nginx
apt install nginx
```

2. 配置 Nginx，将项目的静态文件部署到 Nginx 目录下。

将打包好的项目静态文件复制到 Nginx 目录下。

默认情况下，Nginx 的静态文件目录是 `/var/www/html`，
将项目的静态文件复制到该目录下即可。

3. 重启 Nginx。

```shell
# 重启 Nginx
systemctl restart nginx
```

## 配置 HTTPS

受限安装相关软件：

```shell
apt install certbot python3-certbot-nginx
```

然后生成密钥和证书：

```shell
sudo openssl req -x509 -nodes -days 365 -newkey rsa:2048 -keyout /etc/ssl/private/nginx-selfsigned.key -out /etc/ssl/certs/nginx-selfsigned.crt
```

编辑 `/etc/nginx/sites-available/default` 文件，将其中内容删除，并修改为如下配置：

```nginx
server {
    listen 443 ssl;
    server_name _;

    ssl_certificate /etc/ssl/certs/nginx-selfsigned.crt;
    ssl_certificate_key /etc/ssl/private/nginx-selfsigned.key;

    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers HIGH:!aNULL:!MD5;

    location / {
        root /var/www/html;
        index index.html;
    }
}

server {
    listen 80;
    server_name _;
    return 301 https://$host$request_uri;
}
```

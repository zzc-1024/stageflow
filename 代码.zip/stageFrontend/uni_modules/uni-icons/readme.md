## Icons 图标
> **组件名：uni-icons**
> 代码块： `uIcons`

用于展示 icons 图标 。

### [查看文档](https://uniapp.dcloud.io/component/uniui/uni-icons)
#### 如使用过程中有任何问题，或者您对uni-ui有一些好的建议，欢迎加入 uni-ui 交流群：871950839 



## DataCheckbox 数据驱动的单选复选框
> **组件名：uni-data-checkbox**
> 代码块： `uDataCheckbox`


本组件是基于uni-app基础组件checkbox的封装。本组件要解决问题包括：

### [查看文档](https://uniapp.dcloud.io/component/uniui/uni-card)
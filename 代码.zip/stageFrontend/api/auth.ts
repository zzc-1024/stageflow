import clientInstance from "./clientInstance";


export async function verifyEmail() {
	return clientInstance.get("/verification/email")
}

export async function register(username : string, email : string, password : string) {
	return clientInstance.post("/auth/register", {
		username,
		email,
		password,
	})
}

export async function login(email : string, password : string) {
	return clientInstance.post("/auth/login", {
		email,
		password,
	})
}
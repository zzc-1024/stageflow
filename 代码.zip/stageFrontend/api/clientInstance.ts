import ApiClient from './client'


const PRODUCTION = true;
const PROTOCOL = PRODUCTION ? "https" : "http";
const WS_PROTOCOL = PRODUCTION ? "wss" : "ws";
const DOMAIN = PRODUCTION ? "www.superlivescene.com" : "127.0.0.1";
// const DOMAIN = "10.1.89.164";
const PORT = "8192";
const PATH = "/v1";

export const BASE_URL = PROTOCOL + "://" + DOMAIN + ":" + PORT + PATH;
export const WS_URL = WS_PROTOCOL + "://" + DOMAIN + ":" + PORT + PATH;

const clientInstance = new ApiClient({
	baseURL: BASE_URL
});

export default clientInstance;
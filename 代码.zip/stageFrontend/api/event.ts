import clientInstance from "./clientInstance";


export async function getEventsByActivityId(activity_id : number) {
	return clientInstance.get(`/activity/event/all?activity_id=${activity_id}`);
}

export async function createEvent(
	activity_id : number,
	event_name : string,
	parent_event_id : number | null,
	pre_event_id : number | null,
	delta_time : number | null,
) {
	return clientInstance.post("/activity/event/", {
		activity_id,
		event_name,
		pre_event_id,
		parent_event_id,
		delta_time,
	});
}

export async function changeEvent(
	event_id : number,
	event_name : string,
	delta_time : number,
	real_delta_time : number | null,
) {
	return clientInstance.put(`/activity/event/${event_id}`, {
		event_name,
		delta_time,
		real_delta_time,
	});
}

export async function setEventRealDeltaTime(
	activity_id : number,
	event_id : number,
	real_delta_time : number | null,
) {
	return clientInstance.put(`/activity/event/${activity_id}/${event_id}/real_delta_time`, {
		real_delta_time,
	});
}
import clientInstance from "./clientInstance";


export async function getPhases(
	activity_id : number,
) {
	return clientInstance.get(
		`/activity/${activity_id}/design/phase/all`,
	);
}

export async function createPhase(
	activity_id : number,
	phase_name : string,
) {
	return clientInstance.post(
		`/activity/${activity_id}/design/phase`,
		{
			phase_name
		}
	);
}

export async function deletePhase(
	activity_id : number,
	phase_id : number,
) {
	return clientInstance.delete(
		`/activity/${activity_id}/design/phase/${phase_id}`,
	);
}

export async function createProgramItem(
	activity_id : number,
	phase_id : number,
	program_item_name : string
) {
	return clientInstance.post(
		`/activity/${activity_id}/design/program_item`,
		{
			phase_id,
			program_item_name
		}
	);
}

export async function deleteProgramItem(
	activity_id : number,
	program_item_id : number,
) {
	return clientInstance.delete(
		`/activity/${activity_id}/design/program_item/${program_item_id}`,
	);
}

export async function createShow(
	activity_id : number,
	program_item_id : number,
	show_name : string,
	delta_time : string,
) {
	return clientInstance.post(
		`/activity/${activity_id}/design/show`,
		{
			program_item_id,
			show_name,
			delta_time,
		}
	);
}

export async function deleteShow(
	activity_id : number,
	show_id : number,
) {
	return clientInstance.delete(
		`/activity/${activity_id}/design/show/${show_id}`,
	);
}

export async function createShowTask(
	activity_id : number,
	show_id : number,
	show_task_name : string,
) {
	return clientInstance.post(
		`/activity/${activity_id}/design/show_task`,
		{
			show_id,
			show_task_name,
		}
	);
}

export async function deleteShowTask(
	activity_id : number,
	show_task_id : number,
) {
	return clientInstance.delete(
		`/activity/${activity_id}/design/show_task/${show_task_id}`,
	);
}

export async function createShowTaskActivityUser(
	activity_id : number,
	show_task_id : number,
	activity_user_id : number,
) {
	return clientInstance.post(
		`/activity/${activity_id}/design/show_task_activity_user`,
		{
			show_task_id,
			activity_user_id,
		}
	);
}

export async function deleteShowTaskActivityUser(
	activity_id : number,
	show_task_activity_user_id : number,
) {
	return clientInstance.delete(
		`/activity/${activity_id}/design/show_task_activity_user/${show_task_activity_user_id}`,
	);
}

// export async function setShowTaskActivityUser(
// 	activity_id : number,
// 	show_task_activity_user_id : number,
// 	status : number
// ) {
// 	return clientInstance.put(
// 		`/activity/${activity_id}/design/show_task_activity_user`,
// 		{
// 			show_task_activity_user_id,
// 			status,
// 		}
// 	);
// }
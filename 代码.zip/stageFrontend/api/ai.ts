import clientInstance from "./clientInstance";


export async function speechRecognition(
	base64_data : string,
) {
	return clientInstance.post(
		`/ai/speech_recognition`,
		{ base64_data }, { timeout: 120_000 }
	);
}
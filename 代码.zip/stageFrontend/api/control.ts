import clientInstance from "./clientInstance";


export async function startActivity(
	activity_id : number,
	real_activity_start_time : string,
) {
	return clientInstance.put(
		`/activity/${activity_id}/control/start`,
		{
			real_activity_start_time,
		}
	);
}

export async function setCurrentShow(
	activity_id : number,
	show_id : string,
	real_delta_time : string | null,
) {
	return clientInstance.put(
		`/activity/${activity_id}/control/show/set_real_delta_time`,
		{
			show_id,
			real_delta_time,
		}
	);
}

export async function setShowTaskActivityUser(
	activity_id : number,
	show_task_activity_user_id : number,
	status : number
) {
	return clientInstance.put(
		`/activity/${activity_id}/control/show_task/set_status`,
		{
			show_task_activity_user_id,
			status,
		}
	);
}

import clientInstance from "./clientInstance";


export async function createActivity(
	activity_name : string,
	activity_description : string,
	activity_start_time : string,
	activity_visibility : number
) {
	return clientInstance.post(
		"/activity",
		{
			activity_name,
			activity_description,
			activity_start_time,
			activity_visibility,
		}
	);
}

export async function updateActivity(
	activity_id : number,
	activity_name : string,
	activity_description : string,
	activity_start_time : string,
	activity_visibility : number,
) {
	return clientInstance.put(
		"/activity",
		{
			activity_id,
			activity_name,
			activity_description,
			activity_start_time,
			activity_visibility,
		}
	);
}

export async function startActivity(
	activity_id : number,
	real_activity_start_time : string,
) {
	return clientInstance.put(
		`/activity/${activity_id}/start`,
		{
			real_activity_start_time
		}
	);
}

export async function getActivityByCurrentUser() {
	return clientInstance.get("/activity/");
}

export async function getActivityByManager() {
	return clientInstance.get("/activity/managed");
}

export async function getParticipateActivities() {
	return clientInstance.get("/activity/participate");
}

export async function getActivityById(
	activity_id : number,
) {
	return clientInstance.get("/activity/" + activity_id.toString())
}

export async function inviteMember(
	activity_id : number,
	user_email : string,
) {
	return clientInstance.post(
		"/activity/invite",
		{
			activity_id,
			user_email
		}
	)
}

export async function getMembers(
	activity_id : number,
) {
	return clientInstance.get(
		`/activity/${activity_id.toString()}/member`
	)
}

export async function removeMember(
	activity_user_id : number
) {
	return clientInstance.delete(
		`/activity/member/${activity_user_id.toString()}`
	)
}

export async function addMemberRole(
	activity_participation_id : number,
	activity_scope_id : number,
) {
	return clientInstance.put(
		`/activity/member/role/${activity_participation_id.toString()}`,
		{ activity_scope_id }
	);
}

export async function deleteMemberRole(
	user_activity_role_id : number
) {
	return clientInstance.delete(
		`/activity/member/role/${user_activity_role_id}`,
	);
}

export async function askActivity(
	activity_id : number,
	question : string,
) {
	return clientInstance.post(
		`/activity/${activity_id}/ask`,
		{ question },
		{ timeout: 120_000 }
	);
}
import clientInstance from "./clientInstance";


export async function createEventTask(
	activity_id : number,
	event_id : number,
	event_task_name : string
) {
	return clientInstance.post(`/activity/event/event_task/create`, {
		activity_id,
		event_id,
		event_task_name,
	});
}

export async function deleteEventTask(event_task_id : number) {
	return clientInstance.delete(`/activity/event/event_task/${event_task_id}`);
}

export async function changeEventTask(
	event_task_id : number,
	event_task_name : string
) {
	return clientInstance.put(`/activity/event/event_task/${event_task_id}`, {
		event_task_name,
	});
}

export async function changeEventTaskStartTime(
	event_task_id : number,
	event_task_start_time : number
) {
	return clientInstance.put(`/activity/event/event_task/${event_task_id}/start_time`, {
		event_task_start_time,
	});
}

export async function addParticipationTask(
	activity_id : number,
	event_task_id : number,
	activity_participation_id : number,
) {
	return clientInstance.post(`/activity/event/event_task/${event_task_id}/participation`, {
		activity_id,
		activity_participation_id,
	});
}

export async function deleteParticipationTask(participation_task_id : number) {
	return clientInstance.delete(`/activity/event/event_task/participation/${participation_task_id}`);
}

export async function checkIn(
	activity_id : number,
	participation_task_id : number,
	status : number
) {
	return clientInstance.put(`/activity/event/event_task/${activity_id}/participation/${participation_task_id}`, {
		status,
	});
}
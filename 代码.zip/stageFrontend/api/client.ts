// HTTP 方法类型
// export type HttpMethod = 'GET' | 'POST' | 'PUT' | 'DELETE' | 'OPTIONS' | 'HEAD' | 'TRACE' | 'CONNECT'

// 基础响应类型
export interface ApiResponse<T = any> {
	code : number
	message : string
	data : T
	timestamp ?: number
}

// 请求配置类型
export interface ApiRequestConfig {
	url : string
	method ?: any
	data ?: any
	params ?: Record<string, any>
	headers ?: Record<string, string>
	timeout ?: number
	baseURL ?: string
}

// API 客户端配置
export interface ApiClientConfig {
	baseURL ?: string
	timeout ?: number
	headers ?: Record<string, string>
	interceptors ?: {
		request ?: (config : ApiRequestConfig) => ApiRequestConfig
		response ?: (response : any) => any
	}
}

class ApiClient {
	private config : ApiClientConfig

	constructor(config : ApiClientConfig = {}) {
		this.config = {
			baseURL: '',
			timeout: 10000,
			headers: {
				'Content-Type': 'application/json'
			},
			...config
		}
	}

	// 合并配置
	private mergeConfig(config : ApiRequestConfig) : ApiRequestConfig {
		const mergedConfig : ApiRequestConfig = {
			baseURL: this.config.baseURL,
			timeout: this.config.timeout,
			headers: { ...this.config.headers },
			method: 'GET',
			...config
		}

		// 处理请求拦截器
		if (this.config.interceptors?.request) {
			return this.config.interceptors.request(mergedConfig)
		}

		return mergedConfig
	}

	// 构建完整 URL
	private buildURL(config : ApiRequestConfig) : string {
		let url = config.url

		// 添加 baseURL
		if (config.baseURL && !url.startsWith('http')) {
			url = config.baseURL + url
		}

		// 处理查询参数
		if (config.params) {
			const params = new URLSearchParams()
			Object.keys(config.params).forEach(key => {
				if (config.params![key] !== undefined && config.params![key] !== null) {
					params.append(key, config.params![key])
				}
			})

			if (params.toString()) {
				url += (url.includes('?') ? '&' : '?') + params.toString()
			}
		}

		return url
	}

	// 发送请求的核心方法
	private async sendRequest<T>(config : ApiRequestConfig) : Promise<ApiResponse<T>> {
		const finalConfig = this.mergeConfig(config)
		const token : string = uni.getStorageSync("token");
		if (token) {
			finalConfig.headers["Authorization"] = "Bearer " + token
		}
		const url = this.buildURL(finalConfig)

		return new Promise((resolve, reject) => {
			uni.request({
				url,
				method: finalConfig.method,
				data: finalConfig.data,
				header: finalConfig.headers,
				timeout: finalConfig.timeout,
				success: (res : any) => {
					try {
						// 处理响应拦截器
						let result = res.data

						if (this.config.interceptors?.response) {
							result = this.config.interceptors.response(result)
						}

						resolve(result)
						// 下面的代码就不执行了

						// 标准化响应格式
						const response : ApiResponse<T> = {
							code: res.statusCode,
							message: 'success',
							data: result,
							timestamp: Date.now()
						}

						resolve(response)
					} catch (error) {
						reject(error)
					}
				},
				fail: (err : any) => {
					reject(new Error(`请求失败: ${err.errMsg}`))
				}
			})
		})
	}

	// GET 请求
	async get<T>(url : string, config ?: Omit<ApiRequestConfig, 'url' | 'method'>) : Promise<ApiResponse<T>> {
		return this.sendRequest<T>({
			url,
			method: 'GET',
			...config
		})
	}

	// POST 请求
	async post<T>(url : string, data ?: any, config ?: Omit<ApiRequestConfig, 'url' | 'method' | 'data'>) : Promise<ApiResponse<T>> {
		return this.sendRequest<T>({
			url,
			method: 'POST',
			data,
			...config
		})
	}

	// PUT 请求
	async put<T>(url : string, data ?: any, config ?: Omit<ApiRequestConfig, 'url' | 'method' | 'data'>) : Promise<ApiResponse<T>> {
		return this.sendRequest<T>({
			url,
			method: 'PUT',
			data,
			...config
		})
	}

	// DELETE 请求
	async delete<T>(url : string, config ?: Omit<ApiRequestConfig, 'url' | 'method'>) : Promise<ApiResponse<T>> {
		return this.sendRequest<T>({
			url,
			method: 'DELETE',
			...config
		})
	}

	// 设置基础配置
	setConfig(config : Partial<ApiClientConfig>) : void {
		this.config = { ...this.config, ...config }
	}
}

export default ApiClient
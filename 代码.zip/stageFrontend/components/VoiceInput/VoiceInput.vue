<template>
	<div class="v-container">
		<div v-if="!isRecording" class="mic-icon">🎤</div>
		<div v-else class="audio-bars">
			<div class="bar" style="height: 1.5rem; background-color: #818cf8; animation-delay: 0s;"></div>
			<div class="bar" style="height: 2rem; background-color: #6366f1; animation-delay: 0.15s;"></div>
			<div class="bar" style="height: 1rem; background-color: #818cf8; animation-delay: 0.3s;"></div>
			<div class="bar" style="height: 2.5rem; background-color: #4f46e5; animation-delay: 0.075s;"></div>
			<div class="bar" style="height: 1.25rem; background-color: #818cf8; animation-delay: 0.3s;"></div>
		</div>

		<div v-if="!isRecording" class="text-section">
			<h2 class="title">随时待命</h2>
			<p class="subtitle">
				{{props.responseMessage ? props.responseMessage: '组件异常，没有检测到文本，请联系管理员修复该问题。'}}
			</p>
		</div>
		<div v-else class="text-section">
			<h2 class="title">倾听中...</h2>
			<p class="subtitle">请保持周围环节安静，使用普通话录音</p>
		</div>

		<div class="button-group">
			<button v-if="!isRecording" class="btn-primary" @click="startRecording">开始录制</button>
			<button v-else class="btn-primary" @click="stopRecording">结束录制</button>
			<button v-if="!isRecording" class="btn-primary" @click="openInputDialog" :disabled="askDisabled">输入文本</button>
		</div>

		<!-- 弹出框，默认不展示 -->
		<view>
			<uni-popup ref="inputDialog" type="dialog">
				<uni-popup-dialog ref="inputClose" mode="input" title="输入内容" value="对话框预置提示内容!" placeholder="请输入内容"
					@confirm="dialogInputConfirm"></uni-popup-dialog>
			</uni-popup>
		</view>
	</div>
</template>

<script setup lang="ts">
	import { ref } from 'vue';

	const props = defineProps({
		responseMessage: {
			type: String,
			required: true,
		},
	});

	const emit = defineEmits<{
		onMessage : [message: string],
		onAudio : [base64_data: string],
	}>();


	// 录音功能
	const isRecording = ref(false);
	// #ifndef H5
	const recorderManager = uni.getRecorderManager();
	// 停止录音
	recorderManager.onStop((res) => {
		console.log('录音停止:', res.tempFilePath); // 返回录音文件路径
	});
	// 错误处理
	recorderManager.onError((err) => {
		console.log('录音错误:', err);
	});
	// #endif
	// #ifdef H5
	let mediaRecorder : MediaRecorder;
	// #endif
	async function startRecording() {
		// #ifdef H5
		isRecording.value = true;
		// 获取媒体流
		console.log(navigator);
		const stream = await navigator.mediaDevices.getUserMedia({ audio: true })

		// 创建 MediaRecorder 实例 
		mediaRecorder = new MediaRecorder(stream);

		// 注册数据可用事件,以获取编码后的媒体数据块
		function blobToBase64(blob : Blob) : Promise<string> {
			return new Promise((resolve, reject) => {
				const fileReader = new FileReader();
				fileReader.onload = (e) => {
					let res : string = e.target.result as string;
					res = res.split(',')[1]
					resolve(res); // 返回Base64字符串
				};
				fileReader.onerror = () => {
					reject(new Error('Blob转Base64失败'));
				};
				fileReader.readAsDataURL(blob); // 读取Blob为DataURL
			});
		}
		mediaRecorder.ondataavailable = async event => {
			const blob = event.data;
			const base64_data : string = await blobToBase64(blob);
			emit('onAudio', base64_data);
		}

		// 开始录制
		mediaRecorder.start();

		// #endif
		// isRecording.value = true;
		// recorderManager.start({
		// 	duration: 10000, // 最长10秒
		// 	format: 'mp3',   // 音频格式
		// });
		// console.log("录音开始");
	}
	function stopRecording() {
		// 录制完成后停止
		isRecording.value = false;
		mediaRecorder.stop();
	}


	// 对话框提问功能
	const inputDialog = ref();
	const askDisabled = ref(false);
	const openInputDialog = () => inputDialog.value.open();
	function dialogInputConfirm(val : string) {
		const trimVal = val.trim();
		if (trimVal.length === 0) {
			return;
		}
		askDisabled.value = true;
		emit('onMessage', trimVal);
		// 这里还需要修改
		askDisabled.value = false;
	}
</script>

<style scoped>
	/* 容器整体样式 */
	/*这里有bug,container会和外面容器的container冲突,虽然加上了作用域限制也没有用.
	这个问题在工作站上没有出现,但是在dell的小电脑上出现了,并且只有在不是localhost时出现.
	这个问题应该编译了就解决了,目前的方案是将container改为v-container应付一下.*/
	.v-container {
		width: calc(100% - 64px - 2px);
		margin: 0;
		padding: 32px;
		/* border-radius: 16px; */
		border: 1px solid rgba(255, 255, 255, 0.2);
		background-color: #1e1e1e;
		box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
		text-align: center;
		color: #ffffff;
		overflow: hidden;
	}

	.mic-icon {
		font-size: 48rpx;
		color: #818cf8;
	}

	/* 声波动画条 */
	.audio-bars {
		display: flex;
		align-items: center;
		justify-content: center;
		height: 96rpx;
		gap: 8px;
		margin-bottom: 24px;
	}

	.audio-bars .bar {
		width: 4px;
		border-radius: 2px;
		background-color: #818cf8;
		opacity: 0.8;
		/* 动态脉冲动画 */
		animation: pulse 1.2s ease-in-out infinite;
	}

	@keyframes pulse {

		0%,
		100% {
			transform: scaleY(0.3);
		}

		50% {
			transform: scaleY(1);
		}
	}

	/* 文字区域 */
	.text-section {
		margin-bottom: 24px;
	}

	.title {
		font-size: 18px;
		font-weight: 600;
		color: white;
		margin-bottom: 8px;
	}

	.subtitle {
		font-size: 14px;
		color: rgba(255, 255, 255, 0.8);
	}

	/* 按钮组 */
	.button-group {
		display: flex;
		justify-content: center;
		gap: 8px;
	}

	.btn-primary {
		padding: 8px 24px;
		border-radius: 8px;
		background-color: #4f46e5;
		color: white;
		font-weight: 600;
		font-size: 16px;
		border: none;
		box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
		transition: background-color 0.3s;
	}

	.btn-primary:hover {
		background-color: #4338ca;
	}

	.btn-help {
		padding: 8px 16px;
		border-radius: 8px;
		background-color: rgba(255, 255, 255, 0.1);
		color: white;
		font-weight: 600;
		font-size: 16px;
		border: none;
		transition: background-color 0.3s;
	}

	.btn-help:hover {
		background-color: rgba(255, 255, 255, 0.2);
	}
</style>
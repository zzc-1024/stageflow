<template>
	<view v-if="event['status'] != 'past'" class="event-item" :class="['level-' + level]" :style="eventStyle">
		<!-- 事件头部 -->
		<view class="event-header">
			<!-- 展开/折叠按钮 -->
			<button v-if="hasChildren" class="toggle-btn" @click.stop="toggleExpand" :aria-expanded="isExpanded">
				<i class="icon" :class="isExpanded ? 'expanded' : 'collapsed'">
					{{ isExpanded ? '−' : '+' }}
				</i>
			</button>

			<!-- 事件名称 -->
			<h3 class="event-name" @click="onOpenChangeNameDialog">
				{{ event['event_name'] }}
			</h3>

			<!-- 时长信息 -->
			<!-- 这里的class类名能对上号就行，不要在意名称，这里后续修改 -->
			<view class="duration-info" @click="onOpenChangeTimeDialog">
				<span v-if="!hasChildren" class="planned">
					预计: {{event['formatted_start_time']}} -
					{{event['formatted_end_time']}}（{{ formatDuration(Math.floor(event['duration'] / 1000))}}）
				</span>
				<div v-if="!hasChildren" class="planned">
					原计划: {{event['planed_formatted_start_time']}} -
					{{event['planed_formatted_end_time']}}（{{ formatDuration(Math.floor(event['planed_duration'] / 1000))}}）
				</div>
				<span v-if="event['real_delta_time']" class="actual"
					:class="getDurationClass(event['real_delta_time'], event['delta_time'])">
					实际: {{ formatDuration(event['real_delta_time']) }}
				</span>
				<span class="actual" :class="getDurationClass(event['real_delta_time'], event['delta_time'])">
					{{
						event['status'] === 'past' ? "已完成" :
						(event['status'] === 'current' ? "进行中" : "未开始")
					}}
				</span>
			</view>
		</view>

		<!-- 操作按钮 -->
		<view class="event-actions" v-if="onAddEvent">
			<button class="add-btn" @click.stop="addEventTask">添加任务</button>
			<button class="add-btn" @click.stop="addSubEvent">添加子事件</button>
		</view>

		<!-- 任务列表 -->
		<view v-if="props.event['event_tasks'].length > 0">
			<EventTask :eventTasks="props.event['event_tasks']" :onChangeEventTask="props.onChangeEventTask"
				:onDeleteEventTask="props.onDeleteEventTask" :onChangeEventTaskStartTime="onChangeEventTaskStartTime"
				:onAddParticipationTask="props.onAddParticipationTask" :onRemoveParticipant="props.onRemoveParticipant"
				:onCheckIn="props.onCheckIn" />
			<TimeLine :eventTasks="props.event['event_tasks'].filter((item : any) => item['event_task_start_time'] !== null)"
				:currentTime="props.event['status'] !=='past' ? (Math.floor(new Date().getTime() / 1000) - Math.floor(props.event['calculated_start_time']?.getTime() / 1000)) : 0"
				:totalDuration="Math.floor(props.event['planed_duration'] / 1000)" />
		</view>

		<!-- 子事件列表 -->
		<view v-if="hasChildren" class="sub-events"
			:style="{ display: isExpanded ? 'block' : 'none',animation: isExpanded ? 'fadeIn 0.3s ease-out' : 'none'}">
			<event-item v-for="(subEvent, index) in event['children']" :key="subEvent['event_id'] || index" :event="subEvent"
				:level="level + 1" :onAddEvent="props.onAddEvent" :onChangeEvent="props.onChangeEvent"
				:onAddEventTask="props.onAddEventTask" :onChangeEventTask="props.onChangeEventTask"
				:onDeleteEventTask="props.onDeleteEventTask" :onChangeEventTaskStartTime="onChangeEventTaskStartTime"
				:onAddParticipationTask="props.onAddParticipationTask" :onRemoveParticipant="props.onRemoveParticipant"
				:onCheckIn="props.onCheckIn" :all-expanded="allExpanded" />
		</view>

		<!-- 弹窗，这里的内容不显示 -->
		<view class="dialogs">
			<!-- 修改 event 标题的弹窗 -->
			<uni-popup ref="inputDialog" type="dialog">
				<uni-popup-dialog mode="input" title="输入新的事件名称" value="对话框预置提示内容!" placeholder="输入新的事件名称"
					@confirm="dialogInputConfirm"></uni-popup-dialog>
			</uni-popup>

			<!-- 修改 event 时间的弹窗 -->
			<uni-popup ref="timeDialog" background-color="#fff" class="time-dialog">
				<view class="time-dialog-content">
					<text>设置时长</text>

					<view class="time-raw">
						<uni-number-box v-model="timeToChange.hours" :min="0" :max="23" />
						小时
					</view>
					<view class="time-raw">
						<uni-number-box v-model="timeToChange.minutes" :min="0" :max="59" />
						分钟
					</view>
					<view class="time-raw">
						<uni-number-box v-model="timeToChange.seconds" :min="0" :max="59" />
						秒
					</view>

					<button type="primary" size="mini" @click="changeTimeConfirm">
						确定
					</button>
				</view>
			</uni-popup>
		</view>
	</view>
</template>

<script setup lang="ts">
	import {
		ref,
		computed,
		watch
	} from 'vue';
	import EventTask from "./EventTask.vue";
	import TimeLine from './TimeLine.vue';

	// 定义属性
	const props = defineProps({
		event: {
			type: Object,
			required: true,
			default: () => ({
				event_id: 0,
				event_name: '',
				delta_time: 0,
				real_delta_time: 0,
				children: [],
				event_tasks: [],
			})
		},
		level: {
			type: Number,
			default: 0
		},
		allExpanded: {
			type: Boolean,
			default: true
		},
		onAddEvent: {
			type: Function,
			default: null,
		},
		onChangeEvent: {
			type: Function,
			default: null,
		},
		onAddEventTask: {
			type: Function,
			default: null,
		},
		onChangeEventTask: {
			type: Function,
			default: null,
		},
		onDeleteEventTask: {
			type: Function,
			default: null,
		},
		onChangeEventTaskStartTime: {
			type: Function,
			default: null,
		},
		onAddParticipationTask: {
			type: Function,
			default: null,
		},
		onRemoveParticipant: {
			type: Function,
			default: null,
		},
		onCheckIn: {
			type: Function,
			default: null,
		}
	});

	const inputDialog = ref();
	const timeDialog = ref();

	// 定义事件
	const emit = defineEmits(['toggle-all']);

	// 展开状态
	const isExpanded = ref(true);

	// 监听allExpanded变化
	watch(
		() => props.allExpanded,
		(newVal) => {
			isExpanded.value = newVal;
		}, {
		immediate: true
	}
	);

	// 切换展开/折叠
	const toggleExpand = () => {
		isExpanded.value = !isExpanded.value;
	};

	// 检查是否有子事件
	const hasChildren = computed(() => {
		return props.event.children && props.event.children.length > 0;
	});

	// 添加子事件
	const addSubEvent = () => {
		if (!props.event['children']) {
			props.event['children'] = [];
		}

		props.onAddEvent(
			props.event['event_id'],
			null,
		)
	};

	function addEventTask() {
		if (!props.onAddEventTask) return;

		props.onAddEventTask(
			props.event['event_id'],
			"事件任务",
		)
	}

	function onOpenChangeNameDialog() {
		if (!props.onChangeEvent) return;
		inputDialog.value.open("dialog");
	}

	function dialogInputConfirm(newEventName : string) {
		if (!props.onChangeEvent) return;
		props.onChangeEvent(
			props.event['event_id'],
			newEventName,
			props.event['delta_time'],
			props.event['real_delta_time'],
		);
	}

	const timeToChange = ref({
		hours: 0,
		minutes: 0,
		seconds: 0,
	})

	function onOpenChangeTimeDialog() {
		if (!props.onChangeEvent) return;
		timeDialog.value.open("center");
	}

	function changeTimeConfirm() {
		const totalSeconds = timeToChange.value.hours * 60 * 60 +
			timeToChange.value.minutes * 60 +
			timeToChange.value.seconds;
		props.onChangeEvent(
			props.event['event_id'],
			props.event['event_name'],
			totalSeconds,
			props.event['real_delta_time'],
		);
		timeDialog.value.close();
	}

	const formatDuration = (seconds : number) => {
		if (seconds < 60) {
			return `${seconds}秒`;
		}

		const hours = Math.floor(seconds / 3600);
		const mins = Math.floor((seconds % 3600) / 60);
		const secs = seconds % 60;

		let result = '';
		if (hours > 0) {
			result += `${hours}小时`;
		}
		if (mins > 0) {
			result += `${mins}分钟`;
		}
		if (secs > 0 || result === '') { // 如果前面都是0，至少显示秒
			result += `${secs}秒`;
		}

		return result;
	};

	// 获取时长样式类
	const getDurationClass = (actual : number | null, planned : number) => {
		if (actual > planned) return 'overtime';
		if (actual < planned) return 'early';
		return 'ontime';
	};

	// 计算事件样式 - 根据层级变化
	const eventStyle = computed(() => {
		// 层级颜色映射 - 循环使用
		const colors = [
			'#ffffff', '#f0f9ff', '#f0fdf4', '#fff7ed',
			'#fcfafe', '#fef2f2', '#fffbf5', '#f0fdfa',
		];

		// 阴影强度随层级增加
		const shadowLevels = [
			'0 1px 3px rgba(0,0,0,0.1)',
			'0 2px 4px rgba(0,0,0,0.08)',
			'0 2px 5px rgba(0,0,0,0.07)',
			'0 1px 6px rgba(0,0,0,0.06)',
			'0 1px 7px rgba(0,0,0,0.05)',
		];

		const colorIndex = props.level % colors.length;
		const shadowIndex = Math.min(props.level, shadowLevels.length - 1);

		return {
			backgroundColor: colors[colorIndex],
			boxShadow: shadowLevels[shadowIndex],
			marginLeft: `${props.level * 5}rpx`,
			borderLeft: `4rpx solid ${getLevelColor(props.level)}`,
		};
	});

	// 获取层级指示颜色
	const getLevelColor = (level : number) => {
		const levelColors = [
			'#3b82f6', '#10b981', '#f59e0b', '#ef4444',
			'#8b5cf6', '#ec4899', '#06b6d4', '#6366f1'
		];
		return levelColors[level % levelColors.length];
	};

	// 声明组件名称供递归使用
	defineOptions({
		name: 'event-item'
	});
</script>

<style scoped lang="less">
	.event-item {
		padding-bottom: 10rpx;
		margin-bottom: 10rpx;
		border-radius: 12rpx;
		transition: all 0.3s ease;
	}

	.event-header {
		display: flex;
		align-items: center;
		flex-wrap: wrap;

		.event-name {
			margin: 4rpx;
		}
	}

	.toggle-btn {
		width: 40rpx;
		height: 40rpx;
		border-radius: 50%;
		background-color: rgba(0, 0, 0, 0.05);
		color: #64748b;
		display: flex;
		align-items: center;
		justify-content: center;
		margin-right: 16rpx;
		font-size: 30rpx;
		font-weight: bold;
		border: none;
		cursor: pointer;
		transition: all 0.2s ease;
	}

	.toggle-btn:hover {
		background-color: rgba(0, 0, 0, 0.1);
		transform: scale(1.1);
	}

	.icon.expanded {
		color: #3b82f6;
	}

	.icon.collapsed {
		color: #64748b;
	}

	.event-name {
		flex: 1;
		min-width: 200rpx;
		font-size: 32rpx;
		font-weight: 600;
		color: #1e293b;
		margin: 0 10rpx 8rpx 0;
	}

	.duration-info {
		display: flex;
		flex-direction: column;
		gap: 20rpx;
		font-size: 26rpx;
		white-space: nowrap;
		margin-right: 20rpx;
	}

	.planned {
		color: #64748b;
	}

	.actual {
		font-weight: 500;
	}

	.overtime {
		color: #ef4444;
	}

	.early {
		color: #10b981;
	}

	.ontime {
		color: #3b82f6;
	}

	.event-actions {
		display: flex;
		gap: 10rpx;
	}

	.add-btn {
		width: 40%;
		height: 36rpx;
		border-radius: 1%;
		background-color: #dbeafe;
		color: #2563eb;
		border: none;
		font-size: 24rpx;
		display: flex;
		align-items: center;
		justify-content: center;
		cursor: pointer;
		transition: all 0.2s;
	}

	.add-btn:hover {
		background-color: #bfdbfe;
		transform: scale(1.1);
	}

	.sub-events {
		/* margin-top: 20rpx; */
		padding-top: 10rpx;
	}

	/* 层级动画效果 */
	@keyframes fadeIn {
		from {
			opacity: 0;
			transform: translateX(20rpx);
		}

		to {
			opacity: 1;
			transform: translateX(0);
		}
	}

	/* 层级特定样式增强 */
	.level-0.event-item {
		border-top: 6rpx solid #3b82f6;
	}

	.level-1.event-item {
		border-top: 6rpx solid #10b981;
	}

	.level-2.event-item {
		border-top: 6rpx solid #f59e0b;
	}

	.level-3.event-item {
		border-top: 6rpx solid #ef4444;
	}

	.dialogs {
		.time-dialog {
			.time-dialog-content {
				padding: 30rpx;

				.time-raw {
					display: flex;
					flex-direction: row;
				}
			}
		}
	}
</style>
<template>
	<view class="task-table-container">
		<uni-table class="task-table" border stripe>
			<uni-tr>
				<uni-th align="center">任务名称</uni-th>
				<uni-th align="center">签到人员</uni-th>
			</uni-tr>

			<uni-tr class="task-body" v-for="(eventTask, index) in props.eventTasks" :key="index">
				<uni-td class="task-body-name">
					<text @click="onOpenChangeNameDialog(eventTask['event_task_id'])">
						{{ eventTask['event_task_name'] }}
					</text>
					<text v-if="eventTask['event_task_start_time']" @click="onOpenChangeTimeDialog(eventTask['event_task_id'])"
						class="task-body-start-time">
						{{ `在第${eventTask['event_task_start_time']}秒开始执行` }}
					</text>
					<text v-else @click="onOpenChangeTimeDialog(eventTask['event_task_id'])" class="task-body-non-start-time">
						{{ '无开始执行时间' }}
					</text>
					<text class="task-body-name-delete" v-if="props.onDeleteEventTask"
						@click="onDeleteEventTask(eventTask['event_task_id'])">
						删除
					</text>
				</uni-td>

				<uni-td class="task-body-people">
					<!-- 参与者列表 -->
					<view class="participants-list">
						<!-- 参与者标签 v-for 实现的若干个列表 -->
						<view class="participant-tag" v-for="(participationTask, i) in eventTask['participation_tasks']" :key="i">
							<!-- 签到人员姓名 -->
							{{ participationTask['username_in_activity'] }}

							<!-- 签到按钮 -->
							<view class="check-in-group" v-if="props.onCheckIn">
								<text class="check-in-no" v-if="participationTask['status']===0"
									@click="props.onCheckIn(participationTask['participation_task_id'], 1)">
									未签到
								</text>
								<text class="check-in-yes" v-if="participationTask['status']===1"
									@click="props.onCheckIn(participationTask['participation_task_id'], 0)">
									已签到
								</text>
							</view>

							<!-- 删除签到人员按钮 -->
							<text class="delete-tag" v-if="props.onRemoveParticipant"
								@click.stop="removeParticipant(participationTask['participation_task_id'])">×</text>
						</view>
					</view>
					<button class="add-participant-btn" v-if="props.onAddParticipationTask"
						@click="addParticipant(eventTask['event_task_id'], eventTask['participation_tasks'])">
						<uni-icons type="plus" size="16"></uni-icons>
						添加签到
					</button>
				</uni-td>
			</uni-tr>
		</uni-table>

		<!-- 弹窗，默认不可见 -->
		<view class="dialogs">
			<!-- 修改 task 标题的弹窗 -->
			<uni-popup ref="inputDialog" type="dialog">
				<uni-popup-dialog mode="input" title="输入新的任务名称" value="对话框预置提示内容!" placeholder="输入新的任务名称"
					@confirm="dialogInputConfirm"></uni-popup-dialog>
			</uni-popup>

			<!-- 修改 event 时间的弹窗 -->
			<uni-popup ref="timeDialog" background-color="#fff" class="time-dialog">
				<view class="time-dialog-content">
					<text>设置时长</text>

					<view class="time-raw">
						<uni-number-box v-model="timeToChange.hours" :min="0" :max="23" />
						小时
					</view>
					<view class="time-raw">
						<uni-number-box v-model="timeToChange.minutes" :min="0" :max="59" />
						分钟
					</view>
					<view class="time-raw">
						<uni-number-box v-model="timeToChange.seconds" :min="0" :max="59" />
						秒
					</view>

					<button type="primary" size="mini" @click="changeTimeConfirm">
						确定
					</button>
				</view>
			</uni-popup>
		</view>
	</view>
</template>

<script setup lang="ts">
	import { ref } from 'vue';

	const props = defineProps({
		eventTasks: {
			required: true,
		},
		onChangeEventTask: {
			type: Function,
			default: null,
		},
		onDeleteEventTask: {
			type: Function,
			default: null,
		},
		onChangeEventTaskStartTime: {
			type: Function,
			default: null,
		},
		onAddParticipationTask: {
			type: Function,
			default: null,
		},
		onRemoveParticipant: {
			type: Function,
			default: null,
		},
		onCheckIn: {
			type: Function,
			default: null,
		},
	});

	// 任务列表数据
	const tasks = ref([]);
	const selectedTaskId = ref();

	// 弹窗
	const inputDialog = ref();
	const timeDialog = ref();

	// 修改任务名称
	function onOpenChangeNameDialog(eventTaskId : number) {
		if (!props.onChangeEventTask) return;
		selectedTaskId.value = eventTaskId;
		inputDialog.value.open("dialog");
	}
	function dialogInputConfirm(newEventTaskName : string) {
		if (!props.onChangeEventTask) return;
		if (newEventTaskName.trim().length === 0) {
			uni.showToast({
				title: "名称长度不能为空",
				icon: 'error'
			});
			return;
		}
		props.onChangeEventTask(
			selectedTaskId.value,
			newEventTaskName
		);
	}
	const timeToChange = ref({
		hours: 0,
		minutes: 0,
		seconds: 0,
	});
	function onOpenChangeTimeDialog(id : number) {
		if (!props.onChangeEventTaskStartTime) return;
		selectedTaskId.value = id;
		timeDialog.value.open('center');
	}
	function changeTimeConfirm() {
		if (!props.onChangeEventTaskStartTime) return;
		const totalSeconds = timeToChange.value.hours * 60 * 60 +
			timeToChange.value.minutes * 60 +
			timeToChange.value.seconds;
		props.onChangeEventTaskStartTime(selectedTaskId.value, totalSeconds);
		timeDialog.value.close();
	}

	// 删除该名称
	function onDeleteEventTask(eventTaskId : number) {
		if (!props.onDeleteEventTask) return;
		props.onDeleteEventTask(eventTaskId);
	}

	// 添加签到人员
	function addParticipant(
		eventTaskId : number,
		participations : Array<any>
	) {
		if (!props.onAddParticipationTask) return;
		const participationIds = participations.map(item => item['activity_participation_id']);
		props.onAddParticipationTask(
			eventTaskId,
			participationIds,
		);
	};

	// 移除签到人员
	function removeParticipant(participationTaskId : number) {
		if (!props.onRemoveParticipant) return;
		props.onRemoveParticipant(participationTaskId);
	};
</script>

<style scoped lang="less">
	.task-table-container {
		width: 100%;
		padding: 16rpx;
		box-sizing: border-box;

		// 引入uni-table样式
		::v-deep .uni-table {
			width: 100%;
			margin-bottom: 24rpx;
		}

		.task-body {
			.task-body-name {
				.task-body-start-time {
					color: #008800;
					text-decoration: underline;

					&:hover {
						color: darkgreen;
					}
				}

				.task-body-non-start-time {
					color: blue;
					text-decoration: underline;

					&:hover {
						color: darkblue;
					}
				}

				.task-body-name-delete {
					color: red;
					text-decoration: underline;

					&:hover {
						color: darkred;
					}
				}
			}

			.task-body-people {
				.participants-list {
					.participant-tag {
						.check-in-group {
							.check-in-no {
								color: red;
							}

							.check-in-yes {
								color: green;
							}
						}
					}
				}
			}
		}

		// 签到人员列表
		.participants-list {
			display: flex;
			flex-wrap: wrap;
			gap: 12rpx;
			width: 100%;
			margin-bottom: 12rpx;
		}

		// 签到人员标签
		.participant-tag {
			background-color: #e8f4fd;
			color: #1677ff;
			padding: 6rpx 16rpx;
			border-radius: 50rpx;
			font-size: 26rpx;
			display: flex;
			align-items: center;
			gap: 8rpx;

			.delete-tag {
				color: #1677ff;
				font-size: 24rpx;
				font-weight: bold;
				cursor: pointer;
			}
		}

		// 添加签到人员按钮
		.add-participant-btn {
			height: 50rpx;
			min-width: 190rpx; // 提供最小宽度限制，防止显示不开
			background-color: #f5f7fa;
			color: #666;
			font-size: 26rpx;
			padding: 8rpx 20rpx;
			border-radius: 4rpx;
			display: flex;
			align-items: center;
			gap: 8rpx;
		}

		// 新增任务按钮
		.add-task-btn {
			width: 100%;
			background-color: #1677ff;
			color: #fff;
			font-size: 30rpx;
			padding: 20rpx 0;
			border-radius: 8rpx;
			display: flex;
			align-items: center;
			justify-content: center;
			gap: 12rpx;
		}
	}
</style>
<template>
	<div class="timeline-wrapper">
		<!-- 顶部控制栏 -->
		<div class="controls" v-if="false">
			<div class="btn-group">
				<button @click="toggleTimer" class="btn">{{ isRunning ? '暂停' : '播放' }}</button>
				<button @click="resetTimer" class="btn btn-outline">重置</button>
			</div>
			<span class="timer-display">
				{{ props.currentTime }}s / {{ totalDuration }}s
			</span>
		</div>

		<!-- 
      1. 滚动容器：限制宽度，允许 overflow-x: auto 
      ref="scrollContainer" 用于 JS 控制滚动
    -->
		<div class="scroll-container" ref="scrollContainer" v-if="totalDuration">

			<!-- 
        2. 实体容器：宽度动态计算，保证每秒钟有足够的物理像素
        style.width = totalDuration * unitWidth
      -->
			<div class="timeline-body" :style="{ width: timelineRealWidth + 'px' }">
				<!-- 轨道线 -->
				<div class="track"></div>

				<!-- 进度条 -->
				<div class="progress-bar" :style="{ width: progressPercentage + '%' }"></div>

				<!-- 当前时间指示器 -->
				<div class="current-time-indicator" :style="{ left: progressPercentage + '%' }">
					<span class="current-time-label">{{ props.currentTime }}s</span>
					<div class="current-time-dot"></div>
				</div>

				<!-- 时间刻度 (可选，为了看清间距) -->
				<div v-for="n in totalDuration + 1" :key="'tick-'+n" class="tick-mark"
					:style="{ left: ((n-1) / totalDuration) * 100 + '%' }"></div>

				<!-- 时间节点 -->
				<div v-for="(group, index) in processedEvents" :key="index" class="timeline-node"
					:class="{ 'is-active': props.currentTime >= group.time }"
					:style="{ left: (group.time / totalDuration) * 100 + '%' }" :ref="(el) => setNodeRef(el, group.time)">
					<!-- 圆点 -->
					<div class="node-dot">
						<span class="time-label">{{ group.time }}s</span>
					</div>

					<!-- 垂直引线 (错位防重叠) -->
					<div class="connector-line" :style="{ height: group.level * 50 + 30 + 'px' }"></div>

					<!-- 内容框 -->
					<div class="node-content-box">
						<div v-for="(desc, i) in group.descriptions" :key="i" class="event-item">
							{{ desc }}
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</template>

<script setup>
	import {
		ref,
		computed,
		watch,
		onUnmounted
	} from 'vue';

	// --- 传入参数 ---
	const props = defineProps({
		eventTasks: {
			required: true,
		},
		currentTime: {
			required: true,
		},
		totalDuration: {
			required: true,
		}
	});

	// --- 配置项 ---
	// const totalDuration = ref(25);
	const pxPerSecond = 60; // 关键：定义每一秒代表多少像素。值越大，间距越宽。
	const timelineRealWidth = computed(() => props.totalDuration * pxPerSecond);

	// --- 数据 ---
	const rawEvents = ref([{
			time: 2,
			description: "开场"
		},
		{
			time: 5,
			description: "灯光准备"
		},
		{
			time: 6,
			description: "音效切入"
		},
		{
			time: 12,
			description: "主舞台升起"
		},
		{
			time: 12,
			description: "干冰喷射"
		},
		{
			time: 18,
			description: "演员登场"
		},
		{
			time: 19,
			description: "聚光灯"
		},
		{
			time: 20,
			description: "高潮音乐"
		}
	]);

	// --- 状态 ---
	// const currentTime = ref(0);
	const isRunning = ref(false);
	let timer = null;

	// --- DOM Refs ---
	const scrollContainer = ref(null);
	const nodeRefs = ref({}); // 存储所有节点的 DOM 引用

	// 收集节点 Ref 的辅助函数
	const setNodeRef = (el, time) => {
		if (el) nodeRefs.value[time] = el;
	};

	// --- 核心逻辑 1: 数据处理 ---
	const processedEvents = computed(() => {
		let sorted = [...props.eventTasks].sort((a, b) =>
			a['event_task_start_time'] - b['event_task_start_time']
		);
		sorted = sorted.map(item => {
			return {
				...item,
				time: item['event_task_start_time'],
				description: item['event_task_name'],
			}
		});
		const grouped = [];
		sorted.forEach(event => {
			const last = grouped[grouped.length - 1];
			if (last && last.time === event.time) {
				last.descriptions.push(event.description);
			} else {
				grouped.push({
					time: event.time,
					descriptions: [event.description],
					level: 0
				});
			}
		});

		// 错位计算逻辑
		grouped.forEach((item, index) => {
			if (index === 0) return;
			const prevItem = grouped[index - 1];
			// 这里用物理像素距离判断更准确，或者继续用时间差
			const timeDiff = item.time - prevItem.time;

			// 如果两个节点相差小于 2.5秒，我们就错位显示
			// 因为我们定死了每秒 60px，所以 2.5s = 150px，小于这个距离文字可能会撞
			if (timeDiff < 2.5) {
				item.level = (prevItem.level + 1) % 3;
			} else {
				item.level = 0;
			}
		});
		return grouped;
	});

	const progressPercentage = computed(() => {
		return Math.min((props.currentTime / props.totalDuration) * 100, 100);
	});

	// --- 核心逻辑 2: 自动滚动 (Auto Scroll) ---
	// 监听 currentTime，当它变化时，检查是否有节点被激活
	watch(() => props.currentTime, (newTime) => {
		// 找到当前时间对应的节点（或者最近的一个过去节点）
		// 这里我们简单处理：每当时间变化，我们计算进度条的位置，让屏幕中心跟随进度条
		// 或者：只在“遇到节点”时滚动。为了平滑，我们选择跟随进度条中心。

		scrollToProgress(newTime);
	});

	const scrollToProgress = (time) => {
		if (!scrollContainer.value) return;

		const container = scrollContainer.value;
		const containerWidth = container.clientWidth;

		// 计算当前进度在总宽度中的像素位置
		const currentPx = (time / props.totalDuration) * timelineRealWidth.value;

		// 目标滚动位置 = 当前像素位置 - 容器一半宽度 (这样当前点就在屏幕正中间)
		const targetScrollLeft = currentPx - (containerWidth / 2);

		container.scrollTo({
			left: targetScrollLeft,
			behavior: 'smooth' // 平滑滚动
		});
	};

	// --- 计时器控制 ---
	const startTimer = () => {
		if (currentTime.value >= props.totalDuration) return;
		isRunning.value = true;
		timer = setInterval(() => {
			if (currentTime.value < props.totalDuration) {
				currentTime.value++;
			} else {
				pauseTimer();
			}
		}, 1000);
	};

	const pauseTimer = () => {
		isRunning.value = false;
		if (timer) clearInterval(timer);
	};

	const toggleTimer = () => isRunning.value ? pauseTimer() : startTimer();
	const resetTimer = () => {
		pauseTimer();
		currentTime.value = 0;
		// 重置时滚回起点
		if (scrollContainer.value) scrollContainer.value.scrollTo({
			left: 0,
			behavior: 'smooth'
		});
	};

	onUnmounted(() => pauseTimer());
</script>

<style scoped>
	.timeline-wrapper {
		width: 100%;
		/* max-width: 800px; */
		/* 限制外层最大宽，模拟手机或小屏环境 */
		margin: 0 auto;
		background: #fff;
		border: 1px solid #eee;
		border-radius: 8px;
		overflow: hidden;
		/* 防止圆角溢出 */
	}

	.controls {
		padding: 15px;
		background: #f5f7fa;
		border-bottom: 1px solid #eee;
		display: flex;
		justify-content: space-between;
		align-items: center;
		position: sticky;
		/* 如果外层页面滚动，控制栏吸顶 */
		left: 0;
	}

	.btn {
		padding: 6px 16px;
		margin-right: 8px;
		background: #333;
		color: #fff;
		border: none;
		border-radius: 4px;
		cursor: pointer;
	}

	.btn-outline {
		background: transparent;
		border: 1px solid #ccc;
		color: #333;
	}

	/* --- 核心滚动容器 --- */
	.scroll-container {
		width: 100%;
		overflow-x: auto;
		/* 关键：允许横向滚动 */
		padding: 60px 0 160px;
		/* 上下留白给节点 */
		position: relative;

		/* 隐藏滚动条但保留功能 (可选) */
		scrollbar-width: thin;
	}

	/* --- 实体时间轴 --- */
	.timeline-body {
		/* width 由 JS 动态计算 */
		position: relative;
		height: 4px;
		background: #e0e0e0;
		border-radius: 2px;
		margin: 0 20px;
		/* 左右留点余地，不要贴边 */
	}

	.progress-bar {
		position: absolute;
		height: 100%;
		background: #409eff;
		border-radius: 2px;
		z-index: 1;
		transition: width 1s linear;
		/* 线性过渡，配合计时器 */
	}

	/* 当前时间指示器样式 */
	.current-time-indicator {
		position: absolute;
		top: 50%;
		transform: translate(-50%, -50%);
		z-index: 4;
		display: flex;
		flex-direction: column;
		align-items: center;
		transition: left 1s linear;
	}

	.current-time-label {
		position: absolute;
		top: -20px;
		left: 50%;
		transform: translateX(-50%);
		font-size: 10px;
		color: #409eff;
		font-weight: bold;
		white-space: nowrap;
	}

	.current-time-dot {
		width: 8px;
		height: 8px;
		background: #409eff;
		border-radius: 50%;
		border: 2px solid #fff;
		box-shadow: 0 0 0 2px rgba(64, 158, 255, 0.3);
	}

	/* 刻度线 */
	.tick-mark {
		position: absolute;
		top: 0;
		width: 1px;
		height: 8px;
		background: #ccc;
		transform: translateY(-100%);
	}

	/* --- 节点样式 (与之前类似) --- */
	.timeline-node {
		position: absolute;
		top: 50%;
		transform: translate(-50%, -50%);
		z-index: 2;
		display: flex;
		flex-direction: column;
		align-items: center;
		transition: left 0.3s;
		/* 如果调整窗口，位置变化平滑 */
	}

	.node-dot {
		width: 12px;
		height: 12px;
		background: #fff;
		border: 2px solid #999;
		border-radius: 50%;
		z-index: 3;
		position: relative;
	}

	.time-label {
		position: absolute;
		top: -20px;
		left: 50%;
		transform: translateX(-50%);
		font-size: 10px;
		color: #999;
		white-space: nowrap;
	}

	.connector-line {
		width: 1px;
		background: #ddd;
		transition: all 0.3s;
	}

	.node-content-box {
		background: #fff;
		border: 1px solid #eee;
		box-shadow: 0 2px 6px rgba(0, 0, 0, 0.08);
		padding: 4px 8px;
		border-radius: 4px;
		min-width: 80px;
		text-align: center;
	}

	.event-item {
		font-size: 11px;
		color: #666;
		white-space: nowrap;
		/* 禁止文字换行，保证宽度 */
	}

	/* 激活态 */
	.timeline-node.is-active .node-dot {
		background: #409eff;
		border-color: #409eff;
		box-shadow: 0 0 0 4px rgba(64, 158, 255, 0.2);
	}

	.timeline-node.is-active .connector-line {
		background: #409eff;
	}

	.timeline-node.is-active .node-content-box {
		border-color: #409eff;
		background: #ecf5ff;
	}

	.timeline-node.is-active .event-item {
		color: #409eff;
		font-weight: bold;
	}
</style>
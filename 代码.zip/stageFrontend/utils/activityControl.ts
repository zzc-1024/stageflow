export class ActivityControl {

	private activityStartFunction : ((time : string) => void) | null = null;
	private eventSetRealDeltaTimeFunction : ((showId : number, realDeltaTime : number | null) => void) | null = null;
	private participationTaskCheckInFunction : ((showTaskActivityUserId : number, status : number) => void) | null = null;
	private heartBeatFunction : (() => void) | null = null;
	private errorFunction : ((reason : string) => void) | null = null;

	private handleActivity(command : string, params : string) {
		if (!this.activityStartFunction) return;
		switch (command) {
			case "start":
				this.activityStartFunction(params);
				break;
			default:
				if (this.errorFunction) this.errorFunction(`Activity 中没有 ${command} 这条命令`);
		}
	}

	private handleEvent(command : string, params : string) {
		if (!this.eventSetRealDeltaTimeFunction) return;
		// 早期 0.0.x 版本使用的是字符串传参，然后将字符串转化成秒，从 0.1.x 开始直接使用秒来传参，该方法暂时没用了
		const hhmmssToInt = (s : string) : number | null => {
			if (s === "None") return null;
			const [h, m, sSec] = s.split(':').map(x => parseInt(x, 10));
			return h * 3600 + m * 60 + sSec;
		};
		switch (command) {
			case "set_real_delta_time":
				const firstSpace = params.indexOf(" ");
				// TODO: 捕获异常
				const realDeltaTimeString = params.substring(firstSpace + 1);
				this.eventSetRealDeltaTimeFunction(
					parseInt(params.substring(0, firstSpace)),
					realDeltaTimeString === "None" ? null : parseInt(realDeltaTimeString),
				);
				break;
			default:
				if (this.errorFunction) this.errorFunction(`Show 中没有 ${command} 这条命令`);
		}
	}

	private handleParticipationTask(command : string, params : string) {
		if (!this.participationTaskCheckInFunction) return;
		switch (command) {
			case "check_in":
				const space = params.indexOf(" ");
				this.participationTaskCheckInFunction(
					parseInt(params.substring(0, space)),
					parseInt(params.substring(space + 1)),
				);
				break;
			default:
				if (this.errorFunction) this.errorFunction(`Show 中没有 ${command} 这条命令`);
		}
	}

	private handleHeartBeat() {
		if (!this.heartBeatFunction) return;
		this.heartBeatFunction();
	}

	onActivityStart(func : (time : string) => void) {
		this.activityStartFunction = func;
	}

	onEventSetRealDeltaTime(func : (eventId : number, realDeltaTime : number | null) => void) {
		this.eventSetRealDeltaTimeFunction = func;
	}

	onCheckIn(func : (participationTaskId : number, status : number) => void) {
		this.participationTaskCheckInFunction = func;
	}

	onHeartBeat(func : () => void) {
		this.heartBeatFunction = func;
	}

	onError(func : (reason : string) => void) {
		this.errorFunction = func;
	}

	handleInput(input : string) {
		if (input === "pong") {
			this.handleHeartBeat();
			return;
		}
		const firstSpace = input.indexOf(" ");
		const subject = input.substring(0, firstSpace);
		let remain = "";
		remain = input.substring(firstSpace + 1);
		const secondSpace = remain.indexOf(" ");
		const command = remain.substring(0, secondSpace);
		const params = remain.substring(secondSpace + 1);
		switch (subject) {
			case "activity":
				this.handleActivity(command, params);
				break;
			case "event":
				this.handleEvent(command, params);
				break;
			case "participation_task":
				this.handleParticipationTask(command, params);
				break;
			default:
				if (this.errorFunction) this.errorFunction(`${subject} 不是有效的主题`)
				break;
		}
	}
}